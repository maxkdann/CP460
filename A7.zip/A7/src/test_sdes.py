from sdes import SBOX, SDES

def test_sbox():
    print('{}'.format('-'*40))
    print("Start of SBOX class testing")
    print()
    
    print('Creating an empty SBOX:')
    sbox = SBOX()
    print(sbox)
    print('sbox.substitute(1000) = {}'.format(sbox.substitute('1000')))
    print('sbox.is_empty() = {}'.format(sbox.is_empty()))
    print('sbox.get_size() = {}'.format(sbox.get_size()))    
    print('sbox.get_box() = {}'.format(sbox.get_box()))
    print()
    
    print('Loading sbox1.txt:')
    print("sbox.set_box('sbox1.txt'):")
    print(sbox.set_box('sbox1.txt'))
    print(sbox)
    print('sbox.is_empty() = {}'.format(sbox.is_empty()))
    print('sbox.get_size() = {}'.format(sbox.get_size()))
    print('sbox.get_box() = {}'.format(sbox.get_box()))
    cases = ['1101','0010','0111','0000','010',1010]
    for c in cases:
        print('sbox.substitute({}) = {}'.format(c,sbox.substitute(c)))
    print()
    
    print("sbox.set_box('sbox2.txt'):")
    print(sbox.set_box('sbox2.txt'))
    print(sbox)
    cases = ['1101','0010','0111','0000','010',1010]
    for c in cases:
        print('sbox.substitute({}) = {}'.format(c,sbox.substitute(c)))
    print()
    
    print('Testing valid_box:')
    cases = [ [['1','0'],['0','1']] ,
             [[1,0],[0,1]],
             [['1','0'],['0','1'],['0','1']],
             [['10','11','00','01'],['01','10','11','00']],
             [['10','11','00','01'],['01','10','11']],
             [['10','11','000','01'],['01','10','11','00']],
             ]
    for c in cases:
        print('{} --> {}'.format(c,SBOX.valid_box(c)))
    print()
    
    print('End of SBOX class Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_feistel():
    print('{}'.format('-'*40))
    print("Start of Feistel Network testing")
    print()
    
    sdes = SDES()
    
    print('Testing expand:')
    cases = ['011001','00001111','0011','',1011]
    for c in cases:
        print('sdes.expand({}) = {}'.format(c,sdes.expand(c)))
    print()
    
    print('Testing F function:')
    bi = ['111000','100110','10011','100110']
    ki = ['00011010','01100101','01100101','0110010']
    for i in range(len(bi)):
        print('F({},{}) = {}'.format(bi[i],ki[i],sdes.F(bi[i],ki[i])))
    print()

    print('Testing feistel:')
    bi = ['011100100110','010001100101','01110010011','011100100110']
    ki = ['01100101','11000001','01100101','0110010']
    for i in range(len(bi)):
        print('feistel({},{}) = {}'.format(bi[i],ki[i],sdes.feistel(bi[i],ki[i])))
    print()

    print('End of Feistel Network Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_ECB():
    print('{}'.format('-'*40))
    print("Start of SDES ECB Mode testing")
    print()

    sdes = SDES()
    
    p = [11, 503, 27691]
    q = [19, 23, 11]
    pads = ['q','x','Q']
    rounds = [2,3,4]
    #added yR to the front
    #changed get key
    plaintexts = ['an', 'Sit', 'beet']
    for i in range(len(plaintexts)):
        sdes.set_parameter('p', p[i])
        sdes.set_parameter('q', q[i])
        sdes.set_parameter('pad',pads[i])
        sdes.set_parameter('rounds',rounds[i])
        print('key = {}'.format(sdes.get_key()))
        plaintext = plaintexts[i]
        print('plaintext  = {}'.format(plaintext))
        ciphertext = sdes.encrypt(plaintext,'ECB')
        print('ciphertext = {}'.format(ciphertext))
        plaintext2 = sdes.decrypt(ciphertext,'ECB')
        print('plaintext2 = {}'.format(plaintext2))
        print()
        
    print('End of SDES ECB Mode Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_CBC():
    print('{}'.format('-'*40))
    print("Start of SDES CBC Mode testing")
    print()

    sdes = SDES()
    
    p = [11, 43, 27691]
    q = [19, 23, 11]
    plaintexts = ['go', 'CAT', 'seed']
    for i in range(len(plaintexts)):
        sdes.set_parameter('p', p[i])
        sdes.set_parameter('q', q[i])
        print('key = {}'.format(sdes.get_key()))
        plaintext = plaintexts[i]
        print('plaintext  = {}'.format(plaintext))
        ciphertext = sdes.encrypt(plaintext,'CBC')
        print('ciphertext = {}'.format(ciphertext))
        plaintext2 = sdes.decrypt(ciphertext,'CBC')
        print('plaintext2 = {}'.format(plaintext2))
        print()
        
    print('End of SDES CBC Mode Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_OFB():
    print('{}'.format('-'*40))
    print("Start of SDES OFB Mode testing")
    print()

    sdes = SDES()
    
    p = [11, 43, 47]
    q = [19, 23, 59]
    plaintexts = ['or', 'HAT', 'feed']
    for i in range(len(plaintexts)):
        sdes.set_parameter('p', p[i])
        sdes.set_parameter('q', q[i])
        print('key = {}'.format(sdes.get_key()))
        plaintext = plaintexts[i]
        print('plaintext  = {}'.format(plaintext))
        ciphertext = sdes.encrypt(plaintext,'OFB')
        print('ciphertext = {}'.format(ciphertext))
        plaintext2 = sdes.decrypt(ciphertext,'OFB')
        print('plaintext2 = {}'.format(plaintext2))
        print()
        
    print('End of SDES OFB Mode Testing')
    print('{}'.format('-'*40))
    print()
    return

test_sbox()
test_feistel()
test_ECB()
test_CBC()
test_OFB()