import utilities
from mod import MOD
from copy import deepcopy

class PRNG:
    """
    ----------------------------------------------------
    Description: Pseudo random number generators
    ----------------------------------------------------
    """
    PRIMES_FILE = 'primes.txt'
    
    @staticmethod
    def LFSR(feedback, IG, bits):
        """
        ----------------------------------------------------
        Parameters:   feedback (str): a binary number representing feedback equation
                      IG (str): a binary number representing initial configuration state
                      bits (int): number of bits to generate
        Return:       output (str): random binary bits
        Description:  Linear Feedback Shift Register
                      Used for generating random bits
                      feedback binary maps to feedback equation
                          Example 1: feedback = '01001'
                              0*b5 + 1*b4 + 0*b3 + 0*b2 + 1*b1
                          Example 2: feedback = '0101'
                              0*b4 + 1*b3 + 0*b2 + 1*b1
                      Number of bits in feedback and IG should be equal
                      If invalid input --> return error message
        ---------------------------------------------------
        """ 
        # check for valid input
        valid = utilities.is_binary(feedback) and utilities.is_binary(IG) and len(feedback) == len(IG) and bits>0
        if not valid:
            return "Error(PRNG.LFSR): invalid input"
        
        output = ""
        registers = []
        for f in IG:
            registers.append(f)
        counter = 0
        old_registers = []
        
        while counter<bits:
            num = 0
            old_registers = registers.copy()
            #shift over registers
            for i in range(len(registers)-1,0,-1):
                registers[i] = registers[i-1]
            #compute first index
            for i in range(len(feedback)):
                num += int(feedback[i]) * int(old_registers[i])
                if num==2:
                    num = 0
                
            registers[0] = num
            output+=str(old_registers[-1])
            
            counter+=1
            
        
        return output

    @staticmethod
    def BBS(p, q, bits):
        """
        ----------------------------------------------------
        Parameters:   p (int): a prime number
                      q (int): a prime number
                      bits (int): number of bits to generate
        Return:       output (str): random binary bits
        Description:  Blum Blum Shub PRNG Generator
                      p and q should be primes congruent to 3
                      The seed is the nth prime number, where n = p*q
                      If the nth prime number is not relatively prime with n,
                          the next prime number is selected until a valid one is found
                          The prime numbers are read from the file PRIMES_FILE (starting n=1)
                      If invalid input --> return error message
        ---------------------------------------------------
        """ 
        output = ""
        if not isinstance(bits,int) or bits<=0:
            return "Error(PRNG.BBS): invalid bits"
        elif not isinstance(p,int) or p<=0 or (3-p)%4!=0:
            return "Error(PRNG.BBS): invalid p"
        elif not isinstance(q,int) or q<=0 or (3-q)%4!=0:
            return "Error(PRNG.BBS): invalid q"
        #check for congruence
        n=p*q
        
        #get the nth prime number from primes file
        primes = utilities.file_to_text("primes.txt").split("\n")
        i=n
        while not MOD.is_relatively_prime(n, primes[i]):
            i+=1
        x = int(primes[i-1])
        mod = MOD()
        counter = 1
        
        mod.set_mod(n)
        mod.set_value(x**2)
        x0 = mod.get_residue()
        #output+=str(x0)
        while counter<=bits:
            mod.set_value(x0**2)
            xi = mod.get_residue()
            x0 = xi
            bi = xi%2
            output+=str(bi)
            
            counter+=1
        
        
        
        return output
