"""
-----------------------------
CP460 (Fall 2021)
Name: Maxwell Dann
ID:   190274440
Assignment 7
-----------------------------
"""

"""Put any comments to the grader here"""

import utilities
from mod import MOD
from prng import PRNG
from copy import deepcopy


class SBOX:
    """
    ----------------------------------------------------
    Description: SDES SBOX
    ----------------------------------------------------
    """

    def __init__(self, filename=''):
        """
        ----------------------------------------------------
        Parameters:   _box (list): default value = [[],[]]
                      _size (int): #bits for input, default = 0
        Description:  Creates an SBOX from a given file
                      The contents of the file are read into a 2D list
                      The size represent #bits for the sbox input
                      Note that the output #bits is (size - 1)
        ---------------------------------------------------
        """
        self._box = [[], []]
        self._size = 0
        if filename != "":
            self._box, self._size = self.file_to_box(filename)
                
    def file_to_box(self, filename):
        contents = utilities.file_to_text(filename).split("\n")
        # find size
        counter = 0
        while contents[0][counter] != "-":
            counter += 1
        size = counter + 1
        
        box = utilities.new_matrix(2, int((len(contents[0]) + 1) / 4), 0)
        temp = ""
        r = 0
        c = 0
        for i in range(len(contents) - 1):
            for j in range(len(contents[i])):
                if contents[i][j] != "-" and len(temp) < size - 1:
                    temp += contents[i][j]
                else:
                    box[r][c] = temp
                    temp = ""
                    c += 1
            box[r][c] = temp
            temp = ""
            r += 1
            c = 0
        return box, size
    
    def is_empty(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       True/False
        Description:  Check if current sbox is empty
        ---------------------------------------------------
        """ 
        return self._box == [[], []]
    
    def get_box(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       box (list)
        Description:  Returns a copy of _box
        ---------------------------------------------------
        """ 
        return deepcopy(self._box)
    
    def get_size(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       size (int)
        Description:  Returns a copy of current sbox size
        ---------------------------------------------------
        """ 
        return deepcopy(self._size)
    
    @staticmethod
    def valid_box(box):
        """
        ----------------------------------------------------
        Parameters:   box (?)
        Return:       True/False
        Description:  Check if given output is a valid box
                      A valid box is a 2D list, composing of 2 rows
                      Both rows have same #columns
                      All items in the 2D list are binary numbers of
                          equal number of bits
        ---------------------------------------------------
        """ 
        valid = True
        if not isinstance(box, list):
            valid = False
        elif len(box) != 2:
            valid = False
        elif len(box[0]) != len(box[1]):
            valid = False
        elif not isinstance(box[0][0], str):
            valid = False
        else:
            # check to make sure all numbers are binary and have the same number of bits
            size = len(box[0][0])
            for i in range(len(box)):
                for j in range(len(box[i])):
                    if not utilities.is_binary(box[i][j]) or len(box[i][j]) != size:
                        valid = False
                        break
        return valid
    
    def set_box(self, filename):
        """
        ----------------------------------------------------
        Parameters:   filename (str)
        Return:       success: True/False
        Description:  Read contents of a file into _box
                      file is formatted as:
                        <item[0][0]>-<item[0][1]>-...-<item[0][n-1]>
                        <item[1][0]>-<item[1][1]>-...-<item[1][n-1]>
                      where n is the size
                      if successful, values of _box and _size are updated
                      otherwise, no changes are applied to _box and _size
        ---------------------------------------------------
        """ 
        box, size = self.file_to_box(filename)
        valid = SBOX.valid_box(box)
        if valid:
            self._box = box
            self._size = size
        return valid
    
    def substitute(self, value):
        """
        ----------------------------------------------------
        Parameters:   value (str): sbox input (binary num of size bits)
        Return:       result (str): sbox output (binary num of size-1 bits)
        Description:  substitute <value> to corresponding output in sbox
                      if invalid input return ''
        ---------------------------------------------------
        """ 
        if not isinstance(value, str) or not len(value) == 4 or not utilities.is_binary(value):
            return ""
        # first bit is row number
        row = int(value[0])
        # find corresponding value
        val = utilities.bin_to_dec(value[1:])
        
        box = self.get_box()
        replacement = ""

        if not self.is_empty():
            replacement = box [row][val]
        
        return replacement
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of SBOX object
                      format:
                      SBOX(<size>):
                      <_box[0]>
                      <_box[1]>
        ---------------------------------------------------
        """ 
        if self._box != [[]]:
            output = "SBOX({}):\n{}\n{}".format(self._size, self._box[0], self._box[1])
        else:
            output = "SBOX(0):\n[]\n[]"
        return output


class SDES:
    DEFAULT_ENCODING = 'B6'
    DEFAULT_BLOCK_SIZE = 12
    DEFAULT_KEY_LENGTH = 9
    DEFAULT_ROUNDS = 2
    DEFAULT_P = 103
    DEFAULT_Q = 199
    DEFAULT_SBOX1 = SBOX('sbox1.txt')
    DEFAULT_SBOX2 = SBOX('sbox2.txt')
    DEFAULT_PAD = 'Q'

    def __init__(self):
        """
        ----------------------------------------------------
        Parameters:   _rounds (int)
                      _key_length (int)
                      _block_size (int)
                      _encoding (str): set to B6
                      _p (int)
                      _q (int)
                      _sbox1 (SBOX)
                      _sbox2 (SBOX)
                      _pad (str)
        Description:  Constructs an SDES object
                      Al parameters are set to default values
        ---------------------------------------------------
        """
        self._rounds = self.DEFAULT_ROUNDS
        self._key_length = self.DEFAULT_KEY_LENGTH
        self._block_size = self.DEFAULT_BLOCK_SIZE
        self._encoding = self.DEFAULT_ENCODING
        self._p = self.DEFAULT_P
        self._q = self.DEFAULT_Q
        self._sbox1 = self.DEFAULT_SBOX1
        self._sbox2 = self.DEFAULT_SBOX2
        self._pad = self.DEFAULT_PAD
        
    def get_value(self, parameter):
        """
        ----------------------------------------------------
        Parameters:   parameter (str)
        Return:       value (?)
        Description:  Returns a copy of parameter value
                      Valid parameter names:
                      rounds, key_length, block_size
                      encoding, p, q, sbox1, sbox2, pad
                      if invalid parameter name --> print error msg & return ''
        ---------------------------------------------------
        """
        result = ""
        if parameter == "rounds":
            result = deepcopy(self._rounds)
        elif parameter == "key_length":
            result = deepcopy(self._key_length)
        elif parameter == "block_size":
            result = deepcopy(self._block_size)
        elif parameter == "encoding":
            result = deepcopy(self._encoding)
        elif parameter == "p":
            result = deepcopy(self._p)
        elif parameter == "q":
            result = deepcopy(self._q)
        elif parameter == "sbox1":
            result = deepcopy(self._sbox1)
        elif parameter == "sbox2":
            result = deepcopy(self._sbox2)
        elif parameter == "pad":
            result = deepcopy(self._pad)
        return result
    
    def set_parameter(self, parameter, value):
        """
        ----------------------------------------------------
        Parameters:   parameter (str)
                      value (?)
        Return:       success: True/False
        Description:  Set the given parameter to given value (if valid)
                      if invalid value, do not update current value
                      if invalid parameter name, print error msg and return ''
                      rounds should be an integer larger than 1
                      p and q should be integers congruent to 3 mod 4
                      pad should be a single character string in B6 encoding
                      sbox1 and sbox2 should be non-empty SBOX objects
                      block_size should be an integer of multiples of 2, >= 4
                          sets also key_length to block_size//2 + 3
                      cannot set key_length
                      If invalid value, return False
                      if invalid parameter name, print error msg and return False
        ---------------------------------------------------
        """
        valid = True
        if parameter == "rounds":
            if not isinstance(value, int) or value < 1:
                valid = False
                print("Error (set_parameter_: Invalid input")
            else:
                self._rounds = value
        elif parameter == "block_size":
            if not isinstance(value, int) or value % 2 != 0 or value < 4:
                valid = False
                print("Error (set_parameter_: Invalid input")
            else:
                self._key_length = value // 2 + 3
        elif parameter == "p":
            if not isinstance(value, int) or (value - 3) % 4 != 0:
                valid = False
                print("Error (set_parameter_: Invalid input")
            else:
                self._p = value
        elif parameter == "q":
            if not isinstance(value, int) or (value - 3) % 4 != 0:
                valid = False
                print("Error (set_parameter_: Invalid input")
            else:
                self._q = value
        elif parameter == "sbox1":
            if not isinstance(value, SBOX) or value.is_empty():
                valid = False
                print("Error (set_parameter_: Invalid input")
            else:
                self._sbox1 = value
        elif parameter == "sbox2":
            if not isinstance(value, SBOX) or value.is_empty():
                valid = False
                print("Error (set_parameter_: Invalid input")
            else:
                self._sbox2 = value
        elif parameter == "pad":
            base = utilities.get_base("B6")
            if not isinstance(value, str) or len(value) != 1 or value not in base:
                valid = False
                print("Error (set_parameter_: Invalid input")
            else:
                self._pad = value
        return valid

    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str): binary number
        Description:  Returns a copy of SDES key
                      The key is generated by Blum Blum Shub algorithm
                      Uses p and q to generates key_length bits
        ---------------------------------------------------
        """
        prng = PRNG()
        
        #key = "111000111"
        key = prng.BBS(self._p, self._q, self._key_length)
        return key
    
    def get_subkey(self, i):
        """
        ----------------------------------------------------
        Parameters:   i (int): subkey index
        Return:       subkey (str): binary number
        Description:  Returns the ith subkey from SDES key
                      Gets key_length bits from key starting at index i
                      Using circular indexing if necessary
        Errors:       if invalid i --> return ''
        ---------------------------------------------------
        """
        # generate the key starting at the ith index and wrapping if necessary
        subkey = ""
        key = self.get_key()
        counter = 0
        while counter < 8:
            if i == len(key):
                i = 0
            subkey += key[i]
            i += 1
            counter+=1
        
        return subkey
        
    def expand(self, R):
        """
        ----------------------------------------------------
        Parameters:   R (str): binary number of size (block_size/2)
        Return:       R_exp (str): output of expand function
        Description:  Expand the input binary number by adding two digits
                      Expansion works as the following:
                      If the index of the two middle elements is i and i+1
                          indices 0 up to i-1: same order
                          middle becomes: R(i+1)R(i)R(i+1)R(i)
                          indices R(i+2) to the end: same order
                      No need to validate that R is of size block_size/2
        Errors:       if R is an invalid binary number -->  return ''
        ---------------------------------------------------
        """
        result = ""
        if utilities.is_binary(R):
            middle = len(R) // 2 - 1
            if middle > 0:
                result = R[:middle] + R[middle + 1] + R[middle] + R[middle + 1] + R[middle] + R[middle + 2:]
        return result
    
    def F(self, Ri, ki):
        """
        ----------------------------------------------------
        Parameters:   Ri (str): block of binary numbers
                      ki (str): binary number representing subkey
        Return:       Ri2 (str): block of binary numbers
        Description:  Performs the following five tasks:
                      1- Pass the Ri block to the expander function
                      2- Xor the output of [1] with ki
                      3- Divide the output of [2] into two equal sub-blocks
                      4- Pass the most significant bits of [3] to Sbox1
                         and least significant bits to sbox2
                      5- Concatenate the output of [4] as [sbox1][sbox2]
        Errors:       if ki or Ri is an invalid binary number --> return ''
        ---------------------------------------------------
        """
        result = ""
        if isinstance(Ri, str) and isinstance(ki, str) and utilities.is_binary(Ri) and utilities.is_binary(ki):
            sbox1 = self.get_value("sbox1")
            sbox2 = self.get_value("sbox2")
            
            step1 = self.expand(Ri)
            if len(step1)==len(ki):
                step2 = str(self.xor(step1, ki))
                step3_first = step2[:len(step2) // 2]
                step3_second = step2[len(step2) // 2:]
                
                step4_first = sbox1.substitute(step3_first)
                step4_second = sbox2.substitute(step3_second)
                
                result = step4_first + step4_second
        return result
    
    def xor(self,a,b):
        decimal = ""
        for i in range(len(a)):
            if a[i]==b[i]:
                decimal+='0'
            else:
                decimal+='1'
        return decimal

    def feistel(self, bi, ki):
        """
        ----------------------------------------------------
        Parameters:   bi (str): block of binary numbers
                      ki (str): binary number representing subkey
        Return:       bi2 (str): block of binary numbers
        Description:  Applies Feistel Cipher on a block of binary numbers
                      L(current) = R(previous)
                      R(current) = L(previous) xor F(R(previous), subkey)
        Errors:       if ki or bi is an invalid binary number --> return ''
        ---------------------------------------------------
        """
        bi2 = ""
        if isinstance(bi,str) and isinstance(ki,str) and utilities.is_binary(bi) and utilities.is_binary(ki):
            mid = len(bi)//2
            l2 = bi[mid:]
            l1 = bi[:mid]
            f = self.F(l2,ki)
            if len(f)==len(l1):
                r2 = self.xor(l1,f)
                bi2 = l2+r2
        return bi2
    
    def encrypt(self, plaintext, mode):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
                      mode (str)
        Return:       ciphertext (str)
        Description:  A dispatcher SDES encryption function
                      passes the plaintext to the proper function based on given mode
                      Works for ECB, CBC and OFB modes
        Errors:       if undefined mode --> return ''
        ---------------------------------------------------
        """
        ciphertext = ""
        if mode=="ECB":
            ciphertext = self._encrypt_ECB(plaintext)
        elif mode == "CBC":
            ciphertext = self._encrypt_CBC(plaintext)
        elif mode == "OFB":
            ciphertext = self._encrypt_OFB(plaintext)
        return ciphertext
    
    def decrypt(self, ciphertext, mode):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
                      mode (str)
        Return:       plaintext (str)
        Description:  A dispatcher SDES decryption function
                      passes the ciphertext to the proper function based on given mode
                      Works for ECB, CBC and OFB modes
        Errors:       if undefined mode --> return ''
        ---------------------------------------------------
        """
        plaintext = ""
        if mode=="ECB":
            plaintext = self._decrypt_ECB(ciphertext)
        elif mode == "CBC":
            plaintext = self._decrypt_CBC(ciphertext)
        elif mode == "OFB":
            plaintext = self._decrypt_OFB(ciphertext)
        return plaintext
    
    def _encrypt_ECB(self, plaintext):
        #remove unwanted base chars
        base = utilities.get_base("B6")
        all = utilities.get_base("all")
        base_to_remove = ""
        for a in all:
            if a not in base:
                base_to_remove+=a
                
        positions = utilities.get_positions(plaintext, base_to_remove)
        plaintext = utilities.clean_text(plaintext, base_to_remove)
        ciphertext = ""
        
        #each character corresponds to 6 binary numbers, add them to blocks
        blocks = []
        curr_block = ""
        block_size = self.get_value("block_size")
        pad = self.get_value("pad")
        
        for i in range (len(plaintext)):
            curr_block+=utilities.encode(plaintext[i],"B6")
            if len(curr_block)==block_size:
                blocks.append(curr_block)
                curr_block = ""
            #pad the last block if need be
            elif i==len(plaintext)-1 and len(curr_block)!=block_size:
                curr_block+=utilities.encode(pad,"B6")
                blocks.append(curr_block)
            
        rounds = self.get_value("rounds")
        j=0
        
        #run fiestal for multiple rounds    
        for i in range(len(blocks)): 
            curr = ""
            prev = blocks[i]
            j=0
            while j<rounds:
                key = self.get_subkey(j)
                curr = self.feistel(prev, key)
                prev = curr
                j+=1
            #swap on last round
            mid = len(curr)//2
            first = utilities.decode(curr[mid:],"B6")
            second = utilities.decode(curr[:mid],"B6")
            #add decoded block to ciphertext
            curr = first+second
            ciphertext+=curr
        
        ciphertext = utilities.insert_positions(ciphertext, positions)
        return ciphertext
    
    def _decrypt_ECB(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  SDES decryption using ECB mode
        ---------------------------------------------------
        """
        #remove unwanted base chars
        base = utilities.get_base("B6")
        all = utilities.get_base("all")
        base_to_remove = ""
        for a in all:
            if a not in base:
                base_to_remove+=a
                
        positions = utilities.get_positions(ciphertext, base_to_remove)
        ciphertext = utilities.clean_text(ciphertext, base_to_remove)
        plaintext = ""
        
        #each character corresponds to 6 binary numbers, add them to blocks
        blocks = []
        curr_block = ""
        block_size = self.get_value("block_size")
        pad = self.get_value("pad")
        
        for i in range (len(ciphertext)):
            curr_block+=utilities.encode(ciphertext[i],"B6")
            if len(curr_block)==block_size:
                blocks.append(curr_block)
                curr_block = ""
            #pad the last block if need be
            elif i==len(ciphertext)-1 and len(curr_block)!=block_size:
                curr_block+=utilities.encode(pad,"B6")
                blocks.append(curr_block)
                
            
            
        rounds = self.get_value("rounds")
        j=0
        
        #run fiestal for multiple rounds    
        for i in range(len(blocks)): 
            curr = ""
            prev = blocks[i]
            j=rounds
            while j>0:
                key = self.get_subkey(j-1)
                curr = self.feistel(prev, key)
                prev = curr
                j-=1
            #swap on last round
            mid = len(curr)//2
            first = utilities.decode(curr[mid:],"B6")
            second = utilities.decode(curr[:mid],"B6")
            #add decoded block to ciphertext
            curr = first+second
            plaintext+=curr
        
        #strip pad if need be
        while plaintext[-1]==pad:
            plaintext = plaintext[:-1]
        plaintext = utilities.insert_positions(plaintext, positions)
        return plaintext

    def _encrypt_CBC(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  SDES encryption using CBC mode
        ---------------------------------------------------
        """ 
        #remove unwanted base chars
        base = utilities.get_base("B6")
        all = utilities.get_base("all")
        base_to_remove = ""
        for a in all:
            if a not in base:
                base_to_remove+=a
                
        positions = utilities.get_positions(plaintext, base_to_remove)
        plaintext = utilities.clean_text(plaintext, base_to_remove)
        ciphertext = ""
        
        #each character corresponds to 6 binary numbers, add them to blocks
        blocks = []
        blocks.append(self.get_IV())
        curr_block = ""
        block_size = self.get_value("block_size")
        pad = self.get_value("pad")
        
        for i in range (len(plaintext)):
            curr_block+=utilities.encode(plaintext[i],"B6")
            if len(curr_block)==block_size:
                blocks.append(curr_block)
                curr_block = ""
            #pad the last block if need be
            elif i==len(plaintext)-1 and len(curr_block)!=block_size:
                curr_block+=utilities.encode(pad,"B6")
                blocks.append(curr_block)
            
        rounds = self.get_value("rounds")
        j=0
        #xor current block with previous block and run feistal on it
        for i in range(1,len(blocks)):
            prev = str(self.xor(blocks[i-1],blocks[i]))
            curr = ""
            j=0
            while j<rounds:
                key = self.get_subkey(j)
                curr = self.feistel(prev, key)
                prev = curr
                j+=1
            #swap on last round
            mid = len(curr)//2
            #update current block to encrypted block
            blocks[i] = curr[mid:]+curr[:mid]
            #add decoded block to ciphertext
            first = utilities.decode(curr[mid:],"B6")
            second = utilities.decode(curr[:mid],"B6")
            curr = first+second
            ciphertext+=curr
            
        
        ciphertext = utilities.insert_positions(ciphertext, positions)
        return ciphertext
    

    def get_IV(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       iv (str): binary number
        Description:  prepares an IV for CBC and OFB modes
                      see PDF for instructions
        ---------------------------------------------------
        """ 
        prng = PRNG()
        bits = self.get_value("block_size")
        registers = self.get_value("key_length")//2
        c = ""
        i = 0
        while i<registers:
            if i%2==0:
                c+="0"
            else:
                c+="1"
            i+=1
        IG = utilities.dec_to_bin(self.get_value("key_length"))
        IV = prng.LFSR(c, IG, bits)
        return IV

    def _decrypt_CBC(self, ciphertext): 
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  SDES decryption using CBC mode
        ---------------------------------------------------
        """     
        #remove unwanted base chars
        base = utilities.get_base("B6")
        all = utilities.get_base("all")
        base_to_remove = ""
        for a in all:
            if a not in base:
                base_to_remove+=a
                
        positions = utilities.get_positions(ciphertext, base_to_remove)
        ciphertext = utilities.clean_text(ciphertext, base_to_remove)
        plaintext = ""
        
        #each character corresponds to 6 binary numbers, add them to blocks
        blocks = []
        blocks.append(self.get_IV())
        curr_block = ""
        block_size = self.get_value("block_size")
        pad = self.get_value("pad")
        
        for i in range (len(ciphertext)):
            curr_block+=utilities.encode(ciphertext[i],"B6")
            if len(curr_block)==block_size:
                blocks.append(curr_block)
                curr_block = ""
            #pad the last block if need be
            elif i==len(ciphertext)-1 and len(curr_block)!=block_size:
                curr_block+=utilities.encode(pad,"B6")
                blocks.append(curr_block)
                
            
            
        rounds = self.get_value("rounds")
        j=0
        
        #run fiestal for multiple rounds    
        for i in range(1,len(blocks)): 
            curr = ""
            prev = blocks[i]
            j=rounds
            while j>0:
                key = self.get_subkey(j-1)
                curr = self.feistel(prev, key)
                prev = curr
                j-=1
            #swap on last round
            mid = len(curr)//2
            curr = curr[mid:] + curr[:mid]
            #xor with key (or IV if first round)
            curr = self.xor(curr,blocks[i-1])
            #swap halves
            curr = curr[mid:]+curr[:mid]
            #add decoded block to ciphertext
            first = utilities.decode(curr[mid:],"B6")
            second = utilities.decode(curr[:mid],"B6")
            plaintext+=(first+second)
        
        #strip pad if need be
        while plaintext[-1]==pad:
            plaintext = plaintext[:-1]
        plaintext = utilities.insert_positions(plaintext, positions)
        return plaintext


    def _encrypt_OFB(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  SDES encryption using OFB mode
        ---------------------------------------------------
        """      
        #remove unwanted base chars
        base = utilities.get_base("B6")
        all = utilities.get_base("all")
        base_to_remove = ""
        for a in all:
            if a not in base:
                base_to_remove+=a
                
        positions = utilities.get_positions(plaintext, base_to_remove)
        plaintext = utilities.clean_text(plaintext, base_to_remove)
        ciphertext = ""
        
        #each character corresponds to 6 binary numbers, add them to blocks
        blocks = []
        nonce = self.get_IV()
        nonces = []
        nonces.append(nonce)
        curr_block = ""
        block_size = self.get_value("block_size")
        
        for i in range (len(plaintext)):
            curr_block+=utilities.encode(plaintext[i],"B6")
            if len(curr_block)==block_size:
                blocks.append(curr_block)
                curr_block = ""
            #add the last block regardless of whether it is the correct length
            elif i==len(plaintext)-1:
                blocks.append(curr_block)
            
        rounds = self.get_value("rounds")
        j=0
        
        #encrypt nonce and key, xor this with plainblock to get cipherblock
        for i in range(len(blocks)):
            prev = nonces[i]
            curr = ""
            j=0
            while j<rounds:
                key = self.get_subkey(j)
                curr = self.feistel(prev, key)
                prev = curr
                j+=1
            #swap on last round
            mid = len(curr)//2
            curr = curr[mid:]+curr[:mid]
            nonces.append(curr)
            #xor with plainblock
            if len(blocks[i])!=len(curr):
                #last char, pad front with 0s
                curr = self.xor(curr[:len(curr)//2],blocks[i])
                curr = utilities.decode(curr,"B6")
            else:
                curr = self.xor(curr,blocks[i])
                second = utilities.decode(curr[mid:],"B6")
                first = utilities.decode(curr[:mid],"B6")
                curr = first+second
            ciphertext+=curr
            
        
        ciphertext = utilities.insert_positions(ciphertext, positions)
        return ciphertext

    def _decrypt_OFB(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  SDES decryption using OFB mode
        ---------------------------------------------------
        """
        plaintext = self._encrypt_OFB(ciphertext)
        return plaintext
