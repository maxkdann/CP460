"""
-----------------------------
CP460 (Fall 2021)
Name: Maxwell Dann
ID:   190274440
-----------------------------
"""

"""Put any comments to the grader here"""

import utilities
from mod import MOD
from copy import deepcopy


class Matrix:

    def __init__(self, r=0, c=0, fill=0):
        """
        ----------------------------------------------------
        Parameters:   _matrix (list): default = []
        Description:  Matrix constructor
                      sets _matirx using Matrix.create(r,c,fill)
        ---------------------------------------------------
        """
        self._matrix = self.create(r, c, fill)
        
    def get_matrix(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       matrix (list)
        Description:  returns a copy of the current matrix as a list
        ---------------------------------------------------
        """
        return deepcopy(self._matrix)
    
    def get_size(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       r (int): number of rows
                      c (int): number of columns
        Description:  returns the size of the current matrix, i.e.,
                        #rows and #columns
        ---------------------------------------------------
        """
        matrix = self.get_matrix()
        if matrix == []:
            r = 0
            c = 0
        elif isinstance(matrix[0], int):
            r = 1
            c = len(matrix)
        else:
            r = len(matrix)
            c = len(matrix[0])
        return r, c
    
    def valid_index(self, i=-1, j=-1):
        '''
        checks if i, j is a valid index for matrix
        '''
        matrix = self.get_matrix()
        valid = True
        # check if matrix is one dimensional 
        if not isinstance(matrix[0], list):
            if j != -1 and j != 0:
                valid = False
            elif i > len(matrix) or i * -1 > (len(matrix) - 1):
                valid = False
        else:  # matrix is 2d
            if i >= len(matrix) or -1 * i > len(matrix):
                valid = False
            elif j >= len(matrix[0]) or -1 * j > len(matrix[0]):
                valid = False
        return valid

    def get_row(self, i):
        """
        ----------------------------------------------------
        Parameters:   i (int): row number
        Return:       row (list): the ith row
        Description:  returns a copy of the ith row in the matrix
                      Supports positive values: 0 to r-1
                               negative values: -1 to -r
        Errors:       if invalid i, print error message and return ''
        ---------------------------------------------------
        """
        matrix = self.get_matrix()
        if matrix == [] or not self.valid_index(i, -1):
            print("Error(Matrix.get_row): index out of range")
            return ""
        return matrix[i]
    
    def get_column(self, j):
        """
        ----------------------------------------------------
        Parameters:   j (int): column number
        Return:       column (list): the ith column
        Description:  returns a copy of the ith column in the matrix
                      Supports positive values: 0 to c-1
                               negative values: -1 to -c
        Errors:       if invalid i, print error message and return ''
        ---------------------------------------------------
        """
        matrix = self.get_matrix()
        c = []
        if matrix == [] or not self.valid_index(-1, j):
            print("Error(Matrix.get_column): index out of range")
            return ""
        for i in range(len(matrix)):
            c.append([matrix[i][j]])
        return c
        
    def get_item(self, i, j):
        """
        ----------------------------------------------------
        Parameters:   i (int): row number
                      j (int): column number
        Return:       column (list): the ith column
        Description:  returns a copy of item [i][j] in the matrix
                      Supports positive and negative values for i and j
        Errors:       if invalid i, print error message and return ''
        ---------------------------------------------------
        """
        matrix = self.get_matrix()
        if matrix == [] or not self.valid_index(i, j):
            print("Error(Matrix.get_item): index out of range")
            return ""
        elif j == -1:
            return matrix[i]
        else:
            return matrix[i][j]
    
    def is_empty(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       True/False
        Description:  checks if the current matrix is empty
        ----------------------------------------------------
        """
        matrix = self.get_matrix()
        return len(matrix) == 0
    
    def is_vector(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       True/False
        Description:  checks if the current matrix is a vector
        ----------------------------------------------------
        """
        matrix = self.get_matrix()
        if matrix == []:
            return True
        elif isinstance(matrix[0], list):
            return False
        return True
    
    def is_square(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       True/False
        Description:  Check if current matrix is square
                        #rows equal to #columns
        ---------------------------------------------------
        """
        matrix = self.get_matrix()
        if matrix == []:
            return True
        return len(matrix) == len(matrix[0])

    def is_identity(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       True/False
        Description:  Check if current matrix is an identity matrix
                      Diagonal elements [from top left to bottom right] = 1
                      All other elements = 0
        ---------------------------------------------------
        """
        matrix = self.get_matrix()
        identity = True
        if matrix == []:
            identity = False
        for i in range(len(matrix)):
            for j in range(len(matrix[0])):
                if i == j and matrix[i][j] != 1:
                    identity = False
                elif i != j and matrix[i][j] != 0:
                    identity = False
        return identity

    @staticmethod
    def to_matrix(list1):
        """
        ----------------------------------------------------
        Parameters:   list1: a list representing a matrix
        Return:       m: a Matrix objectc
        Description:  Creates a matrix object that has same items as list1
                      if list1 is not a valid matrix: 
                          return empty Matrix object
        ---------------------------------------------------
        """
        valid = Matrix.valid_matrix(list1)
        
        if not valid or list1 == []:
            return Matrix(0, 0, 0)
        elif not isinstance(list1[0], list):
            m = Matrix(1, len(list1), 0)
            for i in range(len(list1)):
                m.set_item(i, -1, list1[i])
            return m
        r = len(list1)
        c = len(list1[0])
        matrix = Matrix(r, c, 0)
        for i in range(r):
            for j in range(c):
                matrix.set_item(i, j, list1[i][j])
        return matrix
        
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      a Matrix object
                      output format:
                      if empty or vecotr: print _matrix
                      Otherwise, print each row in a separate line
        ---------------------------------------------------
        """
        output = ""
        empty = self.is_empty()
        vector = self.is_vector()
        if empty or vector:
            output = str(self._matrix)
        else:
            matrix = self._matrix
            for i in range(len(self._matrix)):
                output += str(matrix[i])
                if i < len(self._matrix) - 1:
                    output += '\n'
        return output
    
    def to_list(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       matrix (list)
        Description:  Converts a Matrix object to a list
                      Same as get_matrix()
        ---------------------------------------------------
        """
        
        return self._matrix
    
    def set_matrix(self, A):
        """
        ----------------------------------------------------
        Parameters:   A (list or Matrix)
        Return:      True/False
        Description:  sets _matrix data member by the given A
                      parameter A can be a list or a Matrix
                      Before setting, ensure it is a valid matrix
                      if invalid input --> print error message and return False
        ---------------------------------------------------
        """
        valid = Matrix.valid_matrix(A)
        if not valid:
            p = False
            if isinstance(A, list):
                t = type(A[0])
                for v in A:
                    if type(v) != t:
                        print("Error(Matrix.set_matrix): invalid input")
                        p = True
                        break
            if not p:
                print("Error(Matrix.set_matrix): unsupported matrix size")
        else:
            self._matrix = A
        
        return valid
    
    def set_item(self, i, j, value):
        """
        ----------------------------------------------------
        Parameters:   i (int): row number
                      j (int): column number
                      value (int)
        Return:      True/False
        Description:  sets _matrix[i][j] to given value
                      supports positive and negative values of i and j
                      if invalid input, print error msg and return False
        ---------------------------------------------------
        """
        matrix = self.get_matrix()
        if matrix == [] or not self.valid_index(i, j):
            print("Error(Matrix.set_item): index out of range")
            return False
        else:
            if not isinstance(matrix[0], list):
                self._matrix[i] = value
            else:
                self._matrix[i][j] = value
        return True
    
    @staticmethod
    def valid_vector(A):
        """
        ----------------------------------------------------
        Parameters:   A (any input)
        Return:       True/False
        Description:  checks if the given input is a valid vector
                      A valid vector is a list in which all elements are integers
                      An empty list is a valid vector
                      Note: a matrix with a vertical vector (one item in each row)
                          is NOT a valid vector
        ----------------------------------------------------
        """
        valid = True
        if not isinstance(A, list):
            valid = False
        elif A == [[]]:
            valid = False
        elif A != [] and len(A) != 1: 
            for v in A:
                if not isinstance(v, int):
                    valid = False
        return valid

    @staticmethod
    def valid_matrix(A):
        """
        ----------------------------------------------------
        Parameters:   A (any input)
        Return:       True/False
        Description:  checks if the given input is a valid matrix
                      A valid matrix is any object of type Matrix, or 
                      a 2D list that fits matrix properties
                      A matrix is a list in which all elements are valid vectors of equal size
                      Any valid vector is also a valid matrix
        ----------------------------------------------------
        """        
        valid = True
        if type(A) == Matrix or A == []:
            return True
        elif not isinstance(A, list):
            valid = False
        else:
            # need to check sizes
            if isinstance(A[0], list):
                size = len(A[0])
                # loop through vectors
                for v in A:
                    if not Matrix.valid_vector(v) or len(v) != size or not isinstance(v, list):
                        valid = False
                        break;
        return valid
    
    @staticmethod
    def create(r=0, c=0, fill=0):
        """
        ----------------------------------------------------
        Parameters:   r: #rows (int)
                      c: #columns (int)
                      fill (?)
        Return:       matrix (2D List)
        Description:  Create a matrix (2D list not Matrix) of size r x c
                          All elements initialized to fill
                      if r or c is <= 0, return empty list
                      if r is 1 returns a vector (1D list)
                      Otherwise, returns a 2D list
        ---------------------------------------------------
        """
        matrix = []
        if r <= 0 or c <= 0:
            return matrix
        elif r == 1:
            matrix = [fill] * c
        else:
            matrix = [[fill] * c for i in range(r)]
        return matrix
    
    @staticmethod
    def I(size):
        """
        ----------------------------------------------------
        Parameters:   size (int): #rows = #columns in square matrix
        Return:       I (2D list): identity matrix
        Description:  returns the identity matrix of size:
                        size x size
                      The output is a 2D list (not a matrix object)
                      1 --> [1]
                      2 --> [[1,0],[0,1]]
        Errors:       if size is 0 or negative, print error message and return []
        ---------------------------------------------------
        """
        if size <= 0:
            print("Error(Matrix.get_I): invalid size")
            return []
        matrix = Matrix.create(size, size, 0)
        if size == 1:
            matrix = [1]
        else:
            for i in range(size):
                for j in range(size):
                    if i == j:
                        matrix[i][j] = 1
        return matrix
        
    @staticmethod
    def scalar_mul(constant, A):
        """
        ----------------------------------------------------
        Parameters:   c (int): scalar value
                      A (Matrix or list): an arbitrary matrix
        Return:       B (Matrix): result of c.A
        Description:  Performs scalar multiplication of c with A
                      A can be a Matrix object or a valid matrix list
                      The result is a Matrix object
        Errors:       if one of the inputs is invalid:
                        print error message and return empty Matrix object
        ---------------------------------------------------
        """
        matrix = A
        if matrix == [] or not isinstance(constant, int) or not isinstance(A, Matrix) and not isinstance(A, list):
            print("Error(Matrix.scalar_mul): invalid input")
            return Matrix(0, 0)
        if isinstance(matrix, list):
            if isinstance(matrix[0], list):
                r, c = len(matrix), len(matrix[0])
            else:
                r, c = 1, len(matrix)
        else:
            r, c = matrix.get_size()
            
        B = Matrix(r, c, 0)
        # if not isinstance(matrix, Matrix):
        #     matrix = Matrix.to_matrix(A)
        # to 1d mul
        if isinstance(matrix, Matrix):
            matrix = matrix.to_list()
                    
        if isinstance(matrix[0], int):
            for i in range(len(matrix)):
                B.set_item(i, -1, matrix[i] * constant)
        else:
            for i in range(len(matrix)):
                for j in range(len(matrix[i])):
                    B.set_item(i, j, matrix[i][j] * constant)
        return B
    
    @staticmethod
    def mul(A, B):
        """
        ----------------------------------------------------
        Parameters:   A (Matrix): an arbitrary Matrix object
                      B (Matrix): an arbitrary Matrix object
        Return:       C (Matrix): result of A x B
        Description:  Performs cross multiplication of c with A
                    
                      The result is a Matrix object
        Errors:       if one of the inputs is invalid or A(#columns) != B(#rows)
                        print error message and return empty Matrix object
        ---------------------------------------------------
        """
        if not isinstance(A, Matrix) or not isinstance(B, Matrix):
            print("Error(Matrix.mul): size mismatch")
            return Matrix(0, 0)
        elif len(A.get_matrix()) == 1 and len(B.get_matrix()) == 1:
            return Matrix(1, 1, A.get_matrix()[0] * B.get_matrix()[0])
        
        ra, ca = A.get_size()
        rb, cb = B.get_size()
        if ca != rb:
            print("Error(Matrix.mul): size mismatch")
            return Matrix(0, 0)
        # go down the cols of A and across the rows of B
        
        c = Matrix.create(ra, cb, 0)
        if len(c) == 1:
            for i in range(ca):
                c[0] += A.get_item(i, -1) * B.get_item(i, -1)[0]
        else: 
            for i in range(ra):
                for j in range(cb):
                    for k in range(rb):
                        c[i][j] += A.get_item(i, k) * B.get_item(k, j)
        C = Matrix()
        C.set_matrix(c)
        return C
    
    @staticmethod
    def mod(A, m):
        """
        ----------------------------------------------------
        Parameters:   A (Matrix): an arbitrary Matrix object
                      m (int): mod
        Return:       B (Matrix): output matrix
        Description:  Return a matrix which has same elements as A
                      but with residue values mod m
        Errors:       if one of the inputs is invalid or A is empty:
                        print error msg
                        return empty Matrix object
        ---------------------------------------------------
        """
        if not isinstance(A, Matrix) or not isinstance(m, int) or m == 0:
            print("Error(Matrix.mod): invalid input")
            return Matrix(0, 0)      
        
        matrix = A.get_matrix()
        mod = MOD()
        mod.set_mod(m)
        # check if 1d
        if not isinstance(matrix[0], list):
            for i in range(len(matrix)):
                mod.set_value(matrix[i])
                matrix[i] = mod.get_residue()
        else:
            for i in range(len(matrix)):
                for j in range(len(matrix[i])):
                    mod.set_value(matrix[i][j])
                    matrix[i][j] = mod.get_residue()
        M = Matrix()
        M.set_matrix(matrix)
        
        return M
    
    def det(self):
        """
        ----------------------------------------------------
        Parameters:   - 
        Return:       det (int): determinant
        Description:  Finds the determinant of current matrix
                      works only for 2x2 matrices
        Errors:       if current matrix is empty or non square, or
                      if size other than 2x2:
                        print error msg, return 0
        ---------------------------------------------------
        """
        matrix = self.get_matrix()
        det = 0
        if matrix == []:
            print("Error(Matrix.det): det does not exist")
        elif len(matrix) != 2: 
            print("Error(Matrix.det): unsupported matrix size")
        elif len(matrix[0]) != 2 or len(matrix[1]) != 2:
            print("Error(Matrix.det): det does not exist")
        else:
            # det = ad-bc
            det = matrix[1][1] * matrix[0][0] - matrix[0][1] * matrix[1][0]
        return det
    
    @staticmethod
    def inverse_mod(B, m):
        """
        ----------------------------------------------------
        Parameters:   A (Matrix): an arbitrary Matrix object
                      m (int): mod 
        Return:       B (Matrix): output matrix
        Description:  Finds the inverse of matrix A mod m
                      works only for 2x2 matrices
        Errors:       if invalid A or m, or invalid size, or inverse does not exist
                        return empty Matrix object
        ---------------------------------------------------
        """
        A = deepcopy(B)
        if not isinstance(A, Matrix) or not isinstance(m, int) or m <= 0:
            # print("Error(Matrix.inverse_mod): invalid input")
            return Matrix(0, 0)  
        r, c = A.get_size()
        if r != 2 or c != 2:
            return Matrix(0, 0)
       
        det = A.det()
        mod = MOD(det, m)
        det = mod.get_residue()
        mod.set_value(det)
        det_inverse = mod.get_mul_inv()
        if det_inverse == "NA":
            return Matrix(0, 0)
        
        a = A.get_item(0, 0)
        A.set_item(0, 0, A.get_item(1, 1))
        A.set_item(1, 1, a)
        A.set_item(0, 1, A.get_item(0, 1) * -1)
        A.set_item(1, 0, A.get_item(1, 0) * -1)
        m = Matrix.scalar_mul(det_inverse, A)
        
        # mod matrix
        for i in range(r):
            for j in range(c):
                mod.set_value(m.get_item(i, j))
                m.set_item(i, j, mod.get_residue())
        
        return m


class Hill:
    """
    ----------------------------------------------------
    Cipher name: Hill Cipher
    Key:         (keyword,start,end)
    Type:        Substitution Cipher
    Description: y = kx mod m
                 x = k(-1)y mod m
                 k is the matrix representation of keyword
                 base = BASE[start:end]
                 m = len(base)
                 Applies only to characters defined in the base
                 Applies only to key matrices of size 2x2
    ----------------------------------------------------
    """
    BASE = utilities.get_base('lower') + ' ' + utilities.get_base('nonalpha') + utilities.get_base('upper')
    DEFAULT_KEY = ('food', 0, 26)
    DEFAULT_PAD = 'q'
    
    def __init__(self, key=DEFAULT_KEY, pad=DEFAULT_PAD):
        """
        ----------------------------------------------------
        Parameters:   _key (tuple(Matrix,int,int)): (k,start,end)
        Description:  Hill cipher constructor
                      sets _key and _pad
        ---------------------------------------------------
        """
        self.key = key
        self.pad = pad

    @staticmethod
    def encode(keyword, base, size):
        """
        ----------------------------------------------------
        Parameters:   keyword (str): an arbitrary keyword
                      base (str): a sequence of unique characters
                      size (int): #columns in output matrix
        Return:       k (Matrix): matrix representation of the given key
        Description:  Takes a keyword and constructs a corresponding matrix
                      matrix items represent indices of keyword characters in base
                      The output matrix is always 2 x size
                      characters undefined in the base are removed from key
                      if keyword is too long, use first elements
                      if key is too short, use running key
                      if invalid key, matrix or size --> return empty Matrix
        ---------------------------------------------------
        """
        if size < 1:
            return Matrix(0, 0)
        k = Matrix(2, size, 0)
        i = 0
        filler = 0
        r = 0
        c = 0
        while filler < 2 * size:
            if c == size:
                r += 1
                c = 0
            if i >= len(keyword):
                i = 0
            if keyword[i] in base:
                k.set_item(r, c, base.index(keyword[i]))
                c += 1
                filler += 1
            i += 1
            
        return k

    @staticmethod
    def decode(matrix, base):
        """
        ----------------------------------------------------
        Parameters:   matrix (str): an arbitrary Matrix object
                      base (str): a sequence of unique characters
        Return:       keyword (str)
        Description:  Takes a square matrix and constructs a corresponding keyword
                      matrix items represent indices of keyword characters in base
                      The output is a string of length similar to #rows in matrix
                      if invalid matrix or base, return empty string
        ---------------------------------------------------
        """
        keyword = ""
        r, c = matrix.get_size()
        for i in range(r):
            for j in range(c):
                keyword += base[matrix.get_item(i, j)]
        return keyword
        
    def set_pad(self, pad):
        """
        ----------------------------------------------------
        Parameters:   pad (str): a padding character
        Return:       success: True/False
        Description:  Sets hill cipher pad to given character
                      a pad should be a single character from the base
                      if invalid pad, set to default value
        ---------------------------------------------------
        """ 
        base = self.get_base()
        valid = True
        if pad in base:
            self.pad = pad
        else:
            self.pad = Hill.DEFAULT_PAD
            valid = False
        return valid
    
    def get_pad(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       pad (str): current padding character
        Description:  Returns a copy of current padding character
        ---------------------------------------------------
        """ 
        return deepcopy(self.pad)

    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (Matrix,int,int)
        Description:  Returns a copy of the Hill cipher key
        ---------------------------------------------------
        """
        return deepcopy(self.key)
       
    def get_key_matrix(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       k (Matrix)
        Description:  Returns a matrix representation of the keyword
        ---------------------------------------------------
        """ 
        key = self.get_key()
        base = self.get_base()
        
        m = Hill.encode(key[0], base, 2)
        return m
    
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (k,start,end): tuple(Matrix, int,int)
        Return:       success: True/False
        Description:  Sets Hill cipher key to given key
                      if invalid key --> set to default key
        ---------------------------------------------------
        """ 
        valid = Hill.valid_key(key)
        if valid:
            self.key = key
        else:
            self.key = Hill.DEFAULT_KEY
        return valid

    def get_base(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       base (str)
        Description:  Returns a copy of the Hill base
                        which is a subset of BASE
        ---------------------------------------------------
        """
        key = self.get_key()
        return deepcopy(self.BASE[key[1]:key[2]])
        
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Hill cipher object. Used for testing
                      output format:
                      Hill Cipher:
                      key = <key>, pad = <pad>
        ---------------------------------------------------
        """
        key = self.get_key()
        output = "Hill Cipher:\nkey = {}, m = {}, pad = {}".format(key[0], key[2] - key[1], self.get_pad())
        return output
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Hill key
                      A valid key should be a tuple consisting of three parameters
                      <k> should be a keyword (str) that corresponds to:
                          a matrix of size 2x2 and has a multiplicative inverse in mod m
                      start < end, and both are positive valid indexes for BASE
                      The base should contain at least two chars
        ---------------------------------------------------
        """
        valid = True
        hill = Hill()
        start = key[1]
        end = key[2]
        
        base = hill.BASE[start:end]
        if not isinstance(key, tuple):
            valid = False
        elif len(key) != 3:
            valid = False
        elif not isinstance(key[0], str):
            valid = False
        elif start > end or start < 0 or end - start > len(base):
            valid = False
        else:
            counter = 0
            k = key[0]
            keyword = ""
            for c in k:
                if c in base:
                    counter += 1
                    keyword += c
            if counter < 2:
                valid = False
            # see if matrix is invertible
            matrix = hill.encode(keyword, base, 2)
            det = matrix.det()
            mod = MOD(det, end - start)
            if not mod.has_mul_inv():
                valid = False
            if det == 0:
                valid = False
        
        return valid

    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Hill Cipher
        ---------------------------------------------------
        """
        ciphertext = ""
        base = self.get_base()
        curr = ""
        pad = self.get_pad()
        key = self.get_key_matrix()
        not_in_base_index = -1
        not_in_base_char = ""
        for p in range(len(plaintext)):
            if plaintext[p] not in base:
                if len(curr) == 0:
                    ciphertext+=plaintext[p]
                else:
                    not_in_base_char += plaintext[p]
                    not_in_base_index = 1
            else: 
                curr += plaintext[p]
            
            if p == len(plaintext) - 1 and len(curr) != 2:
                curr += pad
            if len(curr) == 2:
                curr_matrix = [[self.find_index(base, curr[0])], [self.find_index(base, curr[1])]]
                curr_matrix = Matrix.to_matrix(curr_matrix)
                block = Matrix.mul(key, curr_matrix)
                block = Matrix.mod(block, len(base))
                temp = Hill.decode(block, base)
                if not_in_base_index == 1:
                    temp = temp[0] + not_in_base_char + temp[1]
                    not_in_base_index = -1
                    not_in_base_char = ""
                    
                ciphertext += temp
                curr = ""
                
        
        return ciphertext
    
    def find_index(self, base, char):
        index = -1
        for i in range(len(base)):
            if base[i] == char:
                index = i
                break
            else:
                i += 1
        return index
    
    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext(str)
        Return:       plaintext (str)
        Description:  Decryption using Hill Cipher
        ---------------------------------------------------
        """
        plaintext = ""
        base = self.get_base()
        curr = ""
        pad = self.get_pad()
        key = self.get_key_matrix()
        
        key = Matrix.inverse_mod(key, len(base))
        not_in_base_char = ""
        not_in_base_index = -1
        # parse blocks of two and multiply by 2
        for p in range(len(ciphertext)):
            if ciphertext[p] in base:
                curr += ciphertext[p]
            else:
                if len(curr) == 0:
                    plaintext+=ciphertext[p]
                else:
                    not_in_base_char += ciphertext[p]
                    not_in_base_index = 1
                    
            if p == len(ciphertext) - 1 and len(curr) != 2:
                curr += pad
            if len(curr) == 2:
                curr_matrix = [[base.index(curr[0])], [base.index(curr[1])]]
                curr_matrix = Matrix.to_matrix(curr_matrix)
                block = Matrix.mul(key, curr_matrix)
                block = Matrix.mod(block, len(base))
                temp = Hill.decode(block, base) 
                if not_in_base_index == 1:
                    temp = temp[0] + not_in_base_char + temp[1]
                plaintext += temp
                curr = ""
                not_in_base_char = ""
                not_in_base_index=-1
        # remove pad if it exists
        while plaintext[-1] == pad:
            plaintext = plaintext[:-1]
        
        return plaintext

    
class PRNG:
    """
    ----------------------------------------------------
    Description: Pseudo random number generators
    ----------------------------------------------------
    """
    PRIMES_FILE = 'primes.txt'
    
    @staticmethod
    def LFSR(feedback, IG, bits):
        """
        ----------------------------------------------------
        Parameters:   feedback (str): a binary number representing feedback equation
                      IG (str): a binary number representing initial configuration state
                      bits (int): number of bits to generate
        Return:       output (str): random binary bits
        Description:  Linear Feedback Shift Register
                      Used for generating random bits
                      feedback binary maps to feedback equation
                          Example 1: feedback = '01001'
                              0*b5 + 1*b4 + 0*b3 + 0*b2 + 1*b1
                          Example 2: feedback = '0101'
                              0*b4 + 1*b3 + 0*b2 + 1*b1
                      Number of bits in feedback and IG should be equal
                      If invalid input --> return error message
        ---------------------------------------------------
        """ 
        # check for valid input
        valid = utilities.is_binary(feedback) and utilities.is_binary(IG) and len(feedback) == len(IG) and bits>0
        if not valid:
            return "Error(PRNG.LFSR): invalid input"
        
        output = ""
        registers = []
        for f in IG:
            registers.append(f)
        counter = 0
        old_registers = []
        
        while counter<bits:
            num = 0
            old_registers = registers.copy()
            #shift over registers
            for i in range(len(registers)-1,0,-1):
                registers[i] = registers[i-1]
            #compute first index
            for i in range(len(feedback)):
                num += int(feedback[i]) * int(old_registers[i])
                if num==2:
                    num = 0
                
            registers[0] = num
            output+=str(old_registers[-1])
            
            counter+=1
            
        
        return output

    @staticmethod
    def BBS(p, q, bits):
        """
        ----------------------------------------------------
        Parameters:   p (int): a prime number
                      q (int): a prime number
                      bits (int): number of bits to generate
        Return:       output (str): random binary bits
        Description:  Blum Blum Shub PRNG Generator
                      p and q should be primes congruent to 3
                      The seed is the nth prime number, where n = p*q
                      If the nth prime number is not relatively prime with n,
                          the next prime number is selected until a valid one is found
                          The prime numbers are read from the file PRIMES_FILE (starting n=1)
                      If invalid input --> return error message
        ---------------------------------------------------
        """ 
        output = ""
        if not isinstance(bits,int) or bits<=0:
            return "Error(PRNG.BBS): invalid bits"
        elif not isinstance(p,int) or p<=0 or (3-p)%4!=0:
            return "Error(PRNG.BBS): invalid p"
        elif not isinstance(q,int) or q<=0 or (3-q)%4!=0:
            return "Error(PRNG.BBS): invalid q"
        #check for congruence
        n=p*q
        
        #get the nth prime number from primes file
        primes = utilities.file_to_text("primes.txt").split("\n")
        i=n
        while not MOD.is_relatively_prime(n, primes[i]):
            i+=1
        x = int(primes[i-1])
        mod = MOD()
        counter = 1
        
        mod.set_mod(n)
        mod.set_value(x**2)
        x0 = mod.get_residue()
        #output+=str(x0)
        while counter<=bits:
            mod.set_value(x0**2)
            xi = mod.get_residue()
            x0 = xi
            bi = xi%2
            output+=str(bi)
            
            counter+=1
        
        
        
        return output
