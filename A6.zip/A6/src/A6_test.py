from A6 import Matrix, PRNG, Hill

def test_matrix_default():
    print('{}'.format('-'*40))
    print("Start of Matrix Library Default Testing")
    print()
    
    m = Matrix()
    print('m = Matrix()')
    print('print(m) = '.format(m))
    print('m.get_matrix() = {}'.format(m.get_matrix()))
    print('m.get_size() = {}'.format(m.get_size()))
    print('m.get_row(0) = ',end='')
    m.get_row(0)
    print('m.get_column(0) = ',end='')
    m.get_column(0)
    print('m.get_item(0,0) = ',end='')
    m.get_item(0,0)
    print('m.is_empty() = {}'.format(m.is_empty()))
    print('m.is_vector() = {}'.format(m.is_vector()))
    print('m.is_square() = {}'.format(m.is_square()))
    print('m.is_identity() = {}'.format(m.is_identity()))
    print('m.to_list() = {}'.format(m.to_list()))
    print('m.set_item(0,0,0) = ',end='')
    m.set_item(0, 0, 0)
    print('m.det() = ',end='')
    m.det()
    print()
    
    print('End of Matrix Library Default Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_matrix_basic():
    print('{}'.format('-'*40))
    print("Start of Matrix Library Default Testing")
    print()
    
    print('---------- Case 1: 2x2 matrix:')
    m = Matrix(2,2,5)
    print('m = Matrix(2,2,5)')
    print('print(m) = \n{}'.format(m))
    print('m.get_matrix() = {}'.format(m.get_matrix()))
    print('m.get_size() = {}'.format(m.get_size()))
    print('m.get_row(0) = {}'.format(m.get_row(0)))
    print('m.get_column(0) = {}'.format(m.get_column(0)))
    print('m.get_item(0,0) = {}'.format(m.get_item(0,0)))
    print('m.is_empty() = {}'.format(m.is_empty()))
    print('m.is_vector() = {}'.format(m.is_vector()))
    print('m.is_square() = {}'.format(m.is_square()))
    print('m.is_identity() = {}'.format(m.is_identity()))
    print('m.to_list() = {}'.format(m.to_list()))
    print('m.set_item(0,0,0) =  {}'.format(m.set_item(0, 0, 0)))
    print('print(m) =\n{}'.format(m))
    print('m.set_matrix([[1,2],[3,4]]) = {}'.format(m.set_matrix([[1,2],[3,4]])))
    print('print(m) =\n{}'.format(m))
    print('m.det() = {}'.format(m.det()))
    print()
    
    print('---------- Case 2: 2x3 matrix:')
    m = Matrix(2,3,6)
    print('m = Matrix(2,3,6)')
    print('print(m) = \n{}'.format(m))
    print('m.set_item(-1,-2,4) =  {}'.format(m.set_item(-1,-2,4)))
    print(m)
    print('m.set_item(-1,-1,5) =  {}'.format(m.set_item(-1,-1,5)))
    print(m)
    print('m.set_item(-1,-3,2) =  {}'.format(m.set_item(-1,-3,2)))
    print(m)
    print('m.set_item(-1,-4,1) =  {}'.format(m.set_item(-1,-4,1)))
    print(m)
    print('m.get_matrix() = {}'.format(m.get_matrix()))
    print('m.get_size() = {}'.format(m.get_size()))
    print('m.get_row(0) = {}'.format(m.get_row(0)))
    print('m.get_column(0) = {}'.format(m.get_column(0)))
    print('m.get_item(0,0) = {}'.format(m.get_item(0,0)))
    print('m.is_empty() = {}'.format(m.is_empty()))
    print('m.is_vector() = {}'.format(m.is_vector()))
    print('m.is_square() = {}'.format(m.is_square()))
    print('m.is_identity() = {}'.format(m.is_identity()))
    print('m.to_list() = {}'.format(m.to_list()))
    print('print(m) =\n{}'.format(m))
    print('m.det() = {}'.format(m.det()))
    print()

    print('---------- matrix.det():')
    A = [ [[14,6],[7,4]] , [10], [[1,1,1],[2,2,2],[3,3,3]] ]
    for i in range(len(A)):
        m.set_matrix(A[i])
        print('A = {}'.format(A[i]))
        print('det = {}'.format(m.det()))
        print()
        
    print('End of Matrix Library Basic Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_matrix_static():
    print('{}'.format('-'*40))
    print("Start of Matrix Library Static methods Testing")
    print()
    
    print('---------- Matrix.to_matrix(m):')
    cases = [[[2,3],[4]],[[1],[2]],[[1,2],[3,4]],[],[10],[10,20,30], 
             [[2,3,4],[4,5,6],[7,8,9]], [[1,2,3],[4,5,6]]]
    for i in range(len(cases)):
        m = Matrix.to_matrix(cases[i])
        if type(m) == Matrix:
            print('{}'.format(m.get_matrix()))
    print()
    
    print('---------- Matrix.valid_vector():')
    cases = [10, (2,3,4), [[]], [[1],[2]],[[1,2],[3,4]],[],[10],[10,20,30]]
    for c in cases:
        print('{:17s} --> {}'.format(str(c),Matrix.valid_vector(c)))
    print()
    
    print('---------- Matrix.valid_matrix():')
    cases = [10, (2,3,4), [[2,3],[4]], [[2,3,4],[4,5,6],[7,[8],9]],
             [[]], [[1],[2]],[[1,2],[3,4]],[],[10],[10,20,30], 
             [[2,3,4],[4,5,6],[7,8,9]], [[1,2,3],[4,5,6]]]
    for c in cases:
        print('{:17s} --> {}'.format(str(c),Matrix.valid_matrix(c)))
    print()
    
    print('---------- Matrix.I():')
    m = Matrix()
    for i in range(0,5):
        print('Matrix.I({}) = '.format(i))
        m.set_matrix(Matrix.I(i))
        print(m)
        print()
     
    print('End of Matrix Library Static methods Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_matrix_operations():
    print('{}'.format('-'*40))
    print("Start of Matrix Library operations Testing")
    print()
    
    print('---------- Scalar multiplication:')
    constants = [4, 4, 6, -1, 13]
    matrices = [(1,2), [], [1,2,3,4], [[10,20],[30,40]], [[15,16,17],[18,19,20]]]
    for i in range(len(constants)):
        print('c = {}'.format(constants[i]))
        print('matrix = {}'.format(matrices[i]))
        result = Matrix.scalar_mul(constants[i], matrices[i])
        print('result = ')
        print(result)
        print()
    
    print('---------- Cross multiplication:')
    A = [ [[1,2],[3,4]] , [[1,2,3],[5,6,7]] , [5] , [0,1,2] , [[0],1] , 
         [[1,2,3],[5,6,7]] , [[1,2,3],[5,6,7]] ]
    B = [ [[10,20],[30,40]] , [[10,20],[30,40],[50,60]] , [10] , 
         [[0],[1],[2]] , [1,0] , [[10,20],[30,40],[50,60]] , [[10,20],[30,40]] ]
    n1 = Matrix()
    n2 = Matrix()
    for i in range(len(A)):
        print('A = {}'.format(A[i]))
        n1.set_matrix(A[i])
        print('B = {}'.format(B[i]))
        n2.set_matrix(B[i])
        result = Matrix.mul(n1,n2)
        print('result = ')
        print(result)
        print()

    print('---------- Matrix.mod:')
    A = [ [[15,2],[3,4]] , [1,2,3,4] , [[3],[5]] , [[3],[5]] ]
    mods = [2, 2, 3, 0]
    for i in range(len(A)):
        print('Matrix.mod({},{}) = '.format(A[i],mods[i]))
        n1.set_matrix(A[i])
        result = Matrix.mod(n1,mods[i])
        print('result = ')
        print(result)
        print()
    
    print('---------- Matrix.inverse_mod:')
    A = [ [[1,4],[8,11]] , [[4,3],[1,1]] , [[5,14],[14,3]], [[1,4],[8,10]] , 
         [1,4,8,10] , [[4,3],[1,1]] , [[1,2,3],[4,5,6],[7,8,9]] ]
    mods = [26, 5, 26, 26, 15, -5, 7]
    for i in range(len(A)):
        print('Matrix.inverse_mod({},{}) = '.format(A[i],mods[i]))
        n1.set_matrix(A[i])
        result = Matrix.inverse_mod(n1,mods[i])
        print('result = ')
        print(result)
        if not result.is_empty():
            ver = Matrix.mul(n1,result)
            ver = Matrix.mod(ver,mods[i])
            if(ver.is_identity()):
                print('Verification successful')
            else:
                print('Verification failed')
        print()
        
    print('End of Matrix Library operations Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_hill_basics():
    print('{}'.format('-'*40))
    print("Start of Hill Basic Testing")
    print()

    print('Creating a hill cipher object using default constructor:')
    h = Hill()
    print(h)
    print()
        
    print('Testing Hill.encode and decode:')

    cases = ['food','pswd','rod','an','b','smart','3Cents']
    base = Hill.BASE
    for c in cases:
        code = Hill.encode(c, base[:26], 2)
        keyword = Hill.decode(code,base[:26])
        print('{} --> {} --> {}'.format(c,code.get_matrix(),keyword))
    print()
    
    print('Testing Hill.valaid_key:')
    cases = [10, 'b','pswd','rod','an','smart','food','3Cents','dog','fishing']
    for c in cases:
        key = (c,0,26)
        print('{} --> {}'.format(str(c), Hill.valid_key(key)))
    print()
    
    print('Testing set_key, get_key, get_base and __str__:')
    cases = [('Horse',0,26),('seal',3,39),('whale',4,41), ('DUCKS',22,92), ('69934',13,87)]
    for c in cases:
        print('Setting Hill key to {}'.format(c))
        print('\tSuccess = {}'.format(h.set_key(c)))
        print('\tget_key = {}'.format(h.get_key()))
        print('\tget_base = {}'.format(h.get_base()))
        print('\tget_key_matrix = {}'.format(h.get_key_matrix().get_matrix()))
        print(h)
        print()
        
    print('End of Hill Cipher basic Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_hill():
    print('{}'.format('-'*40))
    print("Start of Hill cipher Testing")
    print()
    
    h = Hill()
        
    plaintext = ['lunch','brunch','breakfast','dinner','lunch bag',
                 'EMPTY WATER BOTTLE?','Full plates..of SALAD']
    keys = ['pear','apple','fig','mellon','apricot','CHERRY','pr unes']
    pads = ['x','q','q','Q','q','Q','?']
    start = [0,0,0,3,4,21,6]
    end = [26,26,27,39,41,92,87]
    for i in range(len(start)):
        k = (keys[i],start[i],end[i])
        h.set_key(k)
        h.set_pad(pads[i])
        print(h)
        print('plaintext =  {}'.format(plaintext[i]))
        ciphertext = h.encrypt(plaintext[i]) 
        print('ciphertext = {}'.format(ciphertext))
        plaintext2 = h.decrypt(ciphertext)
        print('plaintext2 = {}'.format(plaintext2))
        print()
        
        
    print('End of Hill cipher Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_LFSR():
    print('{}'.format('-'*40))
    print("Start of LFSR Testing")
    print()
    
    
    
    # result = PRNG.LFSR("0011", "1000", 15)
    # print('LFSR({},{},{}) = {}'.format("0110", "1000", 15,result))
        
        
        
        
    
    IG = ['1011','1000','10000' ,'1200','1100','1011','10000']
    feedback = ['0101','0011','01011','0100','01100','0102','01010'] 
    bits = [8,18,32,9,8,11,-2]
    for i in range(len(IG)):
        result = PRNG.LFSR(feedback[i], IG[i], bits[i])
        print('LFSR({},{},{}) = {}'.format(feedback[i],IG[i],bits[i],result))
    print()
    
    print('End of LFSR Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_BBS():
    print('{}'.format('-'*40))
    print("Start of BBS Testing")
    print()
    
    p = [383,11,27691, 383,383,384]
    q = [503,19,11, 503,"503",503]
    bits = [8,4,16, 0,1,1]
    for i in range(len(p)):
        output = PRNG.BBS(p[i],q[i],bits[i])
        print('PRNG.BBS({},{},{}) = {}'.format(p[i],q[i],bits[i],output))
    print()

    print('End of LFSR Testing')
    print('{}'.format('-'*40))
    print()
    return

test_matrix_default()
test_matrix_basic()
test_matrix_static()
test_matrix_operations()
test_hill_basics()
test_hill()
test_LFSR()
test_BBS()