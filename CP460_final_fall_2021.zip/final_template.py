import utilities
from mod import MOD
from copy import deepcopy

NAME = 'Qutaiba_Albluwi'     #<------- edit this to be your name, should match your file name

class final_info:
    
    def get_first_name(self):
        return 'Write your first name'  #<------------- edit this with your first name as in myls
    
    def get_last_name(self):
        return 'Write your last name'  #<------------- edit this with your last name as in myls
        
    def get_ID(self):
        return '012345678'            #<------- edit this with your student ID
    
    def get_certification(self):
        return 'Type the certification'   #<------- edit this string with your honor pledge

    def get_comments(self):
        output = 'If you have any comments that you want the instructor to be aware of '
        output += 'put it in this method'
        return output
    
    def get_task1_solution(self):
        key = (57, 1, 64, 0, 73) #<---------- hard-code your Task 1 key here
        plaintext = ''           #<---------- load your task1 decrypted text here
        return key,plaintext
    
    def get_task2_solution(self):
        key = '100001111'       #<---------- hard-code your Task 2 key here
        plaintext = ''          #<---------- load your task2 decrypted text here
        return key,plaintext
    
    def get_task3_solution(self):
        plaintext = ''          #<---------- load your task3 decrypted text here
        return '',plaintext
    
    def get_task4_solution(self):
        key = 626               #<---------- hard-code your Task 4 key here
        plaintext = ''          #<---------- load your task4 decrypted text here
        return key,plaintext

#-------------------- Task 1: Math Cipher ----------------------
class Math_Cipher:
    BASE = utilities.get_base('lower') + ' ' + utilities.get_base('nonalpha') + utilities.get_base('upper')
    DEFAULT_KEY = (11,7,13,0,26)

    def __init__(self,key=DEFAULT_KEY):
        #your code
        return
    
    def get_key(self):
        #your code
        return ''

    def get_base(self):
        #your code
        return ''
        
    def set_key(self,key):
        #your code
        return False
    
    def __str__(self):
        #your code
        return ''
    
    @staticmethod
    def valid_key(key):
        #your code
        return False
    
    def encrypt(self,plaintext):
        return ''
    
    def decrypt(self,ciphertext):
        return ''
    
    @staticmethod
    def analyze_keys(start,end):
        #your code
        return []
    
    @staticmethod
    def cryptanalyze(ciphertext):
        #your code
        return '',''
    

#-------------------- Task 2: SDES CTR Mode ----------------------
class SBOX:
    def __init__(self,filename = ''):
        self._box = [[],[]]
        self._size = 0
        if filename != '':
            self.set_box(filename)
    
    def is_empty(self):
        return self._size == 0
    
    def get_box(self):
        return deepcopy(self._box)
    
    def get_size(self):
        return self._size
    
    @staticmethod
    def valid_box(box): 
        if type(box) != list or len(box) != 2:
            return False
        if box == [[],[]]:
            return True
        if len(box[0]) != len(box[1]):
            return False
        for i in range(2):
            for j in range(len(box[0])):
                if not utilities.is_binary(box[i][j]) or len(box[i][j]) != len(box[0][0]):
                    return False
        return True
    
    def set_box(self,filename):
        temp = [[],[]]
        in_file = open(filename,'r')
        line1 = in_file.readline().strip()
        line2 = in_file.readline().strip()
        in_file.close()
        temp[0] = line1.split('-')
        temp[1] = line2.split('-')
        if not SBOX.valid_box(temp):
            return False
        self._box = deepcopy(temp)
        self._size = len(temp[0][0]) + 1
        return True
    
    def substitute(self,value):
        if not utilities.is_binary(value) or len(value) != self._size:
            return ''
        row = int(value[0])
        col = utilities.bin_to_dec(value[1:])
        return self._box[row][col]
    
    def __str__(self):
        output = 'SBOX({}):\n'.format(self._size)
        output += str(self._box[0]) + '\n'
        output += str(self._box[1])
        return output
    
class SDES_CTR:
    DEFAULT_ENCODING = 'B6'
    DEFAULT_BLOCK_SIZE = 12
    DEFAULT_KEY_LENGTH = 9
    DEFAULT_ROUNDS = 2
    DEFAULT_SBOX1 = SBOX('sbox1.txt')
    DEFAULT_SBOX2 = SBOX('sbox2.txt')
    DEFAULT_KEY = '111011011'

    def __init__(self,key=DEFAULT_KEY):
        self._rounds = self.DEFAULT_ROUNDS
        self._key_length = self.DEFAULT_KEY_LENGTH
        self._block_size = self.DEFAULT_BLOCK_SIZE
        self._encoding = self.DEFAULT_ENCODING
        self._sbox1 = self.DEFAULT_SBOX1
        self._sbox2 = self.DEFAULT_SBOX2
        if key != self.DEFAULT_KEY:
            self.set_key(key)
        
    def get_value(self,parameter):
        # your code
        return 0
    
    def set_key(self,key):
        #your code
        return False
    
    def set_parameter(self,parameter,value):
        #your code
        return False

    def get_key(self):
        #your code
        return ''
    
    def get_subkey(self,i):
        #your code
        return ''
        
    def expand(self,R):
        #your code
        return ''
    
    def F(self,Ri,ki):
        #your code
        return ''

    def feistel(self,bi,ki):
        #your code
        return ''
        
    def encrypt(self,plaintext):     
        #your code
        return ''

    def decrypt(self,ciphertext):
        #your code
        return ''
    
    @staticmethod
    def cryptanalyze(ciphertext):
        #your code
        return '',''
    
#-------------------- Task 3: RSA ----------------------
class RSA:
    BLOCK_SIZE = 6
    PAD = 'Q'
    THRESHOLD = 0.7
    DICT_FILE = 'engmix.txt'
    P = 19220233 #<---------- hardcode your p value here
    Q = 29908187 #<---------- hardcode your q value here
    E = 32452885 #<---------- hardcode your e value here
    
    @staticmethod
    def compute_m(p,q):
        #your code
        return 0
    
    @staticmethod
    def compute_n(p,q):
        #your code
        return 0
    
    @staticmethod
    def compute_d(p,q,e):
        #your code
        return 0
    
    @staticmethod
    def get_public_key(p,q,e):
        #your code
        return ''
    
    @staticmethod
    def get_private_key(p,q,e):
        #your code
        return ''
    
    @staticmethod
    def LRM(b,e,m):
        #your code
        return ''

    @staticmethod
    def encode(text):
        return ''
    
    @staticmethod
    def decode(num,block_size):
        #your code
        return ''

    @staticmethod
    def encrypt(plaintext,key):
        #your code
        return ''
 
    @staticmethod
    def decrypt(ciphertext,key):
        #your code
        return ''

    @staticmethod
    def verify(message,public_key_file):
        #your code
        return 'Unkown',''

#-------------------- Task 4: Flip Cipher ----------------------

class Flip_Cipher:
    DEFAULT_KEY = 2
    
    def __init__(self,key=DEFAULT_KEY):
        #your code
        return
    
    def get_key(self):
        #your code
        return
    
    def set_key(self,key):
        #your code
        return
    
    def __str__(self):
        #your code
        return ''
    
    @staticmethod
    def valid_key(key):
        #your code
        return False
    
    @staticmethod
    def flip_block(text,block_size):
        #your code
        return ''
    
    def encrypt(self,plaintext):
        #your code
        return ''
    
    def decrypt(self,ciphertext):
        #your code
        return ''
    
    @staticmethod
    def cryptanalyze(ciphertext):
        #your code
        return '',''
