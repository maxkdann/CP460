from final import NAME, final_info, SDES_CTR, Math_Cipher, RSA, Flip_Cipher
import utilities

def get_info():
    info = final_info()
    print('{}'.format('-'*40))
    print("Retrieving student info:")
    print()
    print('Name: {} {}'.format(info.get_first_name(), info.get_last_name()))
    print('ID: {}'.format(info.get_ID()))
    print('filename = {}'.format(NAME))
    print()
    print(info.get_certification())
    print()
    print(info.get_comments())
    print()
    print('{}'.format('-'*40))
    print()
    return

def test_task1():
    print('{}'.format('-'*40))
    print("Start of Math_Cipher Testing")
    print()

    print('Creating a Math_Cipher object using default constructor:')
    mcipher = Math_Cipher()
    print(mcipher)
    print()
    
    print('Testing Math_Cipher.valaid_key:')
    cases = [[11,7,13,0,12],(11,7,13,0),(11,7,13,'0',13),(11,7,13,29,14),(11,0,13,0,26),
             (12,7,13,0,26),(5,13,7,0,26),(11,9,1,2,44),(11,7,13,0,26),(9,15,0,0,29),(9,15,1,2,43)]
    for c in cases:
        print('{:20s} --> {}'.format(str(c), Math_Cipher.valid_key(c)))
    print()
    
    print('Testing set_key, get_key, get_base and __str__:')
    cases = [(11,5,4,0,25),(13,127,2,6,37),(-5,22,9,0,71)]
    for c in cases:
        print('Setting Math_Cipher key to {}'.format(c))
        print('\tset_key success = {}'.format(mcipher.set_key(c)))
        print('\tget_key = {}'.format(mcipher.get_key()))
        print('\tget_base = {}'.format(mcipher.get_base()))
        print(mcipher)
        print()
    
    print('--------------- Testing Encryption/Decryption:')
    
    plaintexts = ['Strike in progress', 'Is mission accomplished?', 'Mission Failed!', 'Plan B ... initiated']
    keys = [(5,9,3,0,26),(45,3,14,0,29),(10,19,15,0,41),(11,17,39,2,88)]
    
    for i in range(len(keys)):
        k = keys[i]
        plaintext = plaintexts[i]
        mcipher.set_key(k)
        print(mcipher)
        print('plaintext =  ', plaintext)
        ciphertext = mcipher.encrypt(plaintext)
        if ciphertext != '':
            print('ciphertext=  ',ciphertext)
        plaintext2 = mcipher.decrypt(ciphertext)
        if plaintext2 != '':
            print('plaintext2=  ',plaintext2)
        print()
        
    print('----------- Testing analyze_keys:')
    cases = [[0,2],[1,4],[2,6],[3,8],[4,10],[5,12],[6,32],[0,29]]
    for c in cases:
        print('Analyze {} = {}'.format(c,Math_Cipher.analyze_keys(c[0],c[1])))
    print()
    
    print('----------- cryptanalysis on sample data:')
    plaintext = 'There are two kinds of cryptography in this world: '
    plaintext += 'cryptography that will stop your kid sister from reading your files, '
    plaintext += 'and cryptography that will stop major governments from reading your files.'
    
    key = (1,24,25,0,61)
    mcipher.set_key(key)
    ciphertext = mcipher.encrypt(plaintext)
    print('plaintext = {}'.format(plaintext))
    print('ciphertext = {}'.format(ciphertext))
    key2,plaintext2 = Math_Cipher.cryptanalyze(ciphertext)
    print('key2 = {}'.format(key2))
    print('plaintext2 = {}'.format(plaintext))
    print()

    info = final_info()
    print('Testing student file:')
    cipher_file = 'ciphertext1_' + NAME + '.txt'
    ciphertext = utilities.file_to_text(cipher_file)
    print('ciphertext = {}'.format(ciphertext[:50]))
    
    #key,plaintext = mcipher.cryptanalyze(ciphertext)
    
    key,plaintext = info.get_task1_solution()
    mcipher.set_key(key)
    plaintext = mcipher.decrypt(ciphertext)
    
    print('plaintext = {}'.format(plaintext[:50]))
    print('key = {}'.format(key))
    print()
    
    print('End of Task1 Testing')
    print('{}'.format('-'*40))
    print()
    return
 
def test_task2():
    print('{}'.format('-'*40))
    print("Start of Task 2 Testing")
    print()

    sdes = SDES_CTR()
    
    print('Testing CTR Encryption/Decryption:')
    keys = ['100010111','011111000','010110111','110111001']
    rounds = [2,4,3,2]
    plaintexts = ['of', 'hin', 'Calf','Very large barn']
    for i in range(len(plaintexts)):
        sdes.set_parameter('rounds',rounds[i])
        sdes.set_key(keys[i])
        print('key = {}'.format(sdes.get_key()))
        plaintext = plaintexts[i]
        print('plaintext  = {}'.format(plaintext))
        ciphertext = sdes.encrypt(plaintext)
        print('ciphertext = {}'.format(ciphertext))
        plaintext2 = sdes.decrypt(ciphertext)
        print('plaintext2 = {}'.format(plaintext2))
        print()
    
    print('Testing sample file:')
    ciphertext = utilities.file_to_text('ciphertext2_sample.txt')
    print('ciphertext = {}'.format(ciphertext[:64]))
    key,plaintext = SDES_CTR.cryptanalyze(ciphertext)
    print('plaintext = {}'.format(plaintext[:64]))
    print('key = {}'.format(key))
    print()
    
    print('Testing student file:')
    cipher_file = 'ciphertext2_' + NAME + '.txt'
    ciphertext = utilities.file_to_text(cipher_file)
    print('ciphertext = {}'.format(ciphertext[:50]))
    key,plaintext = SDES_CTR.cryptanalyze(ciphertext)
    print('plaintext = {}'.format(plaintext[:50]))
    print('key = {}'.format(key))
    print()
    
    print('End of Task 2 Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_task3 ():
    print('{}'.format('-'*40))
    print("Start of Task 3 (RSA) Testing")
    print()

    print('----- Part 1: RSA basics:')
    p = RSA.P
    q = RSA.Q
    e = RSA.E
    print('p = {}'.format(p))
    print('q = {}'.format(q))
    print('e = {}'.format(e))
    print('m = {}'.format(RSA.compute_m(p, q)))
    print('n = {}'.format(RSA.compute_n(p, q)))
    print('d = {}'.format(RSA.compute_d(p, q, e)))
    print('public_key = {}'.format(RSA.get_public_key(p, q, e)))
    print('private_key = {}'.format(RSA.get_private_key(p, q, e)))
    print()
        
    print('----- Part 2: LRM exponentiation:')
    b = [66, 5, 4, 1234567890]
    e = [13, 117, 60, 151515151515151515]
    m = [20, 19, 69, 190]
    for i in range(len(b)):
        result = RSA.LRM(b[i],e[i],m[i])
        print('({}**{}) mod {} = {}'.format(b[i],e[i],m[i],result))
    print()
    
    print('----- Part 3: BA Encoding:')
    texts = ['A','a',' ','AA','BA','??','zZ', 'ABC de', 'ABC defg']
    for i in range(len(texts)):
        result = RSA.encode(texts[i])
        print('encode_BA({}) = {}'.format(texts[i],result))
    print()
    
    cases = [[0,1],[0,3],[26,1],[27,4],[96,8],[7954,2],[4921,3],[87573246,6],[807075038144,5]]
    for case in cases:
        result = RSA.decode(case[0],case[1])
        print('decode_BA({},{}) = {}'.format(case[0],case[1],result))
    print()     
    
    print('----- Part 4: Encryption:')
    print("""Case 1: Use instructor's public key:""")
    print()
    plaintext = "Your theory is crazy, but it's not crazy enough to be true"
    m1 = 574842322747571
    e1 = 32452885
    key = (e1,m1) # this is the instructor's public key
    ciphertext = RSA.encrypt(plaintext,key)
    print('Encryption using instructor public key:')
    print('plaintext: ',plaintext)
    print('key: ',key)
    print('ciphertext: ',ciphertext)
    print()

    print('Encryption using student public key:')
    p = RSA.P
    q = RSA.Q
    e = RSA.E    
    key = RSA.get_public_key(p, q, e) # this is your public key
    ciphertext = RSA.encrypt(plaintext,key)
    print('plaintext: ',plaintext)
    print('key: ',key)
    print('ciphertext: ',ciphertext)
    print()
    
    print('----- Part 5: Decryption:')
    print("Decrypt using instructor's private key:")
    ciphertext = """F},a&_SfF%c'_k:\GU{N+~G'E"3&4Zr9Gci=SRX^BHU4LvRtD+N~Z77/Cp"lyNR5E^^+s?)^FyEq[r@W"""
    plaintext2 = RSA.decrypt(ciphertext,(115013711779069, 574842322747571))
    print(plaintext2)
    print()
    
    print('The instructor sent me the following question:')
    file = 'ciphertext3_'+ NAME +'.txt'
    ciphertext = utilities.file_to_text(file)[:-1]
    private_key = RSA.get_private_key(p, q, e)
    question = RSA.decrypt(ciphertext,private_key)
    print(question)
    print()
    
    print('----- Part 6: Digital Signatures:')
    file = 'message_' + NAME + '.txt'
    message = utilities.file_to_text(file)[:-1]
    name,message = RSA.verify(message,'public_keys.txt')
    print('Retrieved message:')
    print(message)
    print('Signed by:')
    print(name)
    print()

    print('End of Task 3 Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_task4():
    print('{}'.format('-'*40))
    print("Start of Task 4: Flip Cipher Testing")
    print()

    print('Testing Basics: ')
    flip = Flip_Cipher()
    print(flip)
    flip.set_key(4)
    print(flip)
    print('key = {}'.format(flip.get_key()))
    flip.set_key(-4)
    print(flip)
    cases = ['3',-2,-1,0,1,2]
    for c in cases:
        print('valid_key({}) --> {}'.format(c,Flip_Cipher.valid_key(c)))
    print()
    
    print('Testing flip_block:')
    texts = ['ab','abc','abcd','abcde','abcdef','abcdefg','abcdefgh',
             'AB','ABC','ABCD','ABCDE','ABCDEF','ABCDEFG','ABCDEFGH',
             'ab','abc','abcd','abcde','abcdef','abcdefg','abcdefgh',
             'AB','ABC','ABCD','ABCDE','ABCDEF','ABCDEFG','ABCDEFGH']
    block_sizes = [2,2,2,2,2,2,2,3,3,3,3,3,3,3,4,4,4,4,4,4,4,5,5,5,5,5,5,5]
    for i in range(len(texts)):
        text = texts[i]
        size = block_sizes[i]
        print('flip_block({},{}) -->{}'.format(text,size,Flip_Cipher.flip_block(text, size)))
    print()
    
    print('Testing encryption:')
    cases = ['an','fox','cars','canoe','laughs','jig-zag'
             'an','fox','cars','canoe','laughs', 'jig-zag'
             'an','fox','cars','canoe','laughs', 'jig-zag'
             'an','fox','cars','canoe','laughs','jig-zag']
    keys = [2,2,2,2,2,2,3,3,3,3,3,3,4,4,4,4,4,4,5,5,5,5,5,5]
    flip = Flip_Cipher()
    for i in range(len(cases)):
        plaintext = cases[i]
        key = keys[i]
        flip.set_key(key)
        ciphertext = flip.encrypt(plaintext)
        print('key = {}, plaintext = {}, ciphertext = {}'.format(key,plaintext,ciphertext))
        #plaintext2 = flip.decrypt(ciphertext) #you can use this for testing decryption
        #print('plaintext2 = {}'.format(plaintext2))
    print()

    print('----------- cryptanalysis on sample data:')
    plaintext = 'There are two kinds of cryptography in this world: '
    plaintext += 'cryptography that will stop your kid sister from reading your files, '
    plaintext += 'and cryptography that will stop major governments from reading your files.'
    
    key = 57
    flip.set_key(key)
    ciphertext = flip.encrypt(plaintext)
    _,plaintext2 = Flip_Cipher.cryptanalyze(ciphertext)
    print('plaintext =  {}'.format(plaintext))
    print('ciphertext = {}'.format(ciphertext))
    print('plaintext2 = {}'.format(plaintext2))
    print()
    
    print('Testing student file:')
    cipher_file = 'ciphertext4_' + NAME + '.txt'
    ciphertext = utilities.file_to_text(cipher_file)
    print('ciphertext = {}'.format(ciphertext[:50]))
    key,plaintext = Flip_Cipher.cryptanalyze(ciphertext)
    print('plaintext = {}'.format(plaintext[:50]))
    print('key = {}'.format(key))
    print()

    print('End of Task 4: Flip Cipher Testing')
    print('{}'.format('-'*40))
    print()
    return

get_info()
test_task1()
test_task2()
test_task3()
test_task4()