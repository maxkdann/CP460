from A2 import Scytale, Block_Rotate, Alberti

import utilities

def test_scytale_basics():
    print('{}'.format('-'*40))
    print("Start of Scytale Basic Testing")
    print()
    
    print('Creating a scytale object using default constructor:')
    s = Scytale()
    print(s)
    print()
    
    keys = ['5',[6],-2,0,1,2,5]
    print('Testing valid_key:')
    for k in keys:
        print('valid_key({}) = {}'.format(k,Scytale.valid_key(k)))
    print()
    
    print('Testing set_key and get_key:')
    for k in keys:
        print('set_key({}) = {}, get_key = {}'.format(k,s.set_key(k), s.get_key()))
    print()
    
    print('Testing set_pad and get_pad:')
    pads = ['','Z','x','xx',3]
    for p in pads:
        print('set_pad({}) = {}, get_pad = {}'.format(p,s.set_pad(p), s.get_pad()))
    print()
    
    print('End of Scytale Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_scytale_no_padding():
    print('{}'.format('-'*40))
    print("Start of Scytale Cipher (no padding) Testing")
    print()
    
    scytale = Scytale(0,'')
    print(scytale)
    print()
        
    cases = [4, 6, 11, 22, 21]
    for i in range(len(cases)):
        print('key        = {}'.format(cases[i]))
        scytale.set_key(cases[i])
        if i == 4:
            plainfile = 'plaintext1.txt'
        else:
            plainfile = 'plaintext'+str(i+1)+'.txt'
        plaintext = utilities.file_to_text(plainfile)
        print('plaintext  = {}'.format(plaintext[:70]))
        
        ciphertext = scytale.encrypt(plaintext)
        print('ciphertext = {}'.format(ciphertext[:70]))
        utilities.text_to_file(ciphertext,'ciphertext_1'+'.txt')
        
        plaintext2 = scytale.decrypt(ciphertext)
        print('plaintext2 = {}'.format(plaintext2[:70]))
        print()
    
    print('End of Scytale Cipher (no padding) Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_scytale_padding():
    print('{}'.format('-'*40))
    print("Start of Scytale Cipher (padding) Testing")
    print()
    
    scytale = Scytale()

        
    cases = [4, 29, 27, 7, 10, 11]
    pads = ['Q','X','H','x','q','.']
    for i in range(len(cases)):        
        scytale.set_pad(pads[i])
        scytale.set_key(cases[i])
        print(scytale)
        
        print('key        = {}'.format(cases[i]))
        
        if i < 3:
            plainfile = 'plaintext1.txt'
        else:
            plainfile = 'plaintext'+str(i-1)+'.txt'
        plaintext = utilities.file_to_text(plainfile)
        print('plaintext  = {}'.format(plaintext[:70]))
        
        ciphertext = scytale.encrypt(plaintext)
        print('ciphertext = {}'.format(ciphertext[:70]))
        utilities.text_to_file(ciphertext,'ciphertext_1'+'.txt')
        
        plaintext2 = scytale.decrypt(ciphertext)
        print('plaintext2 = {}'.format(plaintext2[:70]))
        print()
    
    print('End of Scytale Cipher (no padding) Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_scytale_cryptanalysis():
    print('{}'.format('-'*40))
    print("Start of Scytale Cipher Cryptanalysis Testing")
    print()
    
    scytale = Scytale(True)
    plaintext = utilities.file_to_text('plaintext5.txt')
    keys = [15,24,1,120]
    max_key = [20,50,10,80]
    pads = ['X','r','Q','S']
    for i in range(len(keys)):
        scytale.set_pad(pads[i])
        scytale.set_key(keys[i])
        ciphertext = scytale.encrypt(plaintext)
        print('ciphertext = {}'.format(ciphertext[:130]))
        key,plaintext2 = Scytale.cryptanalyze(ciphertext,[max_key[i],None,0.85])
        print('key = {}'.format(key))
        print('plaintext  = {}'.format(plaintext2[:130]))
        print()
        
    print('End of Scytale Cipher Cryptanalysis Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_block_rotate_basics():
    print('{}'.format('-'*40))
    print("Start of Block Rotate Basic Testing")
    print()
    
    print('Creating a block rotate cipher object using default constructor:')
    br = Block_Rotate()
    print(br)
    print()
    
    keys = [(5,2), (9,0), (4,9), (5,-1), (7,-3), (0,0), [6,3], (6,3,1), (2.0,1), (9,'3')]
    print('Testing valid_key:')
    for k in keys:
        print('valid_key({}) = {}'.format(k,Block_Rotate.valid_key(k)))
    print()
    
    print('Testing set_key and get_key:')
    for k in keys:
        print('set_key({}) = {}, get_key = {}'.format(k,br.set_key(k), br.get_key()))
    print()
    
    print('Testing set_pad and get_pad:')
    pads = ['Q','x','xx',3]
    for p in pads:
        print('set_pad({}) = {}, get_pad = {}'.format(p,br.set_pad(p), br.get_pad()))
    print()
    
    print('End of Block Rotate Basic Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_block_rotate():
    print('{}'.format('-'*40))
    print("Start of Block Rotate Testing")
    print()
    
    keys = [(4,3), (10,6), (8,5), (14,-3)]
    pads = ['q', 'Q', '.', 'x']

    plaintext1 = utilities.get_base('lower')
    plaintext2 = 'The internet, our greatest tool of emancipation, has been transformed into '
    plaintext2 += 'the most dangerous facilitator of totalitarianism we have ever seen'
    plaintext3 = 'One must acknowledge with cryptography '
    plaintext3 += 'no amount of violence will ever solve a math problem.'
    plaintexts = [plaintext1,plaintext2,plaintext3,plaintext1]
    
    br = Block_Rotate()
    
    print('Testing encryption and decryption:')
    for i in range(len(keys)):
        key = keys[i]
        pad = pads[i]
        print('Key = {}, pad = {}'.format(key,pad))
        br.set_key(key)
        br.set_pad(pad)
        
        plaintext = plaintexts[i]
        print('plaintext  = {}'.format(plaintext))
        
        ciphertext = br.encrypt(plaintext)
        print('ciphertext = {}'.format(ciphertext))
        
        recovered = br.decrypt(ciphertext)
        print('plaintext2 = {}'.format(recovered))
        print() 
        
    print('End of Block Rotate Testing')
    print('{}'.format('-'*40))
    print()
    return
    
def test_block_rotate_cryptanalysis():
    print('{}'.format('-'*40))
    print("Start of Block Rotate Cryptanalysis Testing")
    print()
            
    print('Testing Cryptanalysis: ')
     
    args = [[0,0,0,None,0.85], [0,15,0,None,0.85],[7,0,0,None,0.90],[10,14,0,None,0.85],
            [0,0,8,None,0.85], [0,10,1,None,0.85], [7,0,4,None,0.85], [8,8,7,None,0.80],
            [13,14,0,None,0.87]]
        
    for i in range(len(args)):
        filename = 'ciphertext'+str(i%5+1)+'.txt'
        ciphertext = utilities.file_to_text(filename)
        print('ciphertext = {}'.format(ciphertext[:92]))
        key, plaintext = Block_Rotate.cryptanalyze(ciphertext, args[i])
        print('key = {}'.format(key))
        print('plaintext  = {}'.format(plaintext[:92]))
        print()
          
    print('End of Block Rotate Cryptanalysis Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_alberti_basics():
    print('{}'.format('-'*40))
    print("Start of Alberti Basic Testing")
    print()
    
    print('Creating an alberti cipher object using default constructor:')
    alberti = Alberti()
    print(alberti)
    print()
    
    keys = [('r','m146kcn58xsy9jdbuhft2wez03algv7pqior'),
            ('A','pmohk0r8tlfu7cvas65b3ndw19gq4j2yexiz'),
            ('a','1vjn7koz9ue3dlmrgxy562ctp0wsh4i8baf'),
            ('b','1vjn7koz9ue3dvlmrgxy562ctp0qwsh4i8baf'),
            ('c','pmohk0r8tlfu7cvas65b3ndw1!gq4j2yexiz')]
    print('Testing valid_key:')
    for k in keys:
        print('{} --> {}'.format(k,Alberti.valid_key(k)))
    print()

    keys = [('n','m146kcn58xsy9jdbuhft2wez03algv7pqior'),
            ('b','pmohk0r8tlfu7cvas65b3ndw19gq4j2yexiz'),
            ('c','pmohk0r8tlfu7cvas65b3ndw1!gq4j2yexiz'),
            ('f','1vjn7koz9ue3dlmrgxy562ctp0qwsh4i8baf')]
         
    print('Testing set_key, get_key and get_wheels:')
    for k in keys:
        print('set_key{} = {}'.format(k,alberti.set_key(k)))
        print('get_key() = {}'.format(alberti.get_key()))
        out_wheel,in_wheel = alberti.get_wheels()
        print('out_wheel = {}'.format(out_wheel))
        print('in_wheel  = {}'.format(in_wheel))
        print()
     
    print('Testing set_mode and get_mode:')
    modes = ['periodic','default','simple','complex']
    for m in modes:
        print('set_mode({}) = {}, get_mode = {}'.format(m,alberti.set_mode(m), alberti.get_mode()))
        print(alberti)
        print()
    
    print('End of Alberti Basic Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_alberti():
    print('{}'.format('-'*40))
    print("Start of Alberti Testing")
    print()
     
    keys = [('a',''),
        ('n','m146kcn58xsy9jdbuhft2wez03algv7pqior'),
        ('b','pmohk0r8tlfu7cvas65b3ndw19gq4j2yexiz'),
        ('f','1vjn7koz9ue3dlmrgxy562ctp0qwsh4i8baf')]

    modes = ['simple','default','periodic','periodic']
 
    plaintext1 = utilities.get_base('lower')
    plaintext2 = 'Alberti is a True Renissance Man!'
    plaintext3 = 'Cryptography to some is an art not science'
    plaintext4 = 'One must acknowledge with cryptography '
    plaintext4 += 'no amount of violence will ever solve a math problem.'
    plaintexts = [plaintext1,plaintext2,plaintext3,plaintext4]
     
    alberti = Alberti()
     
    print('Testing encryption and decryption:')
    for i in range(len(keys)):
        key = keys[i]
        mode = modes[i]
        alberti.set_key(key)
        alberti.set_mode(mode)
        print(alberti)
         
        plaintext = plaintexts[i]
        print('plaintext  = {}'.format(plaintext))
         
        ciphertext = alberti.encrypt(plaintext)
        print('ciphertext = {}'.format(ciphertext))
         
        recovered = alberti.decrypt(ciphertext)
        print('plaintext2 = {}'.format(recovered))
        print() 
         
    print('End of Alberti Testing')
    print('{}'.format('-'*40))
    print()
    return
     
def test_alberti_cryptanalysis():
    print('{}'.format('-'*40))
    print("Start of Alberti Cryptanalysis Testing")
    print()

    key = ('0','dgzmhok0rtl9fu7cwvas6538n1q4jb2yexip')    
    alberti = Alberti(key,'periodic')
    plaintext = utilities.file_to_text('plaintext1.txt')
    ciphertext = alberti.encrypt(plaintext)
    utilities.text_to_file(ciphertext, 'ciphertext7.txt')
    
    print('Testing Cryptanalysis: ')
       
    args = [['v','zmhok0r8tlfu7cvas65b3wdn19gq4j2yexip','periodic',None,0.9],
            ['j','','simple',None,0.9],
            ['r','gzmhok0r8tl9fu7cvas65b3wdn1q4j2yexip','',None,0.9],
            ['w','w8gzmhok0rtl9fu7cvas653dn1q4jb2yexip','',None,0.9],
            ['','','simple',None,0.9],
            ['','8gzmhok0rtl9fu7cwvas653dn1q4jb2yexip','',None,0.9],
            ['','dgzmhok0rtl9fu7cwvas6538n1q4jb2yexip','',None,0.9]]
    
    for i in range(len(args)):
        filename = 'ciphertext'+str(i+7)+'.txt'
        ciphertext = utilities.file_to_text(filename)
        print('ciphertext = {}'.format(ciphertext[:92]))
        key, plaintext = Alberti.cryptanalyze(ciphertext, args[i])
        print('key = {}'.format(key))
        print('plaintext  = {}'.format(plaintext[:92]))
        print()
           
    print('End of Alberti Cryptanalysis Testing')
    print('{}'.format('-'*40))
    print()
    return

test_scytale_basics()
test_scytale_no_padding()
test_scytale_padding()
test_scytale_cryptanalysis()
test_block_rotate_basics()
test_block_rotate()
test_block_rotate_cryptanalysis()
test_alberti_basics()
test_alberti()
test_alberti_cryptanalysis()