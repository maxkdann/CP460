"""
-----------------------------
CP460 (Fall 2021)
Name: Maxwell Dann
ID:   190274440
Assignment 2
-----------------------------
"""
from copy import deepcopy
import math
from utilities import get_positions,new_matrix, is_plaintext, load_dictionary, text_to_blocks, shift_string,\
    clean_text, insert_positions
import random


"""Put any comments to the grader here"""


class Scytale:
    """
    ----------------------------------------------------
    Cipher name: Spartan Scytale Cipher (500 B.C.)
    Key:         (int): number of rows (diameter of rod)
    Type:        Transposition Cipher
    Description: Assume infinite length rod, i.e., unlimited #columns
                 Construct a table that can fit the plaintext
                 Then read text vertically
                 #rows is equal to the key, final row might be empty
                 User may or may not use padding
    ----------------------------------------------------
    """
    
    DEFAULT_PAD = 'Q'
    DEFAULT_KEY = 4
    
    def __init__(self,key = DEFAULT_KEY, pad = DEFAULT_PAD):
        """
        ----------------------------------------------------
        Parameters:   _key (int): default value: 4
                      _pad (str): padding character, default = 'Q'
        Description:  Scytale constructor
                      sets _key, and _pad
                      if _pad is set to empty string --> no padding
        ---------------------------------------------------
        """
        self.set_key(key)
        self.set_pad(pad)
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (int)
        Description:  Returns a copy of the scytale key
        ---------------------------------------------------
        """
        return deepcopy(self._key)
       
    def set_key(self,key):
        """
        ----------------------------------------------------
        Parameters:   key (int): #columns
        Return:       success: True/False
        Description:  Sets Scytale key to given key
                      if invalid key --> set to default key
        ---------------------------------------------------
        """ 
        valid = self.valid_key(key)
        if valid:
            self._key = key
        else:
            self._key = self.DEFAULT_KEY
        return valid
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Scytale object. Used for testing
                      output format:
                      Scytale Cipher:
                      key = <key>, pad = <pad> OR
                      key = <key>, no padding
        ---------------------------------------------------
        """
        output = "Scytale Cipher:\nkey = "
        output+=str(self.get_key())
        if self.get_pad()=="":
            output+=", no padding"
        else:
            output+=", pad = "
            output+=str(self.get_pad())
        return output
        
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Scytale key
                      A valid key is an integer >= 1
        ---------------------------------------------------
        """
        return isinstance(key,int) and key>=1
    
    def set_pad(self,pad):
        """
        ----------------------------------------------------
        Parameters:   pad (str): a padding character
        Return:       success: True/False
        Description:  Sets scytale pad to given character
                      a pad should be a single character or an empty string
                      if invalid pad, set to default value
                      empty string means no padding
        ---------------------------------------------------
        """
        if isinstance(pad, str) and (len(pad)==1 or len(pad)==0):
            self._pad = pad
            return True
        else:
            self._pad = self.DEFAULT_PAD
            return False

    def get_pad(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       pad (str): current padding character
        Description:  Returns a copy of current padding character
        ---------------------------------------------------
        """ 
        return deepcopy(self._pad)
    

    def encrypt(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Scytale Cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        assert isinstance(plaintext,str),"Error(encrypt): invalid input"
        rows = self.get_key()
        ciphertext = ""
        pad = self.get_pad()
        #check that len is not key
        if len(plaintext)<=rows or rows == 1:
            ciphertext = plaintext
            #add pad if it exists
            for i in range(rows-len(plaintext)):
                ciphertext+=pad
        else:
            cols = math.ceil(len(plaintext)/rows)
            table = new_matrix(rows,cols,pad)
            x = 0
            #add chars horizontally
            for i in range(len(table)):
                for j in range(len(table[i])):
                    if x>=len(plaintext):
                        break
                    else:
                        table[i][j] = plaintext[x]
                        x+=1
            
            #read vertically
            for i in range(cols):
                for j in range(rows):
                    ciphertext+=table[j][i]
        
        return ciphertext

    def decrypt(self,ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Scytale Cipher
                      Removes padding if it exist
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        assert isinstance(ciphertext,str), "Error(decrypt): invalid input"
        cols = self.get_key()
        rows = math.ceil(len(ciphertext)/cols)
        table = new_matrix(rows, cols, "")
        x = 0
        skips = (cols*rows)-len(ciphertext)
        skip_r = rows-1
        skip_c = cols-1
        #add skips to table
        while skips>0:
            table[skip_r][skip_c] = 'skip'
            if skip_r == 0:
                skip_r = rows-2
                skip_c-=1
            skip_r-=1
            skips-=1
        for i in range(rows):
            for j in range(cols):
                if x>=len(ciphertext):
                    break;
                if table[i][j]=='skip':
                    continue
                else:
                    table[i][j] = ciphertext[x]
                    x+=1
                
        plaintext = ""
        for i in range(cols):
            for j in range(rows):
                if table[j][i]=='skip':
                    continue
                plaintext+=table[j][i]
        #remove padding chars if found
        while plaintext[-1]==self.get_pad():
            plaintext = plaintext[:-1]
        return plaintext

    @staticmethod
    def cryptanalyze(ciphertext,args = [100,None,0.9]):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext (string)
                      args (list):
                        max_key (int): default 100
                        dictionary_file (str): default = None
                        threshold (float): default = 0.9
        Return:       key,plaintext
        Description:  Cryptanalysis of Scytale Cipher
                      Apply brute force from key 1 up to max_key (inclusive)
                      Assumes user passes a valid args list
        ---------------------------------------------------
        """
        found = False
        i = 1
        key = ""
        if args[1] is None:
            dict_list = load_dictionary("engmix.txt")
        else:
            dict_list = load_dictionary(args[1])
        text = ""
        s = Scytale(1)
        while not found and i<args[0]:
            s.set_key(i)
            text = s.decrypt(ciphertext)
            found = is_plaintext(text,dict_list,args[2])
            if found:
                key = i
            i+=1
        if not found:
            text = ""
            print("Scytale.cryptanalysis: cryptanalysis failed")
        return key, text

class Block_Rotate:
    """
    ----------------------------------------------------
    Cipher name: Block Rotate Cipher
    Key:         (B,R): block size, number of rotations
    Type:        Transposition Cipher
    Description: Breaks plaintext into blocks of size B
                 Rotates each block by R
                 Uses padding for the final block
    ----------------------------------------------------
    """
    
    DEFAULT_PAD = 'q'
    DEFAULT_KEY = (1,0)
    
    def __init__(self,key=DEFAULT_KEY,pad=DEFAULT_PAD):
        """
        ----------------------------------------------------
        Parameters:   _key (int,int): default value: (1,0)
                      _pad (str): a character, default = q
        Description:  Block Rotate constructor
                      sets _key and _pad
        ---------------------------------------------------
        """
        self.set_key(key)
        self.set_pad(pad)
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (int,int)
        Description:  Returns a copy of the Block Rotate key
        ---------------------------------------------------
        """
        return deepcopy(self._key)
       
    def set_key(self,key):
        """
        ----------------------------------------------------
        Parameters:   key (b,r): tuple(int,int)
        Return:       success: True/False
        Description:  Sets block rotate cipher key to given key
                      if invalid key --> set to default key
        ---------------------------------------------------
        """ 
        valid = self.valid_key(key)
        if valid:
            block_size = key[0]
            shift = key[1]
            if shift>block_size:
                shift%=block_size
            elif shift<0:
                shift = block_size+shift
            self._key = (block_size,shift)
        else:
            self._key = self.DEFAULT_KEY
        return valid
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Blcok Rotate object. Used for testing
                      output format:
                      Block Rotate Cipher:
                      key = <key>, pad = <pad>
        ---------------------------------------------------
        """
        output = 'Block Rotate Cipher:'
        output+='\n'
        output+='key = {}, pad = {}'.format(self.get_key(),self.get_pad())
        return output
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid block rotate key
        ---------------------------------------------------
        """
        return isinstance(key,tuple) and isinstance(key[0],int) and isinstance(key[1],int) and key[0]>0 and len(key)==2
    
    def set_pad(self,pad):
        """
        ----------------------------------------------------
        Parameters:   pad (str): a padding character
        Return:       success: True/False
        Description:  Sets block rotate pad to given character
                      a pad should be a single character
                      if invalid pad, set to default value
        ---------------------------------------------------
        """ 
        if isinstance(pad, str) and (len(pad)==1 or len(pad)==0):
            self._pad = pad
            return True
        else:
            self._pad = self.DEFAULT_PAD
            return False
    
    def get_pad(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       pad (str): current padding character
        Description:  Returns a copy of current padding character
        ---------------------------------------------------
        """ 
        return deepcopy(self._pad)
        
    def encrypt(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Block Rotation Cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """    
        assert isinstance(plaintext,str), "Error(encrypt): invalid input"
        #find newlines, clean text
        key = self.get_key()
        #find newlines
        newlines = get_positions(plaintext,"\n")
        plaintext = clean_text(plaintext,"\n")
        text = text_to_blocks(plaintext,key[0],True,self.get_pad()) 
        d = 'l'
        if key[1]<0:
            d = 'r'
        ciphertext = ""
        for block in text:
            block = shift_string(block,key[1],d)
            ciphertext+=block
        
        #add newlines back in
        ciphertext = insert_positions(ciphertext,newlines)
          
        return ciphertext

    def decrypt(self,ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Block Rotation Cipher
                      Removes padding if it exist
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """ 
        assert isinstance(ciphertext,str), "Error(decrypt): invalid input"
        #break into blocks, shift, put back together
        key = self.get_key()
        pad = self.get_pad()
        #find newlines
        newlines = get_positions(ciphertext,"\n")
        ciphertext = clean_text(ciphertext,"\n")
        text = text_to_blocks(ciphertext,key[0],True, pad)
        d = 'r'
        if key[1]<0:
            d = 'l'
        plaintext = ""
        for block in text:
            block = shift_string(block,key[1],d)
            plaintext+=block
            
        #remove pad
        while plaintext[-1]==pad:
            plaintext = plaintext[:-1]
        #add newlines
        plaintext = insert_positions(plaintext,newlines)
        return plaintext

    @staticmethod
    def cryptanalyze(ciphertext,args=[0,0,0,None,0.8]):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext (string)
                      args (list):
                            b0: minimum block size (int): default = 0
                            bn: maximum block size (int): default = 0
                            r: rotations (int): default = 0
                            dictionary_file (str): default = None
                            threshold (float): default = 0.8
        Return:       key,plaintext
        Description:  Cryptanalysis of Block Rotate Cipher
                      Returns plaintext and key (r,b)
                      Attempts block sizes from b0 to bn (inclusive)
                      If bn is invalid or unspecified use 20
                      Minimum valid value for b0 is 2
                      Assumes user passes a valid args list
        ---------------------------------------------------
        """
        min_size = args[0]
        max_size= args[1]
        if not isinstance(args[1],int) or args[1]<=0:
            max_size = 20
        rotations = args[2]
        dict_file = args[3]
        if args[3] is None:
            dict_file = "engmix.txt"
        dict_list = load_dictionary(dict_file)
        threshold = args[4]
        found = False
        b = Block_Rotate()
        i = 0
        key = (-1,-1)
        r = -1
        text = ""
        
        if min_size==max_size and min_size>0 and rotations>0:
            b.set_key((max_size,rotations))
            text = b.decrypt(ciphertext)
            if is_plaintext(text, dict_list, threshold):
                found = True
                key = ((max_size,rotations))        
        else:
            if min_size>0:
                i = min_size
            while not found and i<max_size:
                if rotations>0:
                    r = rotations
                else:
                    r = 0
                
                while not found and r<i:
                    b.set_key((i,r))
                    text = b.decrypt(ciphertext)
                    
                    if is_plaintext(text, dict_list, threshold):
                        found = True
                        key = ((i,r))
                    else:
                        r+=1
            
                i+=1
        if not found:
            key = ""
            text = ""
            print("Block_Rotate.cryptanalyze: cryptanalysis failed")
        return key,text

class Alberti:
    """
    ----------------------------------------------------
    Cipher name: Alberti Cipher (1472)
    Key:         (pointer,in_wheel)
    Type:        Substitution Cipher
    Description:Default mode:
                    Outer wheel has a..z0..9
                    Given inner wheel has some random arrangement of a..z0..9
                    Perform simple substitution
                Simple mode:
                    Outer wheel has a..z0..9
                    Inner wheel uses default value
                    Perform simple substitution
                Periodic mode:
                    Outer wheel has a..z0..9
                    Given inner wheel has some random arrangement of a..z0..9
                    Perform simple substitution while changing inner wheel once
                        clockwise every PERIOD number of characters
                In all modes:
                    Outer wheel at a is aligned with (pointer) at inner wheel
                    outer and inner wheel has same characters
                    In encryption/decryption Ignore characters not 
                        defined in the base (wheels)
                     encryption/decryption is case insensitive -->
                        output is always lower case
    ----------------------------------------------------
    """
    #constants
    OUT_WHEEL = 'abcdefghijklmnopqrstuvwxyz0123456789'
    DEFAULT_KEY = ('k','k0v9p1j8m2r7d3l5g4a6zteunwbosfchyqix')
    PERIOD = 8
    MODES = ['default','simple','periodic']
    
    def __init__(self,key=DEFAULT_KEY,mode='default'):
        """
        ----------------------------------------------------
        Parameters:   _key (str,str): pointer,base
                      _mode (str): default = 'default'
        Description:  Alberti Cipher constructor
                      sets _key and _mode
        ---------------------------------------------------
        """
        self._key = key
        self._mode = mode
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str,str)
        Description:  Returns a copy of the Alberti key
        ---------------------------------------------------
        """
        return deepcopy(self._key)
       
    def set_key(self,key):
        """
        ----------------------------------------------------
        Parameters:   key (str,str): tuple(str,str)
        Return:       success: True/False
        Description:  Sets Alberti cipher key to given key
                      if invalid key --> set to default key
                      does not update in_wheel in simple mode
        ---------------------------------------------------
        """ 
        valid = self.valid_key(key)
        if valid:
            if not self.get_mode()=="simple":
                self._key = key
            else:
                self._key = ((key[0],self.DEFAULT_KEY[1]))
        else:
            self._key = self.DEFAULT_KEY
        
        return valid
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Alberti object. Used for testing
                      output format:
                      Alberti Cipher:
                      key = <key>, mode = <mode>
                      <out_wheel>
                      <in_wheel>
        ---------------------------------------------------
        """
        out_wheel,in_wheel = self.get_wheels()
        output = "Alberti Cipher:\nkey = {}, mode = {}\n{}\n{}".format(self.get_key(),self.get_mode(),out_wheel,in_wheel)
        return output
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid alberti key
        ---------------------------------------------------
        """
        # a key (pointer, in_wheel) is valid if pointer is a single char in in_wheel
        #in wheel and out wheel must also have the same chars
        valid = True
        if not(isinstance(key[0],str) and isinstance(key[1],str) and key[0] in key[1]):
            valid = False
            
        a = Alberti()
        out_wheel = a.OUT_WHEEL
        in_wheel = key[1]
        if len(out_wheel)!=len(in_wheel):
            valid = False
        for char in in_wheel:
            if char not in out_wheel:
                valid = False
        return valid
       
    def set_mode(self,mode):
        """
        ----------------------------------------------------
        Parameters:   mode (str): Alberti cipher mode
        Return:       success: True/False
        Description:  Sets Alberti cipher to given mode
                      valid only if defined in MODES
                      Otherwise set to 'default'
                      when setting to simple mode, set in_wheel to default value
        ---------------------------------------------------
        """ 
        valid = mode in self.MODES
        if valid:
            self._mode = mode
            if mode=='simple':
                key = self.get_key()
                self.set_key((key[0],self.DEFAULT_KEY[1]))
        else:
            self._mode = self.MODES[0]
        return valid
    
    def get_mode(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       mode (str): current cipher mode
        Description:  Returns a copy of current mode
        ---------------------------------------------------
        """ 
        return deepcopy(self._mode)
    
    def get_wheels(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       out_wheel (str)
                      in_wheel (str)
        Description:  returns out and in wheels aligned at pointer
        
        
        ---------------------------------------------------
        """
        key = self.get_key()
        in_wheel = key[1]
        pointer = key[0]
        #rotate wheel
        i = 0
        found = False
        while not found:
            if in_wheel[i]==pointer:
                found = True
            else:
                i+=1
            
        in_wheel = shift_string(in_wheel, i, "l")
        
        return self.OUT_WHEEL,in_wheel

    @staticmethod
    def random_wheel():
        """
        ----------------------------------------------------
        Static Method
        Parameters:   -
        Returns:      random_wheel (str)
        Description:  Generates a random arrangement of outer wheel
        ---------------------------------------------------
        """
        a = Alberti()
        outer_chars = a.OUT_WHEEL.split()
        random_wheel = ""
        while len(outer_chars)>0:
            index = random.randint(0,len(outer_chars))
            temp = outer_chars.pop(index)
            random_wheel+=temp
        return random_wheel

    def encrypt(self,plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Alberti Cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        assert isinstance(plaintext,str), 'Error(encrypt): invalid input'
        out_wheel, in_wheel = self.get_wheels()
        ciphertext = ""
        positions = get_positions(out_wheel, in_wheel)
        
        subs_table = self.list_to_dict(positions)
        
        if self.get_mode()=='periodic':
            i = 0
            count = 1
            while i<len(plaintext):
                char = plaintext[i]
                if char.lower() in in_wheel and char.lower() in out_wheel:
                    temp = in_wheel[subs_table[char.lower()]]
                    ciphertext+=str(temp)
                else:
                    ciphertext+=char
                if count==self.PERIOD:
                    in_wheel = shift_string(in_wheel, 1, 'r')
                    positions = get_positions(out_wheel, in_wheel)
                    subs_table = self.list_to_dict(positions)
                    count=0
                i+=1
                count+=1
        else:
            for char in plaintext:
                if char.lower() in in_wheel and char.lower() in out_wheel:
                    temp = in_wheel[subs_table[char.lower()]]
                    ciphertext+=str(temp)
                else:
                    ciphertext+=char
            
            
                
        return ciphertext
    
    def list_to_dict(self,l):
        """
        converts a positions list to a dictionary
        """
        d= {}
        for element in l:
            d[element[0]]=element[1]
        
        return d
    
    def decrypt(self,ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Alberti Cipher
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        assert isinstance(ciphertext,str), "Error(decrypt): invalid input"
        out_wheel, in_wheel = self.get_wheels()
        plaintext = ""
        positions = get_positions(in_wheel, out_wheel)
        
        subs_table = self.list_to_dict(positions)
        
        if self.get_mode()=='periodic':
            i = 0
            count = 1
            while i<len(ciphertext):
                char = ciphertext[i]
                if char.lower() in in_wheel and char.lower() in out_wheel:
                    temp = out_wheel[subs_table[char.lower()]]
                    plaintext+=str(temp)
                else:
                    plaintext+=char
                if count==self.PERIOD:
                    out_wheel = shift_string(out_wheel, -1, 'r')
                    positions = get_positions(in_wheel, out_wheel)
                    subs_table = self.list_to_dict(positions)
                    count=0
                i+=1
                count+=1
        else:
            for char in ciphertext:
                if char.lower() in in_wheel and char.lower() in out_wheel:
                    temp = out_wheel[subs_table[char.lower()]]
                    plaintext+=str(temp)
                else:
                    plaintext+=char
        return plaintext

    @staticmethod
    def cryptanalyze(ciphertext,args=['','','',None,0.8]):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext (string)
                      args (list):
                            pointer: (str): default = ''
                            in_wheel: (str): default = ''
                            mode: (str): default = ''
                            dictionary_file (str): default = None
                            threshold (float): default = 0.8
        Return:       key,plaintext
        Description:  Cryptanalysis of Alberti Cipher
                      Returns plaintext and key (pionter,in_wheel)
                      Assumes user passes a valid args list
        ---------------------------------------------------
        """  
        a = Alberti()
        pointer = args[0]
        in_wheel = args[1]
        if in_wheel=="":
            in_wheel = a.DEFAULT_KEY[1]
        mode = args[2]
        dict_file = args[3]
        threshold = args[4]
        if args[3] is None:
            dict_file = "engmix.txt"
        dict_list = load_dictionary(dict_file)
        key = ""
        text = ""
        found = False
        if pointer!="" and mode!="":
            a.set_mode(mode)
            a.set_key((pointer,in_wheel))
            text = a.decrypt(ciphertext)
            if is_plaintext(text, dict_list, threshold):
                key = (pointer,in_wheel)
                found = True
            else:
                print("Alberti.cryptanalyze: cryptanalysis failed")
        elif pointer=="" and mode=="":
            m=len(a.MODES)-1
            p=0
            while not found and m>=0:
                p=0
                a.set_mode(a.MODES[m])
                while not found and p<len(in_wheel):
                    a.set_key((in_wheel[p],in_wheel))
                    text = a.decrypt(ciphertext)
                    if is_plaintext(text, dict_list, threshold):
                        found = True
                        key = (in_wheel[p],in_wheel)
                    p+=1
                m-=1
        elif pointer=="" and mode!="":
            p=0
            a.set_mode(mode)
            while not found and p<len(in_wheel):
                a.set_key((in_wheel[p],in_wheel))
                text = a.decrypt(ciphertext)
                if is_plaintext(text, dict_list, threshold):
                    found = True
                    key = (in_wheel[p],in_wheel)
                p+=1
        elif pointer!="" and mode=="":
            m=len(a.MODES)-1
            while not found and m>=0:
                a.set_mode(a.MODES[m])
                a.set_key((pointer,in_wheel))
                text = a.decrypt(ciphertext)
                if is_plaintext(text, dict_list, threshold):
                    found = True
                    key = (pointer,in_wheel)
                
                m-=1                 
        else:
            print("Alberti.cryptanalyze: cryptanalysis failed")
            
        if not found:
            text = ""  
        return key,text