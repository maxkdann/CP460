"""
-----------------------------
CP460 (Fall 2021)
Name: <------------------------- edit this
ID:   <------------------------- edit this
Assignment 5
-----------------------------
"""

"""Put any comments to the grader here"""

import utilities
from copy import deepcopy
import math


class MOD:
    """
    ----------------------------------------------------
    Description: Modular Arithmetic Library
    ----------------------------------------------------
    """
    DEFAULT_VALUE = 0
    DEFAULT_MOD = 2
    
    def __init__(self, value=DEFAULT_VALUE, mod=DEFAULT_MOD):
        """
        ----------------------------------------------------
        Parameters:   _value (int): default value = 0
                      _mod(int): default value = 2
        Description:  Creates a number in modular format
                      sets _value and _mod
        ---------------------------------------------------
        """
        self.value = value
        self.mod = mod
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      a MOD object
                      output format:
                      <_value>
        ---------------------------------------------------
        """
        output = str(self.get_value())
        return output
    
    def print(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       -
        Description:  prints string representation of 
                      a MOD object in the following format:
                      <_value> mod <_mod>
        ---------------------------------------------------
        """
        print("{} mod {}".format(self.get_value(), self.get_mod()))
        return 
    
    def set_value(self, value):
        """
        ----------------------------------------------------
        Parameters:   value (int): an arbitrary integer
        Return:       success: True/False
        Description:  Sets MOD object value to given value
                      if invalid value (i.e., not an integer) --> 
                          set to default value
        ---------------------------------------------------
        """ 
        valid = isinstance(value, int)
        if valid:
            self.value = value
        else:
            self.value = MOD.DEFAULT_VALUE
            
        return valid
    
    def set_mod(self, mod):
        """
        ----------------------------------------------------
        Parameters:   mod (int): an arbitrary integer
        Return:       success: True/False
        Description:  Sets MOD object mod to given value
                      if invalid mod (i.e., anything but integers >= 2) --> 
                          set to default mod
        ---------------------------------------------------
        """ 
        valid = isinstance(mod, int) and mod >= 2
        if valid:
            self.mod = mod
        else:
            self.mod = MOD.DEFAULT_MOD
        return valid
    
    def get_value(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       value (int)
        Description:  Returns a copy of the value
        ---------------------------------------------------
        """
        return deepcopy(self.value)
    
    def get_residue(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       residue (int)
        Description:  Returns the residue of the stored value
                        using the stored mod
                      A residue is the smallest positive integer
                      that is congruent to value mod m
                      Example:  residue 16 mod 5 --> 1
        ---------------------------------------------------
        """
        return self.get_value() % self.get_mod()
    
    def get_mod(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       mod (int)
        Description:  Returns a copy of the mod
        ---------------------------------------------------
        """
        return deepcopy(self.mod)

    def get_residue_list(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       residue_list (list)
        Description:  Constructs and returns a list that contains
                        All integers from 0 up to mod -1
                      Example: residue_list(5) --> [0,1,2,3,4]
        ---------------------------------------------------
        """
        residue_list = []
        for i in range(0, self.get_mod()):
            residue_list.append(i)
        return residue_list
    
    def is_congruent(self, num2):
        """
        ----------------------------------------------------
        Parameters:   num2 (MOD): an arbitrary MOD object
        Return:       True/False
        Description:  Checks if current number and given num2 
                        are congruent to each other
                      Both numbers should be of the same mod
        Errors:       if input is not a MOD object return:
                        'Error(MOD.is_congruent): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(num2, MOD):
            return 'Error(MOD.is_congruent): invalid input'
        
        congruent = self.get_mod() == num2.get_mod()
            
        return congruent

    @staticmethod
    def add(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (MOD): an arbitrary MOD object
                      b (MOD): an arbitrary MOD object
        Return:       result (MOD): a + b mod m
        Description:  Adds the values of <a> and <b> and 
                        returns a MOD object containing the residue
                      Example: MOD(11,5) + MOD(3,5) = MOD(4,5)
        Errors:       if one of the inputs is not a MOD object
                      or if <a> and <b> mods are not equal:
                        return 'Error(MOD.add): invalid input'
        ---------------------------------------------------
        """
        # test for valid input
        if not isinstance(a, MOD) or not isinstance(b, MOD) or a.get_mod() != b.get_mod():
            return 'Error(MOD.add): invalid input'
        
        result = MOD((a.get_value() + b.get_value()) % a.get_mod(), a.get_mod())
        return result

    @staticmethod
    def sub(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (MOD): an arbitrary MOD object
                      b (MOD): an arbitrary MOD object
        Return:       result (MOD): <a> - <b> mod m
        Description:  Subtracts the values of <b> from <a> and 
                        returns a MOD object containing the residue
                      Example: MOD(11,5) - MOD(3,5) = MOD(3,5)
        Errors:       if one of the inputs is not a MOD object
                      or if <a> and <b> mods are inequal:
                        return 'Error(MOD.sub): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(a, MOD) or not isinstance(b, MOD) or a.get_mod() != b.get_mod():
            return 'Error(MOD.sub): invalid input'
        
        result = MOD(a.get_value() - b.get_value(), a.get_mod())
        
        val = result.get_value() 
        if val > result.get_mod() or val < 0:
            result.set_value(result.get_residue())
        
        return result
    
    def get_add_inv(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       result (int): additive inverse of current object
        Description:  Computes and returns the additive inverse of the 
                        current object
                      Example: additive inverse of 3 mod 5 is 2
        ---------------------------------------------------
        """
        
        return abs(self.get_value() - self.get_mod())

    @staticmethod
    def get_add_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       add_table (2d list)
        Description:  Construct and return addition table mod m
                        element [r][c] represent r+c mod m
                      Example: MOD.get_add_table(2) --> [[0,1],[1,0]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_add_table): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(m, int) or not m >= 2:
            return 'Error(MOD.get_add_table): invalid input'
        
        add_table = utilities.new_matrix(m, m, 0)
        for i in range(m):
            # reset = 0
            for j in range(m):
                temp = (i + j) % m
                # if temp>m:
                #     temp = reset
                #     reset+=1
                add_table[i][j] = temp
        
        return add_table

    @staticmethod
    def get_sub_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       sub_table (2d list)
        Description:  Construct and return subtraction table mod m
                        element [r][c] represent r-c mod m
                      Example: MOD.get_sub_table(3) --> [[[0,2,1],[1,0,2],[2,1,0]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_sub_table): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(m, int) or not m >= 2:
            return 'Error(Mod.get_sub_table): invalid input'
        
        sub_table = utilities.new_matrix(m, m, 0)
        for i in range(m):
            for j in range(m):
                temp = (i - j) % m
                sub_table[i][j] = temp
        
        return sub_table

    @staticmethod
    def get_add_inv_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       add_inv_table (2d list)
        Description:  Construct and return additive inverse table mod m
                        Top row is num, bottom row is additive inverse
                      Example: MOD.get_add_inv_table(5) --> [[0,1,2,3,4],[0,4,3,2,1]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_add_inv_table): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(m, int) or not m >= 2:
            return 'Error(MOD.get_add_inv_table): invalid input'
        add_inv_table = utilities.new_matrix(2, m, 0)
        
        # first row is just numbers up to m
        for i in range(m):
            add_inv_table[0][i] = i
        # second row is additive inverse
        for i in range(m):
            if i == 0:
                add_inv_table[1][i] = 0
            else:
                add_inv_table[1][i] = abs(add_inv_table[0][i] - m)
        return add_inv_table
    
    @staticmethod
    def mul(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (MOD): an arbitrary MOD object
                      b (MOD): an arbitrary MOD object
        Return:       result (MOD): <a> * <b> mod m
        Description:  Multiplies the values of <a> by <b> and 
                        returns a Mod object containing the residue
                      Example: MOD(11,5) - MOD(2,5) = MOD(2,5)
        Errors:       if one of the inputs is not a MOD object
                      or if <a> and <b> mods are inequal:
                        return 'Error(MOD.mul): invalid input'
        ---------------------------------------------------
        """        
        if not isinstance(a, MOD) or not isinstance(b, MOD) or a.get_mod() != b.get_mod():
            return 'Error(MOD.mul): invalid input'
        
        temp = a.get_value() * b.get_value()
        result = MOD(temp % a.get_mod(), a.get_mod())
        
        return result
    
    @staticmethod
    def get_mul_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       mul_table (2d list)
        Description:  Construct and return multiplication table mod m
                        element [r][c] represent r*c mod m
                      Example: Mod.get_mul_table(4) --> 
                       [[0, 0, 0, 0], [0, 1, 2, 3], [0, 2, 0, 2], [0, 3, 2, 1]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_mul_table): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(m, int) or not m >= 2:
            return 'Error(MOD.get_mul_table): invalid input'
        mul_table = utilities.new_matrix(m, m, 0)
        for i in range(m):
            for j in range(m):
                mul_table[i][j] = (i * j) % m 
        return mul_table

    @staticmethod
    def is_prime(n):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   n (int): an arbitrary integer
        Return:       True/False
        Description:  Check if the given input is a prime number
                      Search Online for an efficient implementation
        ---------------------------------------------------
        """
        if n <= 3:
            return n > 1
        if n % 2 == 0 or n % 3 == 0:
            return False
        i = 5
        while i ** 2 <= n:
            if n % i == 0 or n % (i + 2) == 0:
                return False
            i += 6
        return True

    @staticmethod
    def gcd(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       result (int): the GCD of a and b
        Description:  Computes and returns the greatest common diviser using
                      the standard Eculidean Algorithm.
                      The implementation can be iterative or recursive
        Errors:       if a or b are non positive integers, return:
                        'Error(MOD.gcd): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(a, int) or not isinstance(b, int) or a == 0 or b == 0:
            return 'Error(MOD.gcd): invalid input'
        
        a = abs(a)
        b = abs(b)
        
        while b != 0:
            q = a // b
            r = a - (q * b)
            a = b
            b = r
            
        return a

    @staticmethod
    def is_relatively_prime(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       True/False
        Description:  Check if <a> and <b> are relatively prime
                          i.e., gcd(a,b) equals 1
        Errors:       if a or b are non positive integers, return:
                        'Error(Mod.is_relatively_prime): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(a, int) or not isinstance(b, int) or a < 0 or b < 0:
            return 'Error(MOD.is_relatively_prime): invalid input'
        relatively_prime = MOD.gcd(a, b) == 1
        return relatively_prime

    def has_mul_inv(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       True/False
        Description:  Check if current value has a multiplicative inverse mod m
        ---------------------------------------------------
        """
        
        return MOD.EEA(self.get_value(), self.get_mod())[0] == 1

    @staticmethod
    def EEA(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       result (list): [gcd(a,b), s, t]
        Description:  Uses Extended Euclidean Algorithm to find:
                        gcd(a,b) and <s> and <t> such that:
                        as + bt = gcd(a,b), i.e., Bezout's identity
        Errors:       if a or b are 0 or non-integers
                        'Error(MOD.EEA): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(a, int) or not isinstance(b, int) or a == 0 or b == 0:
            return 'Error(MOD.EEA): invalid input'
        
        u = [abs(a), 1, 0]
        v = [abs(b), 0, 1]
        while v[0] != 0:
            q = math.floor(u[0] / v[0])
            r = [u[0] - q * v[0], u[1] - q * v[1], u[2] - q * v[2]]
            u = v
            v = r
        return u

    def get_mul_inv(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       mul_inv (int or 'NA')
        Description:  Computes and returns the multiplicative inverse of 
                        current value mod m
                      if it does not exist returns 'NA'
        ---------------------------------------------------
        """
        val = self.get_value()
        m = self.get_mod()
        
        u = self.EEA(val, m)
        # check if val and m are relatively prime
        valid = u[0] == 1
        
        mul_inv = 'NA'
        if valid:
            mul_inv = u[1] % m
        return mul_inv

    @staticmethod
    def get_mul_inv_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       mul_inv_table (2d list)
        Description:  Construct and return multiplicative inverse table mod m
                        Top row are numbers 0 --> mod - 1
                        Bottom row is multplicative inverses
                      Example: Mod.get_mul_inv_table(5) --> 
                          [[0,1,2,3,4],['NA',1,3,2,4]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_mul_inv_table): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(m, int) or not m >= 2:
            return 'Error(MOD.get_mul_inv_table): invalid input'
        mul_inv_table = utilities.new_matrix(2, m, 0)
        for i in range(m):
            mul_inv_table[0][i] = i
        mod = MOD(0, m)
        for i in range(m):
            mod.set_value(i)
            mul_inv_table[1][i] = mod.get_mul_inv() 
        return mul_inv_table

    
class Decimation:
    """
    ----------------------------------------------------
    Cipher name: Decimation Cipher
    Key:         (k,start,end)
    Type:        Substitution Cipher
    Description: y = kx mod m
                 x = k(-1)y mod m
                 base = BASE[start:end]
                 m = len(base)
                 Applies only to characters defined in the base
    ----------------------------------------------------
    """
    BASE = utilities.get_base('lower') + ' ' + utilities.get_base('nonalpha') + utilities.get_base('upper')
    DEFAULT_KEY = (3, 0, 26)

    def __init__(self, key=DEFAULT_KEY): 
        """
        ----------------------------------------------------
        Parameters:   _key (tuple(int,int,int)): (k,start,end)
        Description:  Decimation cipher constructor
                      sets _key
        ---------------------------------------------------
        """
        self.key = key
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (int,str)
        Description:  Returns a copy of the Decimation key
        ---------------------------------------------------
        """
        return deepcopy(self.key)

    def get_base(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       base (str)
        Description:  Returns a copy of the decimation base
                        which is a subset of BASE
        ---------------------------------------------------
        """
        key = self.get_key()
        start = key[1]
        end = key[2]
        return deepcopy(Decimation.BASE[start:end])
    
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (tuple): tuple(int,int,int)
        Return:       success: True/False
        Description:  Sets Decimation cipher key to given key
                      and k is stored as a residue value
                      if invalid key --> set to default key
        ---------------------------------------------------
        """ 
        valid = Decimation.valid_key(key)
        
        if valid:
            mod = MOD(key[0], key[2] - key[1])
            if key[0] > key[2] - key[1] or key[0] < 0:
                k = mod.get_residue()
                self.key = (k, key[1], key[2])
            else:
                self.key = key
        else:
            self.key = Decimation.DEFAULT_KEY         
        
        return valid
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Decimation object. Used for testing
                      output format:
                      Decimation Cipher:
                      y = <k>x mod <m>
                      x = <k-1>y mod <m>
        ---------------------------------------------------
        """
        key = self.get_key()
        m = key[2] - key[1]
        k = key[0]
        mod = MOD(k, m)
        k_inverse = mod.get_mul_inv()
        output = "Decimation Cipher:\ny = {}x mod {}\nx = {}y mod {}".format(k, m, k_inverse, m)
        return output
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Decimation key
                      A valid key should be a tuple consisting of three integers
                      <k> should have a multiplicative inverse in mod m
                      start < end, and both are positive valid indexes for BASE
                      The base should contain at least two chars
        ---------------------------------------------------
        """
        valid = True
        if not isinstance(key, tuple):
            valid = False
        elif len(key) != 3:
            valid = False
        elif not (isinstance(key[0], int) and isinstance(key[1], int) and isinstance(key[2], int)):
            valid = False
        elif key[1] > key[2]:
            valid = False
        elif MOD.gcd(key[0], key[2] - key[1]) != 1:
            valid = False
        elif key[2] - key[1] < 2:
            valid = False
        return valid
    
    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Decimation Cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        key = self.get_key()
        k = key[0]
        start = key[1]
        end = key[2]
        base = Decimation.BASE[start:end]
        
        sub_text = self.construct_sub_text(base, k)
        ciphertext = ""
        # perform substitution
        for p in plaintext:
            # search for p in base, use the corresponding index in sub_text
            index = self.find_index(p, base)
            if index == -1:
                ciphertext += p
            else:
                ciphertext += sub_text[index]
        
        return ciphertext
    
    def construct_sub_text(self, base, k):
        m = len(base)
        sub_text = "" 
        # construct sub text
        for b in base:
            # get b's placement in base, that is it's index
            i = base.index(b)
            # i now stores the index of b
            y = (i * k) % m
            sub_text += base[y]
        return sub_text
    
    def find_index(self, char, base):
        '''
        finds the index of char in base
        '''
        index = -1
        i = 0
        found = False
        while i < len(base) and not found:
            if base[i] == char:
                index = i
                found = True
            else:
                i += 1
        return index
    
    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Decimation Cipher
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        key = self.get_key()
        k = key[0]
        start = key[1]
        end = key[2]
        base = Decimation.BASE[start:end]
        
        sub_text = self.construct_sub_text(base, k)
        plaintext = ""
        # perform substitution
        for p in ciphertext:
            # search for p in base, use the corresponding index in sub_text
            index = self.find_index(p, sub_text)
            if index == -1:
                plaintext += p
            else:
                plaintext += base[index]
        
        return plaintext
    
    @staticmethod
    def cryptanalyze_keys(args=[-1, -1, -1]):
        """
        ----------------------------------------------------
        Parameters:   args (list):
                          k (int): if unknown = -1
                          start (int): if unknown = -1
                          end (int): if unknown = -1
        Return:       keys (list)
        Description:  Returns all valid keys
                      Excludes keys which result in no encipherment
                      Assume that at least one arg is known
        ---------------------------------------------------
        """
        k = args[0]
        start = args[1]
        end = args[2]
        keys = []
        
        # cases: 
        # 1. k is known, start and end are known
        # 2. k in unknown, start and end are known
        # 3. k is known, start is unknown, end is known
        # 4. k in known, start is known, end is unknown
        # 5. k and start are unknown, end is unknown
        # 6. k is unknown, start is known, end is unknown
        # 7. k is known, start and end are unknown
        
        # case 1
        if k != -1 and start != -1 and end != -1:
            if k != 0:
                keys.append((k, start, end))
        # case 2
        elif k == -1 and start != -1 and end != -1:
            m = end - start
            mod = MOD()
            mod.set_mod(m)
            for i in range(2, m):
                if i % 2 == 0:
                    continue
                elif MOD.gcd(i, m) != 1:
                    continue
                
                mod.set_value(i)
                mul_inv = mod.get_mul_inv()
                if mul_inv != "NA":
                    keys.append((i, start, end))
        # case 3
        elif k != -1 and start == -1 and end != -1:
            mod = MOD()
            mod.set_value(k)
            for i in range(0, end-1):
                mod.set_mod(end - i) 
                mul_inv = mod.get_mul_inv()
                if mul_inv != "NA":
                    keys.append((k, i, end)) 
        # case 4
        elif k!=-1 and start !=-1 and end==-1:
            mod = MOD()
            mod.set_value(k)
            for i in range(start+2, len(Decimation.BASE)+1):
                mod.set_mod(i-start) 
                mul_inv = mod.get_mul_inv()
                if mul_inv != "NA":
                    keys.append((k, start, i)) 
        #case 5
        elif k==-1 and start==-1 and end!=-1:
            mod = MOD()
            for i in range(0,end-1):
                m = end-i
                for j in range(2,m):
                    if MOD.gcd(j,m)!=1:
                        continue
                    mod.set_value(j)
                    mod.set_mod(m)
                    mul_inv = mod.get_mul_inv()
                    if mul_inv != "NA":
                        keys.append((j, i, end)) 
        #case 6
        if k==-1 and start!=-1 and end==-1:
            mod = MOD()
            for i in range(start+2,len(Decimation.BASE)+1):
                m = i-start
                for j in range(2,m):
                    if MOD.gcd(j,m)!=1:
                        continue
                    mod.set_value(j)
                    mod.set_mod(m)
                    mul_inv = mod.get_mul_inv()
                    if mul_inv != "NA":
                        keys.append((j, start, i)) 
        # case 7 k is known, start and end aren't
        elif k!=-1 and start==-1 and end==-1:
            if k>1:
                mod = MOD()
                mod.set_value(k)
                for i in range(0,len(Decimation.BASE)):#brute force start
                    for j in range(i+k+1,len(Decimation.BASE)+1): #brute force end
                        m = j-i
                        mod.set_mod(m)
                        mul_inv = mod.get_mul_inv()
                        if mul_inv != "NA":
                            keys.append((k, i, j)) 
        return keys
       
    @staticmethod
    def cryptanalyze(ciphertext, args=[-1, -1, -1, None, 0.8]):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
                      args (list):
                          dict_file (str): dictionary file name
                          threshold (float): to be used in is_plaintext
        Return:       key,plaintext
        Description:  Performs cryptanalysis of decimation cipher
                      Assume that the base is some subset of utilitiles.get_base('all')
                      starting at base[0] with an arbitrary length
        ---------------------------------------------------
        """
        k = args[0]
        start = args[1]
        end = args[2]
        dict_file = args[3]
        threshold = args[4]
        
        if dict_file is None:
            dict_list = utilities.load_dictionary('engmix.txt')
        else:
            dict_list = utilities.load_dictionary(dict_file)
        
        possible_keys = Decimation.cryptanalyze_keys([k,start,end])
        print(possible_keys)
        dec = Decimation()
        plaintext = ""
        correct_key = ""
        for key in possible_keys:
            dec.set_key(key)
            text = dec.decrypt(ciphertext)
            if utilities.is_plaintext(text, dict_list, threshold):
                plaintext = text
                correct_key = key
                break
                
        return correct_key,plaintext

    
class Affine:
    """
    ----------------------------------------------------
    Cipher name: Affine Cipher
    Key:         (a,b,start,end)
    Type:        Substitution Cipher
    Description: y = ax + b mod m
                 x = a_inv * (y - b) mod m
                 base = BASE[start:end]
                 m = len(base)
                 Applies only to characters defined in the base
    ----------------------------------------------------
    """
    BASE = utilities.get_base('lower') + ' ' + utilities.get_base('nonalpha') + utilities.get_base('upper')
    DEFAULT_KEY = (17, 9, 0, 26)

    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (tuple(int,int,int,int)): (a,b,start,end)
        Description:  Affine Cipher constructor
                      sets _key
        ---------------------------------------------------
        """
        self.key = key
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (int,str)
        Description:  Returns a copy of the Affine key
        ---------------------------------------------------
        """
        return deepcopy(self.key)

    def get_base(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       base (str)
        Description:  Returns a copy of the Affine base
                        which is a subset of BASE
        ---------------------------------------------------
        """
        key = self.get_key()
        start = key[2]
        end = key[3]
        return deepcopy(Affine.BASE[start:end])
        
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (tuple): tuple(int,int,int,int)
        Return:       success: True/False
        Description:  Sets Affine cipher key to given key
                      If necessary sets a and b to residue values
                      if invalid key --> set to default key
        ---------------------------------------------------
        """ 
        valid = Affine.valid_key(key)
        if valid:
            a = key[0]
            b = key[1]
            mod = MOD(a, key[3] - key[2])
            if a > key[3] - key[2] or a < 0:
                a = mod.get_residue()
            if b > key[3] - key[2] or b < 0:
                mod.set_value(b)
                b = mod.get_residue()
            self.key = (a,b, key[2], key[3])

        else:
            self.key = Affine.DEFAULT_KEY
        return valid
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Affine object. Used for testing
                      output format:
                      Affine Cipher:
                      y = <a>x + <b> mod <m>
                      x = inv(<a>)*(y - <b>) mod <m>
        ---------------------------------------------------
        """
        key = self.get_key()
        a = key[0]
        b = key[1]
        m = key[3]-key[2]
        mod = MOD(a,m)
        inv = mod.get_mul_inv()
        output = "Affine Cipher:\ny = {}x + {} mod {}\nx = {}(y - {}) mod {}".format(a,b,m,inv,b,m)
        return output
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Affine key
                      A valid key is a tuple of 4 integers (a,b,start,end)
                      <a> should have a multiplicative inverse in mod m
                      start < end, and both are positive valid indexes for BASE
                      The base should contain at least two chars
        ---------------------------------------------------
        """
        valid = True
        if not isinstance(key, tuple):
            valid = False
        elif len(key) != 4:
            valid = False
        elif not (isinstance(key[0], int) and isinstance(key[1], int) and isinstance(key[2], int) and isinstance(key[3],int)):
            valid = False
        elif key[2] > key[3]:
            valid = False
        elif MOD.gcd(key[0], key[3] - key[2]) != 1:
            valid = False
        elif key[3] - key[2] < 2:
            valid = False
        return valid
    
    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Decimation Cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        key = self.get_key()
        base = self.get_base()
        a = key[0]
        b = key[1]
        start = key[2]
        end = key[3]
        m = end-start
        
        ciphertext = ""
        
        for p in plaintext:
            index = self.find_index(p, base)
            if index==-1:
                ciphertext+=p
            else:
                y = (a*index + b) % m
                ciphertext+=base[y]
        
        
        return ciphertext
    
    def find_index(self, char, base):
        '''
        finds the index of char in base
        '''
        index = -1
        i = 0
        found = False
        while i < len(base) and not found:
            if base[i] == char:
                index = i
                found = True
            else:
                i += 1
        return index
    
    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Affine Cipher
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """        
        key = self.get_key()
        base = self.get_base()
        a = key[0]
        b = key[1]
        start = key[2]
        end = key[3]
        m = end-start
        
        mod = MOD(a,m)
        mul_inv = mod.get_mul_inv()
        plaintext = ""
        for c in ciphertext:
            index = self.find_index(c, base)
            if index==-1:
                plaintext+=c
            else:
                x = (mul_inv * (index-b))%m
                plaintext+=base[x]
                
        return plaintext
    
    @staticmethod
    def cryptanalyze_keys(args=[-1, -1, -1, -1]):
        """
        ----------------------------------------------------
        Parameters:   args (list):
                          a (int): if unknown = -1
                          b (int): if unknown = -1
                          start (int): if unknown = -1
                          end (int): if unknown = -1
        Return:       keys (list)
        Description:  Returns all valid keys
                      Excludes keys which result in no encipherment
                      Assume that no more than one argument is unknown
        ---------------------------------------------------
        """
        a = args[0]
        b = args[1]
        start = args[2]
        end = args[3]
        m = end-start
        
        keys = []
        #case 1, all are known
        if a!=-1 and b!=-1 and start!=-1 and end!=-1:
            if MOD.gcd(a,m)==1:
                keys.append((a,b,start,end))
        #case 2: b is unknown
        elif a!=-1 and b==-1 and start!=-1 and end!=-1:
            if MOD.gcd(a,m)==1:
                for i in range(0,end+1-start):
                    temp = (a,i,start,end)
                    if Affine.valid_key(temp):
                        if a==1 and i==0:
                            continue
                        else:
                            keys.append(temp)
        #case 3: a is unknown
        elif a==-1 and b!=-1 and start!=-1 and end!=-1:
            if MOD.gcd(a,m)==1:
                for i in range(1,end-start):
                    temp = (i,b,start,end)
                    if Affine.valid_key(temp):
                        if i==1 and b==0:
                            continue
                        else:
                            keys.append(temp)
        #case 4: start is unknown
        elif a!=-1 and b!=-1 and start==-1 and end!=-1:
            for i in range(0,end-1):
                m = end-i
                if MOD.gcd(a,m)==1:
                    temp = (a,b,i,end)
                    if Affine.valid_key(temp):
                        if a==1 and b==0:
                            continue
                        else:
                            keys.append(temp)
        #case 5: end is unknown
        elif a!=-1 and b!=-1 and start!=-1 and end==-1:
            for i in range(start+1,len(Affine.BASE)+1):
                m = i-start
                if MOD.gcd(a,m)==1:
                    temp = (a,b,start,i)
                    if Affine.valid_key(temp):
                        if a==1 and b==0:
                            continue
                        else:
                            keys.append(temp)
        return keys
            
    @staticmethod
    def cryptanalyze(ciphertext, args=[-1, -1, -1, -1, None, 0.8]):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
                      args (list):
                          a (int): if unknown = -1
                          b (int): if unknown = -1
                          start (int): if unknown = -1
                          end (int): if unknown = -1
                          dict_file (str): dictionary file name
                          threshold (float): to be used in is_plaintext
        Return:       key,plaintext
        Description:  Performs cryptanalysis of affine cipher
                      Attempts keys from cryptanalyze_keys
                      returns two empty strings if it fails
        ---------------------------------------------------
        """
        a = args[0]
        b = args[1]
        start = args[2]
        end = args[3]
        dict_file = args[4]
        threshold = args[5]
        
        if dict_file is None:
            dict_list = utilities.load_dictionary('engmix.txt')
        else:
            dict_list = utilities.load_dictionary(dict_file)
            
        key = ""
        plaintext = ""
        
        keys = Affine.cryptanalyze_keys([a,b,start,end])
        a = Affine()
        print(keys)
        for k in keys:
            a.set_key(k)
            text = a.decrypt(ciphertext)
            if utilities.is_plaintext(text, dict_list, threshold):
                key = k
                plaintext = text
                break
        
        
        return key, plaintext
