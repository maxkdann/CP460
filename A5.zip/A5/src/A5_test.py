from A5 import MOD, Decimation, Affine

def test_MOD():
    print('{}'.format('-'*40))
    print("Start of Modular Arithmetic Testing")
    print()
    
    print('1- Testing basics:')
    n = MOD()
    print('Object n is created using default constructor')
    print('print using __str__ = {}'.format(n))
    print('print using n.print() = ',end='')
    n.print()
    print('get_value() = {}'.format(n.get_value()))
    print('get_mod() = {}'.format(n.get_mod()))
    print('n.set_value(6) = {}'.format(n.set_value(6)))
    print(n)
    n.print()
    print('n.set_mod(11) = {}'.format(n.set_mod(11)))
    print(n)
    n.print()
    print('n.set_value("a") = {}'.format(n.set_value('a')))
    print(n)
    n.print()
    print('n.set_mod("b") = {}'.format(n.set_mod('b')))
    print(n)
    n.print()
    print()

    print('2- Testing residue:')
    cases = [[9,4],[3,9],[243,15]]
    for c in cases:
        n = MOD(c[0],c[1])
        n.print()
        print('n.get_residue() = {}'.format(n.get_residue()))
        print('n.get_residue_list() = {}'.format(n.get_residue_list()))
    print()
    
    print('3- Testing is_congruent:')
    n1 = MOD(11,33)
    print('n1 = ',end='')
    n1.print()
    cases = [[26,15],[117,37],[344,37]]
    for c in cases:
        n2 = MOD(c[0],c[1])
        print('n2 = ',end='')
        n2.print()
        print('n1.is_congruent(n2) = {}'.format(n1.is_congruent(n2)))
    print()
    
    print('4- Testing add:')
    n1 = [MOD(17,7),MOD(-17,7),MOD(16,4)]
    n2 = [MOD(23,7),MOD(17,7), MOD(16,8)]
    for i in range(len(n1)):
        n1[i].print()
        n2[i].print()
        print('MOD.add({},{}) = '.format(n1[i],n2[i]),end='')
        n3 = MOD.add(n1[i],n2[i])
        if(type(n3)!= str):
            n3.print()
        else:
            print(n3)
        print()
    
    print('5- Testing sub:')
    n1 = [MOD(17,7),MOD(-17,7),MOD(16,4)]
    n2 = [MOD(25,7),MOD(17,7), MOD(16,8)]
    for i in range(len(n1)):
        n1[i].print()
        n2[i].print()
        print('MOD.sub({},{}) = '.format(n1[i],n2[i]),end='')
        n3 = MOD.sub(n1[i],n2[i])
        if(type(n3)!= str):
            n3.print()
        else:
            print(n3)
        print()
    
    print('6- Testing additive inverse:')
    n1 = [MOD(3,5), MOD(5,9),MOD(2,8)]
    for n in n1:
        print('n = ',end='')
        n.print()
        print('n.get_add_inv() = {}'.format(n.get_add_inv()))
        print()
    
    print('7- Testing additive and subtractive tables: ')
    cases = [7, 11, 0]
    for c in cases:
        print('m = {}'.format(c))
        print('additive_table  = ')
        print(MOD.get_add_table(c))
        print('subtractive_table = ')
        print(MOD.get_sub_table(c))
        print()

    print('8- Testing additive inverse table tables: ')
    cases = [7, 11, 0]
    for c in cases:
        print('m = {}'.format(c))
        print('add_inv_table  = ')
        print(MOD.get_add_inv_table(c))
        print()
    
    print('9- Testing mul:')
    n1 = [MOD(17,7),MOD(-17,7),MOD(16,4)]
    n2 = [MOD(22,7),MOD(17,7), MOD(16,8)]
    for i in range(len(n1)):
        n1[i].print()
        n2[i].print()
        print('MOD.mul({},{}) = '.format(n1[i],n2[i]),end='')
        n3 = MOD.mul(n1[i],n2[i])
        if(type(n3)!= str):
            n3.print()
        else:
            print(n3)
        print()
        
    print('10- Testing multiplicative tables: ')
    cases = [6, 11, 0]
    for c in cases:
        print('m = {}'.format(c))
        print('mul_table  = ')
        print(MOD.get_mul_table(c))
        print()
        
    print('11- Testing is_prime:')
    cases = [97,479,1044,0,-17,-11, 1381]
    for c in cases:
        print('MOD.is_prime({}) =  {}'.format(c,MOD.is_prime(c)))
    print()
    
    print('12- Testing gcd:')
    cases = [[629,357],[440,700],[-30,700],[540,-539],[711,0],[0,311],[[9],27]]
    for c in cases:
        print('MOD.gcd({},{}) =  {}'.format(c[0],c[1],MOD.gcd(c[0],c[1])))
    print()
    
    print('13- Testing is_relatively_prime:')
    cases = [[4,5],[540,539],[18,26],[0,26],[[1],26]]
    for c in cases:
        print('is_relatively_prime({},{}) = {}'.format(c[0],c[1],MOD.is_relatively_prime(c[0],c[1])))
    print()
    
    print('14- Testing has_mul_inv:')
    cases = [MOD(4,5),MOD(17,26),MOD(18,26),MOD(0,26),MOD(13,39)]
    for c in cases:
        print('has_mul_inv({}) = {}'.format(c,c.has_mul_inv()))
    print()
    
    print('15- Testing EEA:')
    cases = [[700,440],[88,35],[35,88], [-88,35],[88,-35],[0,777]]
    for c in cases:
        print('MOD.EEA({},{}) = {}'.format(c[0],c[1],MOD.EEA(c[0],c[1])))
    print()
    
    print('16- Testing get_mul_inv:')
    cases = [MOD(23,26),MOD(5,6),MOD(15,13),MOD(24,26),MOD(700,440),MOD(0,777)]
    for c in cases:
        print('get_mul_inv({}) =   {}'.format(c,c.get_mul_inv()))
    print()

    print('17- Testing multiplicative inverse table: ')
    cases = [11, 6, 0]
    for c in cases:
        print('m = {}'.format(c))
        print('MOD.mul_inv_table  = ')
        print(MOD.get_mul_inv_table(c))
        print()

    print('End of Modular Arithmetic Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_decimation_basics():
    print('{}'.format('-'*40))
    print("Start of Decimation Basic Testing")
    print()

    print('Creating a decimation cipher object using default constructor:')
    d = Decimation()
    print(d)
    print()
    
    print('Testing Decimation.valaid_key:')
    cases = [[7,0,26],(11.2,0,26),(130,200),(7,0,'77'),(13,0,26),(18,15,3),
             (22,31,99),(3,59,60),(11,0,26),(17,3,41)]
    for case in cases:
        print('{} --> {}'.format(str(case), Decimation.valid_key(case)))
    print()
    
    print('Testing set_key, get_key, get_base and __str__:')
    cases = [(7,0,26),(19,3,39),(-5,4,41), (632,11,84), (46,13,82)]
    for c in cases:
        print('Setting Decimation key to {}'.format(c))
        print('\tSuccess = {}'.format(d.set_key(c)))
        print('\tget_key = {}'.format(d.get_key()))
        print('\tget_base = {}'.format(d.get_base()))
        print(d)
        print()
        
    print('End of Decimation Cipher basic Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_decimation():
    print('{}'.format('-'*40))
    print("Start of Decimation Testing")
    print()
    
    print('--------------- Testing Encryption/Decryption:')
    
    keys = [(5,0,26),(46,0,29),(10,4,61),(11,11,91)]
    plaintexts = ['Strike in progress', 'Is mission accomplished?', 'Mission Failed!', 'Plan B ... initiated']
    
    d = Decimation()
    
    for i in range(len(keys)):
        key = keys[i]
        plaintext = plaintexts[i]
        d.set_key(key)
        print(d)
        print('plaintext =  ',plaintext)
        ciphertext = d.encrypt(plaintext)
        if ciphertext != '':
            print('ciphertext=  ',ciphertext)
        plaintext2 = d.decrypt(ciphertext)
        if plaintext2 != '':
            print('plaintext2=  ',plaintext2)
        print()
    
    print('End of Decimation Cipher Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_decimation_cryptanalysis():
    print('{}'.format('-'*40))
    print("Start of Decimation Cryptanalysis Testing")
    print()
    
    print('Testing cryptanalyze_keys:')
    cases = [[0,0,26],[11,0,26],[-1,0,26],[-1,3,49],[9,-1,29],[23,-1,33],
             [2,5,-1],[13,42,-1],[-1,-1,32], [-1,-1,9], [-1,15,-1], [-1,56,-1], 
             [1,-1,-1],[88,-1,-1],[59,-1,-1]]
    for c in cases:
        print('args = {}'.format(c))
        keys = Decimation.cryptanalyze_keys(c)
        print('#keys = {}'.format(len(keys)))
        if keys != []:
            print('keys[:20] = {}'.format(keys[:20]))
            print('keys[-1] = {}'.format(keys[-1]))
        print()
    
    print('Testing cryptanalysis:')
    in_file = open('ciphertext1.txt','r')
    ciphertexts = in_file.readlines()
    in_file.close()
    c = []
    for i in range(len(ciphertexts)):
        c = [cipher.strip('\n') for cipher in ciphertexts]  
    args = [[-1,0,26,None,0.9], [29,10,-1,None,0.9],[28,-1,-1,None,0.85],
            [-1,-1,61,None, 0.85], [33,19,-1,None,0.85], [88,-1,90,None,0.85]]
    for i in range(len(c)):
        key,plaintext = Decimation.cryptanalyze(c[i],args[i])
        print('ciphertext= {}'.format(c[i]))
        print('plaintext = {}'.format(plaintext))
        print('key       = {}'.format(key))
        print()
        
    print('End of Decimation Cryptanalysis Testing')
    print('{}'.format('-'*40))
    print()
    
    return

def test_affine_basics():
    print('{}'.format('-'*40))
    print("Start of Affine Basic Testing")
    print()

    print('Creating a affine cipher object using default constructor:')
    affine = Affine()
    print(affine)
    print()
    
    print('Testing Affine.valaid_key:')
    cases = [[3,5,0,12],(3,5,0),(3,5,'0',13),(3,5,29,14),(13,5,0,26),(11,5,0,26),(14,24,6,37)]
    for c in cases:
        print('{:15s} --> {}'.format(str(c), Affine.valid_key(c)))
    print()
    
    print('Testing set_key, get_key, get_base and __str__:')
    cases = [(11,5,0,25),(14,124,6,37),(-5,22,0,71)]
    for c in cases:
        print('Setting Affine key to {}'.format(c))
        print('\tset_key success = {}'.format(affine.set_key(c)))
        print('\tget_key = {}'.format(affine.get_key()))
        print('\tget_base = {}'.format(affine.get_base()))
        print(affine)
        print()
        
    print('End of Affine Cipher basic Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_affine():
    print('{}'.format('-'*40))
    print("Start of Affine Testing")
    print()
    
    print('--------------- Testing Encryption/Decryption:')
    
    plaintexts = ['Strike in progress', 'Is mission accomplished?', 'Mission Failed!', 'Plan B ... initiated']
    keys = [(5,8,0,26),(45,3,0,29),(10,19,0,41),(11,17,2,88)]
    affine = Affine()
    
    for i in range(len(keys)):
        k = keys[i]
        plaintext = plaintexts[i]
        affine.set_key(k)
        print(affine)
        print('plaintext =  ', plaintext)
        ciphertext = affine.encrypt(plaintext)
        if ciphertext != '':
            print('ciphertext=  ',ciphertext)
        plaintext2 = affine.decrypt(ciphertext)
        if plaintext2 != '':
            print('plaintext2=  ',plaintext2)
        print()
    
    print('End of Affine Cipher Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_affine_cryptanalysis():
    print('{}'.format('-'*40))
    print("Start of Affine Cryptanalysis Testing")
    print()
    
    print('Testing cryptanalyze_keys:')
    cases = [[5,2,0,26], [13,14,0,26],[8,-1,0,27], [1,-1,3,40], [-1,6,4,45],[-1,7,5,49], 
             [-1,0,3,16],[5,11,-1,29], [1,0,-1,28], [19,6,55,-1], [18,15,54,-1]]
    for c in cases:
        print('base = {}'.format(c))
        keys = Affine.cryptanalyze_keys(c)
        print('#keys = {}'.format(len(keys)))
        print('keys[:10] = {}'.format(keys[:10]))
        if keys != []:
            print('keys[-1] = {}'.format(keys[-1]))
        print()
        
    print('Testing cryptanalysis:')
    in_file = open('ciphertext2.txt','r')
    ciphertexts = in_file.readlines()
    in_file.close()
    
    cases = [[-1,18,0,26,None,0.9],[11,-1,0,39,None,0.9],[21,23,0,-1,None,0.85],
             [8,55,-1,81,None,0.8],[23,34,13,91,None,0.8]]
    for i in range(len(ciphertexts)):
        ciphertext = ciphertexts[i].strip('\n')
        key,plaintext = Affine.cryptanalyze(ciphertext,cases[i])
        print('ciphertext= {}'.format(ciphertext))
        print('plaintext = {}'.format(plaintext))
        print('key       = {}'.format(key))
        print()
        
    print('End of Affine Cryptanalysis Testing')
    print('{}'.format('-'*40))
    print()
    return

test_MOD()
test_decimation_basics()
test_decimation()
test_decimation_cryptanalysis()
test_affine_basics()
test_affine()
test_affine_cryptanalysis()