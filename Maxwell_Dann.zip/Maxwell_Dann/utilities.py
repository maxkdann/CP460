"""
-----------------------------
CP460 (Fall 2021)
Name: Maxwell Dann
ID: 190274440
utilities file
-----------------------------
"""

"""comment for grader: line 364 of the testing file says
    decode_B6('0100000') = Error(decode_B6): invalid input
    it is assumed the correct output is actually    
    decode_B6('0100000') = Error(decode): invalid input
    
    based on the fact that we were not required to write a function called decode_B6 and thus
    an error cannot occur in such a function
    """

DICT_FILE = 'engmix.txt'
PAD = 'q'

'______________________________________________________________________________'


def get_base(base_type):
    """
    ----------------------------------------------------
    Parameters:   base_type (str) 
    Return:       result (str)
    Description:  Return a base string containing a subset of ASCII charactes
                  Defined base types:
                  lower, upper, alpha, lowernum, uppernum, alphanum, special, nonalpha, B6, BA, all
                      lower: lower case characters
                      upper: upper case characters
                      alpha: upper and lower case characters
                      lowernum: lower case and numerical characters
                      uppernum: upper case and numerical characters
                      alphanum: upper, lower and numerical characters
                      special: punctuations and special characters (no white space)
                      nonalpha: special and numerical characters
                      B6: num, lower, upper, space and newline
                      BA: upper + lower + num + special + ' \n'
                      all: upper, lower, numerical and special characters
    Errors:       if invalid base type, print error msg, return empty string
    ---------------------------------------------------
    """
    lower = "".join([chr(ord('a') + i) for i in range(26)])
    upper = lower.upper()
    num = "".join([str(i) for i in range(10)])
    special = ''
    for i in range(ord('!'), 127):
        if not chr(i).isalnum():
            special += chr(i)
            
    result = ''
    if base_type == 'lower':
        result = lower
    elif base_type == 'upper':
        result = upper
    elif base_type == 'alpha':
        result = upper + lower
    elif base_type == 'lowernum':
        result = lower + num
    elif base_type == 'uppernum':
        result = upper + num
    elif base_type == 'alphanum':
        result = upper + lower + num
    elif base_type == 'special':
        result = special
    elif base_type == 'nonalpha':
        result = special + num
    elif base_type == 'B6':  # 64 symbols
        result = num + lower + upper + ' ' + '\n'
    elif base_type == 'BA':  # 96 symbols
        result = upper + lower + num + special + ' \n'
    elif base_type == 'all':
        result = upper + lower + num + special
    else:
        print('Error(get_base): undefined base type')
        result = ''
    return result


'______________________________________________________________________________'


def get_language_freq(language='English'):
    """
    ----------------------------------------------------
    Parameters:   language (str): default = English 
    Return:       freq (list of floats) 
    Description:  Return frequencies of characters in a given language
                  Current implementation supports English language
                  If unsupported language --> print error msg and return []
    ---------------------------------------------------
    """
    if language == 'English':
        return [0.08167, 0.01492, 0.02782, 0.04253, 0.12702, 0.02228, 0.02015,
                0.06094, 0.06966, 0.00153, 0.00772, 0.04025, 0.02406, 0.06749,
                0.07507, 0.01929, 0.00095, 0.05987, 0.06327, 0.09056, 0.02758,
                0.00978, 0.0236, 0.0015, 0.01974, 0.00074]
    else:
        print('Error(get_language_freq): unsupported language')
        return []

    
'______________________________________________________________________________'


def file_to_text(filename):
    """
    ----------------------------------------------------
    Parameters:   filename (str)
    Return:       contents (str)
    Description:  Utility function to read contents of a file
                  Can be used to read plaintext or ciphertext
    Asserts:      filename is a valid name
    ---------------------------------------------------
    """
    file = open(filename, "r")
    contents = file.read()
    return contents


'______________________________________________________________________________'


def text_to_file(text, filename):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  filename (str)            
    Return:       no returns
    Description:  Utility function to write any given text to a file
                  If file already exist, previous contents will be erased
    Asserts:      text is a string and filename is a valid filename
    ---------------------------------------------------
    """
    file = open(filename, "w")
    file.write(text)
    file.close()
    return


'______________________________________________________________________________'


def is_valid_filename(filename):
    """
    ----------------------------------------------------
    Parameters:   filename (str)
    Return:       True/False
    Description:  Checks if given input is a valid filename 
                  a filename should have at least 3 characters
                  and contains a single dot that is not the first or last character
    ---------------------------------------------------
    """
    valid = True
    dotcount = 0
    # check length
    if(len(filename) < 4):
        valid = False  
    # check first and last char
    elif(filename[0] == "." or filename[-1] == "."):
        valid = False
    # check to make sure name contains a dot and only one dot
    for s in filename:
        if s == '.':
            dotcount += 1
        
    if dotcount != 1:
        valid = False
    return valid


'______________________________________________________________________________'

   
def load_dictionary(dict_file=None):
    """
    ----------------------------------------------------
    Parameters:   dict_file (str): filename
                        default value = None
    Return:       dict_list (list): 2D list
    Description:  Reads a given dictionary file
                  dictionary is assumed to be formatted as each word in a separate line
                  Returns a list of lists, list 0 contains all words starting with 'a'
                  list 1 all words starting with 'b' and so forth.
                  if no parameter given, use default file (DICT_FILE)
    Errors:       if invalid filename, print error msg, return []
    ---------------------------------------------------
    """
    # check valid file name
    valid = is_valid_filename(dict_file)
    assert valid == True, "Error(load_dictionary): invalid input"
    dict_list = []
    file = open(dict_file, "r", encoding="ISO-8859-15")
    line = file.readline()
    index = 0
    prev_index = -999
    while line:
        line = line.strip()
        index = ord(line[0])
        if index != prev_index:
            dict_list.append([])
        prev_index = index
        index -= 97
        dict_list[index].append(line)
        line = file.readline()
    return dict_list


'______________________________________________________________________________'


def text_to_words(text):
    """
    ----------------------------------------------------
    Parameters:   text (str)
    Return:       word_list (list)
    Description:  Reads a given text
                  Returns a list of strings, each pertaining to a word in the text
                  Words are separated by a white space (space, tab or newline)
                  Gets rid of all special characters at the start and at the end
    Asserts:      text is a string
    ---------------------------------------------------
    """
    valid = isinstance(text, str)
    assert valid == True, "Error(text_to_words): invalid input"
    word_list = []
    text = text.split()
    for word in text:
        if word.isalnum():
            word_list.append(word)
        else:
            temp = word
            while not temp == "" and not temp[0].isalnum() and not temp[-1].isalnum():
                temp = temp[1:-1]
            while not temp == "" and not temp[-1].isalnum():
                temp = temp[:-1]
            while not temp == "" and not temp[0].isalnum():
                temp = temp[1:]
            word_list.append(temp)
    return word_list


'______________________________________________________________________________'


def analyze_text(text, dict_list):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  dict_list (list)
    Return:       matches (int)
                  mismatches (int)
    Description:  Reads a given text, checks if each word appears in given dictionary
                  Returns number of matches and mismatches.
                  Words are compared in lowercase
                  Assumes a proper dict_list
    Asserts:      text is a string and dict_list is a list
    ---------------------------------------------------
    """
    valid = isinstance(text, str) and isinstance(dict_list, list)
    assert valid == True, "Error(analyze_text): invalid input"
    matches = 0
    mismatches = 0
    text = text_to_words(text)
    for word in text:
        word = word.lower()
        match = False
        if word == "":
            mismatches+=1
        else:
            index = ord(word[0])-97
            if not index>=0 and index<27:
                mismatches+=1
            else:
                for dict_word in dict_list[index]:
                    if word==dict_word:
                        match = True
                        matches+=1
                        break
                if not match:
                    mismatches+=1
    return matches, mismatches


'______________________________________________________________________________'


def is_plaintext(text, dict_list, threshold=0.9):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  dict_list (list): dictionary list
                  threshold (float): number between 0 to 1
                      default value = 0.9
    Return:       True/False
    Description:  Check if a given file is a plaintext
                  If #matches/#words >= threshold --> True
                      otherwise --> False
                  If invalid threshold, set to default value of 0.9
                  An empty text should return False
                  Assumes a valid dict_list is passed
    ---------------------------------------------------
    """
    plaintext = False
    matches, mismatches = analyze_text(text, dict_list)
    if matches / (matches+mismatches) >= threshold:
        plaintext = True
    
    return plaintext


'______________________________________________________________________________'


def new_matrix(r, c, fill):
    """
    ----------------------------------------------------
    Parameters:   r: #rows (int)
                  c: #columns (int)
                  fill (str,int,double)
    Return:       matrix (2D List)
    Description:  Create an empty matrix of size r x c
                  All elements initialized to fill
                  minimum #rows and #columns = 2
                  If invalid value given, set to 2
    ---------------------------------------------------
    """
    if not isinstance(r, int) or r < 2:
        r = 2
    if not isinstance(c, int) or c < 2:
        c = 2
    matrix = [[fill]*c for i in range(r)]
                       
    return matrix


'______________________________________________________________________________'


def print_matrix(matrix):
    """
    ----------------------------------------------------
    Parameters:   matrix (2D List)
    Return:       -
    Description:  prints a matrix each row in a separate line
                  items separated by a tab
                  Assumes given parameter is a valid matrix
    ---------------------------------------------------
    """
    for i in range(len(matrix)):
        for j in range(len(matrix[i])):
            print(matrix[i][j], end="        ")
        print()
    return


'______________________________________________________________________________'


def index_2d(input_list, item):
    """
    ----------------------------------------------------
    Parameters:   input_list (list): 2D list
                  item (?)
    Return:       i (int): row number
                  j (int): column number
    Description:  Performs linear search on input list to find "item"
                  returns i,j, where i is the row number and j is the column number
                  if not found returns -1,-1
    Asserts:      input_list is a list
    ---------------------------------------------------
    """
    valid = isinstance(input_list, list)
    assert valid == True, "Error(index_2d): invalid input"
    found = False
    row = -1
    col = -1
    for i in range(len(input_list)):
        if found:
            break
        for j in range(len(input_list[i])):
            if(input_list[i][j] == item):
                row = i
                col = j
                found = True
    return row, col


'______________________________________________________________________________'


def shift_string(s, n, d='l'):
    """
    ----------------------------------------------------
    Parameters:   s (string): input string
                  n (int): number of shifts
                  d (str): direction 'l' or 'r'
    Return:       update_text (str)
    Description:  Shift a given string by given number of shifts (circular shift)
                  If shifts is a negative value, direction is changed
                  If no direction is given or if it is not 'l' or 'r' set to 'l'
    Asserts:      text is a string and shifts is an integer
    ---------------------------------------------------
    """
    valid = isinstance(s, str) and isinstance(n, int)
    assert valid == True, "Error(shift_string): invalid input"
    output_list = [0] * len(s)
    index = 0
    if d != 'r' and d != 'l':
            d = 'l'
    if n < 0:
        if d == 'r':
            d = 'l'
        else:
            d = 'r'
        n *= -1
    if n > len(s):
        n = n % len(s)
    for letter in s:
        letter_index = index
        if d == 'l':
            letter_index -= n
        else:
            letter_index += n
        if letter_index > len(output_list) - 1:
            letter_index -= len(output_list)
        output_list[letter_index] = letter
        index += 1
    
    output = ""
    for c in output_list:
        output += c
    return output


'______________________________________________________________________________'


def matrix_to_string(matrix):
    """
    ----------------------------------------------------
    Parameters:   matrix (2D List)
    Return:       text (string)
    Description:  convert a 2D list of characters to a string
                  from top-left to right-bottom
                  Assumes given matrix is a valid 2D character list
    ---------------------------------------------------
    """
    output = ""
    for i in range(len(matrix)):
        for j in range(len(matrix[i])):
            output += matrix[i][j]
    return output


'______________________________________________________________________________'


def get_positions(text, base):
    """
    ----------------------------------------------------
    Parameters:   text (str): input string
                  base (str):  stream of unique characters
    Return:       positions (2D list)
    Description:  Analyzes a given text for any occurrence of base characters
                  Returns a 2D list with characters and their respective positions
                  format: [[char1,pos1], [char2,pos2],...]
                  Example: get_positions('I have 3 cents.','c.h') -->
                      [['h',2],['c',9],['.',14]]
                  items are ordered based on their occurrence in the text
    Asserts:      text and base are strings
    ---------------------------------------------------
    """
    valid = isinstance(text, str) and isinstance(base, str)
    assert valid == True, "Error(get_positions): invalid input"
    positions = []
    p_index = 0
    for i in range(len(text)):
        for j in range(len(base)):
            if text[i]==base[j]:
                positions.append([])
                positions[p_index].append(text[i])
                positions[p_index].append(i)
                p_index+=1
    
    return positions


'______________________________________________________________________________'


def clean_text(text, base):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  base (str)
    Return:       updated_text (str)
    Description:  Constructs and returns a new text which has
                  all characters in original text after removing base characters
    Asserts:      text and base are strings
    ---------------------------------------------------
    """
    # iterate through text, if the ith character in text exists in base, move to next character
    # else add to output string
    valid = isinstance(text, str) and isinstance(base, str)
    assert valid == True, "Error(clean_text): invalid input"
    updated_text = ""
    for letter in text:
        valid = True
        for b in base:
            if b == letter:
                valid = False
        if valid:
            updated_text += letter
    return updated_text


'______________________________________________________________________________'


def insert_positions(text, positions):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  positions (list): [[char1,pos1],[char2,pos2],...]]
    Return:       updated_text (str)
    Description:  Inserts all characters in the positions 2D list (generated by get_positions)
                  into their respective locations
                  Assumes a valid positions 2d list is given
    Asserts:      text is a string and positions is a list
    ---------------------------------------------------
    """
    valid = isinstance(text, str) and isinstance(positions, list)
    assert valid == True, "Error(get_positions): invalid input"
    for i in range(len(positions)):
        text = text[:positions[i][1]] + positions[i][0] + text[positions[i][1]:]
    return text


'______________________________________________________________________________'


def text_to_blocks(text, b_size, padding=False, pad=PAD):
    """
    ----------------------------------------------------
    Parameters:   text (str): input string
                  block_size (int)
                  padding (bool): False(default) = no padding, True = padding
                  pad (str): padding character, default = PAD
    Return:       blocks (list)
    Description:  Create a list containing strings each of given block size
                  if padding flag is set, pad empty blocks using given padding character
                  if no padding character given, use global PAD
    Asserts:      text is a string and block_size is a positive integer
    ---------------------------------------------------
    """
    valid = isinstance(text, str) and isinstance(b_size, int) and b_size > 0
    assert valid == True, "Error(text_to_blocks): invalid input"
    blocks = []
    block_index = 0;
    temp = ""
    for t in text:
        temp += t
        block_index += 1
        if block_index == b_size:
            block_index = 0
            blocks.append(temp)
            temp = ""
    if temp != "":
        if padding:
            temp += pad * (b_size - block_index)
        blocks.append(temp)
    return blocks


'______________________________________________________________________________'


def blocks_to_baskets(blocks):
    """
    ----------------------------------------------------
    Parameters:   blocks (list): list of equal size strings
    Return:       baskets: (list): list of equal size strings
    Description:  Create k baskets, where k = block_size
                  basket[i] contains the ith character from each block
    Errors:       if blocks are not strings or are of different sizes -->
                    print 'Error(blocks_to_baskets): invalid blocks', return []
    ----------------------------------------------------
    """
    b_size = len(str(blocks[0]))
    if not isinstance(blocks,list):
        print("Error(blocks_to_baskets): invalid blocks")
        return []
    for b in blocks:
        if not isinstance(b, str):
            print("Error(blocks_to_baskets): invalid blocks")
            return []
        if len(b) != b_size:
            print("Error(blocks_to_baskets): invalid blocks")
            return []
        
    baskets = [""] * len(str(blocks[0]))
    for i in range(len(blocks)):
        for j in range(len(blocks[i])):
            baskets[j] += blocks[i][j]
    
    return baskets


'______________________________________________________________________________'


def compare_texts(text1, text2):
    """
    ----------------------------------------------------
    Parameters:   text1 (str)
                  text2 (str)
    Return:       matches (int)
    Description:  Compares two strings and returns number of matches
                  Comparison is done over character by character
    Assert:       text1 and text2 are strings
    ----------------------------------------------------
    """
    valid = isinstance(text1, str) and isinstance(text2, str)
    assert valid == True, "Error(get_freq): invalid input"
    matches = 0
    i = 0
    if len(text1) < len(text2):
        shorttext = text1
        longtext = text2
    else:
        shorttext = text2
        longtext = text1
    
    for t in shorttext:
        if t == longtext[i]:
            matches += 1
        i += 1
    
    return matches


'______________________________________________________________________________'


def get_freq(text, base=''):
    """
    ----------------------------------------------------
    Parameters:   text (str)
                  base (str): default = ''
    Return:       count_list (list of floats) 
    Description:  Finds character frequencies (count) in a given text
                  Default is English language (counts both upper and lower case)
                  Otherwise returns frequencies of characters defined in base
    Assert:       text is a string
    ----------------------------------------------------
    """
    valid = isinstance(text, str)
    assert valid == True, "Error(get_freq): invalid input"
    count_list = []
    if len(base) > 0:
        count_list = [0] * len(base)
    letter_index = 0
    for b in base:
        letter_count = 0
        for t in text:
            if  b == t:
                letter_count += 1
        count_list[letter_index] = letter_count
        letter_index += 1
    return count_list


'______________________________________________________________________________'


def is_binary(b):
    """
    ----------------------------------------------------
    Parameters:   b (str): binary number
    Return:       True/False
    Description:  Checks if given input is a string that represent a valid
                  binary number
                  An empty string, or a string that contains other than 0 or 1
                  should return False
    ---------------------------------------------------
    """
    valid = True
    if not isinstance(b, str):
        valid = False
    else:
        for c in b:
            if c != '0' and c != '1':
                valid = False
                break
    return valid


'______________________________________________________________________________'


def bin_to_dec(b):
    """
    ----------------------------------------------------
    Parameters:   b (str): binary number
    Return:       decimal (int)
    Description:  Converts a binary number into corresponding integer
    Errors:       if not a valid binary number: 
                      print 'Error(bin_to_dec): invalid input' and return empty string
    ---------------------------------------------------
    """
    valid = is_binary(b)
    if not valid:
        print("Error(bin_to_dec): invalid input")
        return ""
    
    decimal = 0
    power = len(b)-1
    for c in b:
        decimal+=int(c)*(2**power)
        power-=1
    
    return decimal


'______________________________________________________________________________'


def dec_to_bin(decimal, size=None):
    """
    ----------------------------------------------------
    Parameters:   decimal (int): input decimal number
                  size (int): number of bits in output binary number
                      default size = None
    Return:       binary (str): output binary number
    Description:  Converts any integer to binary
                  Result is to be represented in size bits
                  pre-pad with 0's to fit the output in the given size
                  If no size is given, no padding is done 
    Asserts:      decimal is an integer
    Errors:       if an invalid size:
                      print 'Error(dec_to_bin): invalid size' and return ''
                  if size is too small to fit output binary number:
                      print 'Error(dec_to_bin): integer overflow' and return ''
    ---------------------------------------------------
    """
    #use the divide by 2 method
    valid = isinstance(decimal, int)
    assert valid == True, "Error(dec_to_bin): invalid input"
    binary = ""
    remainder = 999
    dividend = 999
    while dividend >= 1:
        remainder = decimal%2
        dividend = decimal//2
        binary = str(remainder) + binary
        decimal = dividend
    
    if size is not None:
        if not isinstance(size, int) or size<=0:
            print("Error(dec_to_bin): invalid size")
            binary = ""
        elif size<len(binary):
            print("Error(dec_to_bin): integer overflow")
            binary = ""
        else:
            pad = '0' * (size-len(binary))
            binary = pad + binary
    
    return binary


'______________________________________________________________________________'


def xor(a, b):
    """
    ----------------------------------------------------
    Parameters:   a (str): binary number
                  b (str): binary number
    Return:       decimal (int)
    Description:  Apply xor operation on a and b
    Errors:       if a or b is not a valid binary number 
                      print 'Error(xor): invalid input' and return ''
                  if a and b have different lengths:
                       print 'Error(xor): size mismatch' and return ''
    ---------------------------------------------------
    """
    valid = is_binary(a) and is_binary(b)
    if not valid:
        print ('Error(xor): invalid input')
        return ""
    if len(a)!=len(b):
        print("Error(xor): size mismatch")
        return ""
    decimal = ""
    for i in range(len(a)):
        if a[i]==b[i]:
            decimal+='0'
        else:
            decimal+='1'
    decimal = int(decimal)
    
    return decimal


'______________________________________________________________________________'


def encode(c, code_type):
    """
    ----------------------------------------------------
    Parameters:   c (str): a character
                  code_type (str): ASCII or B6
    Return:       b (str): corresponding binary number
    Description:  Encodes a given character using the given encoding scheme
                  Current implementation supports only ASCII and B6 encoding
    Errors:       If c is not a single character:
                    print 'Error(encode): invalid input' and return ''
                  If unsupported encoding type:
                    print 'Error(encode): Unsupported Coding Type' and return ''
    ---------------------------------------------------
    """
    b = ""
    if not isinstance(c, str) or len(c)!=1 :
        print("Error(encode): invalid input")
    elif code_type!="ASCII" and code_type!="B6":
        print ('Error(encode): Unsupported coding type')
    elif code_type=="ASCII":
        s = ord(c)
        b = dec_to_bin(s,8)
    else:
        base = get_base(code_type)
        position = get_positions(base, c)
        b = dec_to_bin(position[0][1],6)
    
    return b


'______________________________________________________________________________'


def decode(b, code_type):
    """
    ----------------------------------------------------
    Parameters:   b (str): a binary number
                  code_type (str): ASCII or B6
    Return:       c (str): corresponding character
    Description:  Decodes a given character using the given encoding scheme
                  Current implementation supports only ASCII and B6 encoding
    Errors:       If b is not a binary number:
                    print 'Error(decode): invalid input' and return ''
                  If unsupported encoding type:
                    print 'Error(decode): unsupported Coding Type' and return ''
    ---------------------------------------------------
    """
    c = ""
    if not is_binary(b) or len(b)==0:
        print("Error(decode): invalid input")
    elif code_type!="ASCII" and code_type!="B6":
        print ('Error(decode): unsupported coding type')
    else:
        decimal = bin_to_dec(b)
        if code_type == 'ASCII':
            if len(b)>8:
                print("Error(decode): invalid input")
            else:
                c = chr(decimal)
        else:
            if len(b)>6:
                print("Error(decode): invalid input")
            else:
                base = get_base(code_type)
                c = base[decimal]
        
    return c
