"""
-----------------------------
CP460 (Fall 2021)
Name: Maxwell Dann
ID: 190274440
mod library
-----------------------------
"""

from copy import deepcopy
import utilities
import math
class MOD:
    """
    ----------------------------------------------------
    Description: Modular Arithmetic Library
    ----------------------------------------------------
    """
    DEFAULT_VALUE = 0
    DEFAULT_MOD = 2
    
    def __init__(self, value=DEFAULT_VALUE, mod=DEFAULT_MOD):
        """
        ----------------------------------------------------
        Parameters:   _value (int): default value = 0
                      _mod(int): default value = 2
        Description:  Creates a number in modular format
                      sets _value and _mod
        ---------------------------------------------------
        """
        self.value = value
        self.mod = mod
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      a MOD object
                      output format:
                      <_value>
        ---------------------------------------------------
        """
        output = str(self.get_value())
        return output
    
    def print(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       -
        Description:  prints string representation of 
                      a MOD object in the following format:
                      <_value> mod <_mod>
        ---------------------------------------------------
        """
        print("{} mod {}".format(self.get_value(), self.get_mod()))
        return 
    
    def set_value(self, value):
        """
        ----------------------------------------------------
        Parameters:   value (int): an arbitrary integer
        Return:       success: True/False
        Description:  Sets MOD object value to given value
                      if invalid value (i.e., not an integer) --> 
                          set to default value
        ---------------------------------------------------
        """ 
        valid = isinstance(value, int)
        if valid:
            self.value = value
        else:
            self.value = MOD.DEFAULT_VALUE
            
        return valid
    
    def set_mod(self, mod):
        """
        ----------------------------------------------------
        Parameters:   mod (int): an arbitrary integer
        Return:       success: True/False
        Description:  Sets MOD object mod to given value
                      if invalid mod (i.e., anything but integers >= 2) --> 
                          set to default mod
        ---------------------------------------------------
        """ 
        valid = isinstance(mod, int) and mod >= 2
        if valid:
            self.mod = mod
        else:
            self.mod = MOD.DEFAULT_MOD
        return valid
    
    def get_value(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       value (int)
        Description:  Returns a copy of the value
        ---------------------------------------------------
        """
        return deepcopy(self.value)
    
    def get_residue(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       residue (int)
        Description:  Returns the residue of the stored value
                        using the stored mod
                      A residue is the smallest positive integer
                      that is congruent to value mod m
                      Example:  residue 16 mod 5 --> 1
        ---------------------------------------------------
        """
        return self.get_value() % self.get_mod()
    
    def get_mod(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       mod (int)
        Description:  Returns a copy of the mod
        ---------------------------------------------------
        """
        return deepcopy(self.mod)

    def get_residue_list(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       residue_list (list)
        Description:  Constructs and returns a list that contains
                        All integers from 0 up to mod -1
                      Example: residue_list(5) --> [0,1,2,3,4]
        ---------------------------------------------------
        """
        residue_list = []
        for i in range(0, self.get_mod()):
            residue_list.append(i)
        return residue_list
    
    def is_congruent(self, num2):
        """
        ----------------------------------------------------
        Parameters:   num2 (MOD): an arbitrary MOD object
        Return:       True/False
        Description:  Checks if current number and given num2 
                        are congruent to each other
                      Both numbers should be of the same mod
        Errors:       if input is not a MOD object return:
                        'Error(MOD.is_congruent): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(num2, MOD):
            return 'Error(MOD.is_congruent): invalid input'
        
        congruent = self.get_mod() == num2.get_mod()
            
        return congruent

    @staticmethod
    def add(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (MOD): an arbitrary MOD object
                      b (MOD): an arbitrary MOD object
        Return:       result (MOD): a + b mod m
        Description:  Adds the values of <a> and <b> and 
                        returns a MOD object containing the residue
                      Example: MOD(11,5) + MOD(3,5) = MOD(4,5)
        Errors:       if one of the inputs is not a MOD object
                      or if <a> and <b> mods are not equal:
                        return 'Error(MOD.add): invalid input'
        ---------------------------------------------------
        """
        # test for valid input
        if not isinstance(a, MOD) or not isinstance(b, MOD) or a.get_mod() != b.get_mod():
            return 'Error(MOD.add): invalid input'
        
        result = MOD((a.get_value() + b.get_value()) % a.get_mod(), a.get_mod())
        return result

    @staticmethod
    def sub(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (MOD): an arbitrary MOD object
                      b (MOD): an arbitrary MOD object
        Return:       result (MOD): <a> - <b> mod m
        Description:  Subtracts the values of <b> from <a> and 
                        returns a MOD object containing the residue
                      Example: MOD(11,5) - MOD(3,5) = MOD(3,5)
        Errors:       if one of the inputs is not a MOD object
                      or if <a> and <b> mods are inequal:
                        return 'Error(MOD.sub): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(a, MOD) or not isinstance(b, MOD) or a.get_mod() != b.get_mod():
            return 'Error(MOD.sub): invalid input'
        
        result = MOD(a.get_value() - b.get_value(), a.get_mod())
        
        val = result.get_value() 
        if val > result.get_mod() or val < 0:
            result.set_value(result.get_residue())
        
        return result
    
    def get_add_inv(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       result (int): additive inverse of current object
        Description:  Computes and returns the additive inverse of the 
                        current object
                      Example: additive inverse of 3 mod 5 is 2
        ---------------------------------------------------
        """
        
        return abs(self.get_value() - self.get_mod())

    @staticmethod
    def get_add_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       add_table (2d list)
        Description:  Construct and return addition table mod m
                        element [r][c] represent r+c mod m
                      Example: MOD.get_add_table(2) --> [[0,1],[1,0]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_add_table): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(m, int) or not m >= 2:
            return 'Error(MOD.get_add_table): invalid input'
        
        add_table = utilities.new_matrix(m, m, 0)
        for i in range(m):
            # reset = 0
            for j in range(m):
                temp = (i + j) % m
                # if temp>m:
                #     temp = reset
                #     reset+=1
                add_table[i][j] = temp
        
        return add_table

    @staticmethod
    def get_sub_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       sub_table (2d list)
        Description:  Construct and return subtraction table mod m
                        element [r][c] represent r-c mod m
                      Example: MOD.get_sub_table(3) --> [[[0,2,1],[1,0,2],[2,1,0]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_sub_table): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(m, int) or not m >= 2:
            return 'Error(Mod.get_sub_table): invalid input'
        
        sub_table = utilities.new_matrix(m, m, 0)
        for i in range(m):
            for j in range(m):
                temp = (i - j) % m
                sub_table[i][j] = temp
        
        return sub_table

    @staticmethod
    def get_add_inv_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       add_inv_table (2d list)
        Description:  Construct and return additive inverse table mod m
                        Top row is num, bottom row is additive inverse
                      Example: MOD.get_add_inv_table(5) --> [[0,1,2,3,4],[0,4,3,2,1]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_add_inv_table): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(m, int) or not m >= 2:
            return 'Error(MOD.get_add_inv_table): invalid input'
        add_inv_table = utilities.new_matrix(2, m, 0)
        
        # first row is just numbers up to m
        for i in range(m):
            add_inv_table[0][i] = i
        # second row is additive inverse
        for i in range(m):
            if i == 0:
                add_inv_table[1][i] = 0
            else:
                add_inv_table[1][i] = abs(add_inv_table[0][i] - m)
        return add_inv_table
    
    @staticmethod
    def mul(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (MOD): an arbitrary MOD object
                      b (MOD): an arbitrary MOD object
        Return:       result (MOD): <a> * <b> mod m
        Description:  Multiplies the values of <a> by <b> and 
                        returns a Mod object containing the residue
                      Example: MOD(11,5) - MOD(2,5) = MOD(2,5)
        Errors:       if one of the inputs is not a MOD object
                      or if <a> and <b> mods are inequal:
                        return 'Error(MOD.mul): invalid input'
        ---------------------------------------------------
        """        
        if not isinstance(a, MOD) or not isinstance(b, MOD) or a.get_mod() != b.get_mod():
            return 'Error(MOD.mul): invalid input'
        
        temp = a.get_value() * b.get_value()
        result = MOD(temp % a.get_mod(), a.get_mod())
        
        return result
    
    @staticmethod
    def get_mul_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       mul_table (2d list)
        Description:  Construct and return multiplication table mod m
                        element [r][c] represent r*c mod m
                      Example: Mod.get_mul_table(4) --> 
                       [[0, 0, 0, 0], [0, 1, 2, 3], [0, 2, 0, 2], [0, 3, 2, 1]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_mul_table): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(m, int) or not m >= 2:
            return 'Error(MOD.get_mul_table): invalid input'
        mul_table = utilities.new_matrix(m, m, 0)
        for i in range(m):
            for j in range(m):
                mul_table[i][j] = (i * j) % m 
        return mul_table

    @staticmethod
    def is_prime(n):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   n (int): an arbitrary integer
        Return:       True/False
        Description:  Check if the given input is a prime number
                      Search Online for an efficient implementation
        ---------------------------------------------------
        """
        if n <= 3:
            return n > 1
        if n % 2 == 0 or n % 3 == 0:
            return False
        i = 5
        while i ** 2 <= n:
            if n % i == 0 or n % (i + 2) == 0:
                return False
            i += 6
        return True

    @staticmethod
    def gcd(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       result (int): the GCD of a and b
        Description:  Computes and returns the greatest common diviser using
                      the standard Eculidean Algorithm.
                      The implementation can be iterative or recursive
        Errors:       if a or b are non positive integers, return:
                        'Error(MOD.gcd): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(a, int) or not isinstance(b, int) or a == 0 or b == 0:
            return 'Error(MOD.gcd): invalid input'
        
        a = abs(a)
        b = abs(b)
        
        while b != 0:
            q = a // b
            r = a - (q * b)
            a = b
            b = r
            
        return a

    @staticmethod
    def is_relatively_prime(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       True/False
        Description:  Check if <a> and <b> are relatively prime
                          i.e., gcd(a,b) equals 1
        Errors:       if a or b are non positive integers, return:
                        'Error(Mod.is_relatively_prime): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(a, int) or not isinstance(b, int) or a < 0 or b < 0:
            return 'Error(MOD.is_relatively_prime): invalid input'
        relatively_prime = MOD.gcd(a, b) == 1
        return relatively_prime

    def has_mul_inv(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       True/False
        Description:  Check if current value has a multiplicative inverse mod m
        ---------------------------------------------------
        """
        
        return MOD.EEA(self.get_value(), self.get_mod())[0] == 1

    @staticmethod
    def EEA(a, b):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   a (int): an arbitrary integer
                      b (int): an arbitrary integer
        Return:       result (list): [gcd(a,b), s, t]
        Description:  Uses Extended Euclidean Algorithm to find:
                        gcd(a,b) and <s> and <t> such that:
                        as + bt = gcd(a,b), i.e., Bezout's identity
        Errors:       if a or b are 0 or non-integers
                        'Error(MOD.EEA): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(a, int) or not isinstance(b, int) or a == 0 or b == 0:
            return 'Error(MOD.EEA): invalid input'
        
        u = [abs(a), 1, 0]
        v = [abs(b), 0, 1]
        while v[0] != 0:
            q = math.floor(u[0] / v[0])
            r = [u[0] - q * v[0], u[1] - q * v[1], u[2] - q * v[2]]
            u = v
            v = r
        return u

    def get_mul_inv(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       mul_inv (int or 'NA')
        Description:  Computes and returns the multiplicative inverse of 
                        current value mod m
                      if it does not exist returns 'NA'
        ---------------------------------------------------
        """
        val = self.get_value()
        m = self.get_mod()
        
        u = self.EEA(val, m)
        # check if val and m are relatively prime
        valid = u[0] == 1
        
        mul_inv = 'NA'
        if valid:
            mul_inv = u[1] % m
        return mul_inv

    @staticmethod
    def get_mul_inv_table(m):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   m (int): an arbitrary mod
        Return:       mul_inv_table (2d list)
        Description:  Construct and return multiplicative inverse table mod m
                        Top row are numbers 0 --> mod - 1
                        Bottom row is multplicative inverses
                      Example: Mod.get_mul_inv_table(5) --> 
                          [[0,1,2,3,4],['NA',1,3,2,4]]
        Errors:       if m is not an integer >= 2:
                        return 'Error(MOD.get_mul_inv_table): invalid input'
        ---------------------------------------------------
        """
        if not isinstance(m, int) or not m >= 2:
            return 'Error(MOD.get_mul_inv_table): invalid input'
        mul_inv_table = utilities.new_matrix(2, m, 0)
        for i in range(m):
            mul_inv_table[0][i] = i
        mod = MOD(0, m)
        for i in range(m):
            mod.set_value(i)
            mul_inv_table[1][i] = mod.get_mul_inv() 
        return mul_inv_table

    