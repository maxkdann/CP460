import utilities
from mod import MOD
from copy import deepcopy

NAME = 'Maxwell_Dann'  # <------- edit this to be your name, should match your file name


class final_info:
    
    def get_first_name(self):
        return 'Maxwell'  # <------------- edit this with your first name as in myls
    
    def get_last_name(self):
        return 'Dann'  # <------------- edit this with your last name as in myls
        
    def get_ID(self):
        return '190274440'  # <------- edit this with your student ID
    
    def get_certification(self):
        return 'I certify that I completed this final exam according to academic honesty gudelines. I attest that I did not use any external help, neither in person nor virtually. I understand that failing to abide by the academic integrity guidelines may lead to my failure in the course, in addition to other penalties according to the University policies.'  # <------- edit this string with your honor pledge

    def get_comments(self):
        output = 'get_task3_solution has two returns, the first is blank. I have left it this way to make it similar to all other methods.\n'
        output += 'The math cipher cryptanalysis on sample data gives a different key than expected output, this key correctly decrypts '
        output += "the ciphertext and occurs first in brute force, thus it should be considered a better, or at least equal key (since it is found earlier).\n"
        output += "This has been my favourite class I have taken at Laurier, thanks so much for an amazing semester."
        return output
    
    def get_task1_solution(self):
        key = (23, 65, 67, 0, 68)  # <---------- hard-code your Task 1 key here
        plaintext = '''it very slow, but
I shall only be away a couple of hours."

I walked down to the station with them, and then wandered through the
streets of the little town, finally returning to the hotel, where I lay
upon the sofa and tried to interest myself in a yellow-backed novel.
The puny plot of the story was so thin, however, when compared to the
deep mystery through which we were groping, and I found my attention
wander so continually from the action to the fact, that I at last flung
it across the room and gave myself up entirely to a consideration of
the events of the day. Supposing that this unhappy young man's story
were absolutely true, then what hellish thing, what absolutely
unforeseen and extraordinary calamity could have occurred between the
time when he parted from his father, and the moment when, drawn back by
his screams, he rushed into the glade? It was something terrible and
deadly. What could it be? Might not the nature of the injuries reveal
something to my medical instincts? I rang the bell and called for the
weekly county paper, which contained a verbatim account of the inquest.
In the surgeon's deposition it was stated that the posterior third of
the left parietal bone and the left half of the occipital bone had been
shattered by a heavy blow from a blunt weapon. I marked the spot upon
my own head. Clearly such a blow must have been struck from behind.
That was to some extent in favour of the accused, as when seen
quarrelling he was face to face with his father. Still, it did not go
for very much, for the older man might have turned his back before the
blow fell. Still, it might be worth while to call Holmes' attention to
it. Then there was the peculiar dying reference to a rat. What could
that mean? It could not be delirium. A man dying from a sudden blow
does not commonly become delirious. No, it was more likely to be an
attempt to explain how he met his fate. But what could it indicate? I
cudgelled my brains to find some possible explanation. And then the
incident of the grey cloth seen by young McCarthy. If that were true
the murderer must have dropped some part of his dress, presumably his
overcoat, in his flight, and must have had the hardihood to return and
to carry it away at the instant when the son was kneeling with his back
turned not a dozen paces off. What a tissue of mysteries and
improbabilities the whole thing was! I did not wonder at Lestrade's
opinion, and yet I had so much faith in Sherlock Holmes' insight that I
could not lose hope as long as every fresh fact seemed to strengthen
his conviction of young McCarthy's innocence.

It was late before Sherlock Holmes returned. He came back alone, for
Lestrade was staying in lodgings in the town.

"The glass still keeps very high," he remarked as he sat down. "It is
of importance that it should not rain before we are able to go over the
ground. On the other hand, a man should be at his very best and keenest
for such nice work as that, and I did not wish to do it when fagged by
a long journey. I have seen young McCarthy."

"And what did you learn from him?"

"Nothing."

"Could he throw no light?"

"None at all. I was inclined to think at one time that he knew who'''  # <---------- load your task1 decrypted text here
        return key, plaintext
    
    def get_task2_solution(self):
        key = '101101001'  # <---------- hard-code your Task 2 key here
        plaintext = '''I toiled hard, and
my success was proportionate to my efforts; my memory, not naturally
tenacious, improved with practice; exercise sharpened my wits; in a few
weeks I was promoted to a higher class; in less than two months I was
allowed to commence French and drawing.  I learned the first two tenses
of the verb _Etre_, and sketched my first cottage (whose walls, by-the-
bye, outrivalled in slope those of the leaning tower of Pisa), on the
same day.  That night, on going to bed, I forgot to prepare in
imagination the Barmecide supper of hot roast potatoes, or white bread
and new milk, with which I was wont to amuse my inward cravings: I
feasted instead on the spectacle of ideal drawings, which I saw in the
dark; all the work of my own hands: freely pencilled houses and trees,
picturesque rocks and ruins, Cuyp-like groups of cattle, sweet paintings
of butterflies hovering over unblown roses, of birds picking at ripe
cherries, of wren's nests enclosing pearl-like eggs, wreathed about with
young ivy sprays.  I examined, too, in thought, the possibility of my
ever being able to translate currently a certain little French story
which Madame Pierrot had that day shown me; nor was that problem solved
to my satisfaction ere I fell sweetly asleep.

Well has Solomon said--"Better is a dinner of herbs where love is, than a
stalled ox and hatred therewith."

I would not now have exchanged Lowood with all its privations for
Gateshead and its daily luxuries.




CHAPTER IX


But the privations, or rather the hardships, of Lowood lessened.  Spring
drew on: she was indeed already come; the frosts of winter had ceased;
its snows were melted, its cutting winds ameliorated.  My wretched feet,
flayed and swollen to lameness by the sharp air of January, began to heal
and subside under the gentler breathings of April; the nights and
mornings no longer by their Canadian temperature froze the very blood in
our veins; we could now endure the play-hour passed in the garden:
sometimes on a sunny day it began even to be pleasant and genial, and a
greenness grew over those brown beds, which, freshening daily, suggested
the thought that Hope traversed them at night, and left each morning
brighter traces of her steps.  Flowers peeped out amongst the leaves;
snow-drops, crocuses, purple auriculas, and golden-eyed pansies.  On
Thursday afternoons (half-holidays) we now took walks, and found still
sweeter flowers opening by the wayside, under the hedges.

I discovered, too, that a great pleasure, an enjoyment which the horizon
only bounded, lay all outside the high and spike-guarded walls of our
garden: this pleasure consisted in prospect of noble summits girdling a
great hill-hollow, rich in verdure and shadow; in a bright beck, full of
dark stones and sparkling eddies.  How different had this scene looked
when I viewed it laid out beneath the iron sky of winter, stiffened in
frost, shrouded with snow!--when mists as chill as death wandered to the
impulse of east winds along those purple peaks, and rolled down "ing" and
holm till they blended with the frozen fog of the beck!  That beck itself
was then a torrent, turbid and curbless: it tore asunder the wood,'''  # <---------- load your task2 decrypted text here
        return key, plaintext
    
    def get_task3_solution(self):
        plaintext = "What time is it now in London, UK?"  # <---------- load your task3 decrypted text here
        return '', plaintext
    
    def get_task4_solution(self):
        key = 657  # <---------- hard-code your Task 4 key here
        plaintext = '''not doing what he would give his very eyes to do,
but what he knows to be absolutely impossible. It was sheer frenzy of
this sort which made him throw his hands up into the air when his
father, at their last interview, was goading him on to propose to Miss
Turner. On the other hand, he had no means of supporting himself, and
his father, who was by all accounts a very hard man, would have thrown
him over utterly had he known the truth. It was with his barmaid wife
that he had spent the last three days in Bristol, and his father did
not know where he was. Mark that point. It is of importance. Good has
come out of evil, however, for the barmaid, finding from the papers
that he is in serious trouble and likely to be hanged, has thrown him
over utterly and has written to him to say that she has a husband
already in the Bermuda Dockyard, so that there is really no tie between
them. I think that that bit of news has consoled young McCarthy for all
that he has suffered."

"But if he is innocent, who has done it?"

"Ah! who? I would call your attention very particularly to two points.
One is that the murdered man had an appointment with someone at the
pool, and that the someone could not have been his son, for his son was
away, and he did not know when he would return. The second is that the
murdered man was heard to cry 'Cooee!' before he knew that his son had
returned. Those are the crucial points upon which the case depends. And
now let us talk about George Meredith, if you please, and we shall
leave all minor matters until to-morrow."

There was no rain, as Holmes had foretold, and the morning broke bright
and cloudless. At nine o'clock Lestrade called for us with the
carriage, and we set off for Hatherley Farm and the Boscombe Pool.

"There is serious news this morning," Lestrade observed. "It is said
that Mr. Turner, of the Hall, is so ill that his life is despaired of."

"An elderly man, I presume?" said Holmes.

"About sixty; but his constitution has been shattered by his life
abroad, and he has been in failing health for some time. This business
has had a very bad effect upon him. He was an old friend of McCarthy's,
and, I may add, a great benefactor to him, for I have learned that he
gave him Hatherley Farm rent free."

"Indeed! That is interesting," said Holmes.

"Oh, yes! In a hundred other ways he has helped him. Everybody about
here speaks of his kindness to him."

"Really! Does it not strike you as a little singular that this
McCarthy, who appears to have had little of his own, and to have been
under such obligations to Turner, should still talk of marrying his son
to Turner's daughter, who is, presumably, heiress to the estate, and
that in such a very cocksure manner, as if it were merely a case of a
proposal and all else would follow? It is the more strange, since we
know that Turner himself was averse to the idea. The daughter told us
as much. Do you not deduce something from that?"

"We have got to the deductions and the inferences," said Lestrade,
winking at me. "I find it hard enough to tackle facts, Holmes, without
flying away after theories and fancies."

"You are right," said Holmes demurely; "you do find it very hard'''  # <---------- load your task4 decrypted text here
        return key, plaintext


#-------------------- Task 1: Math Cipher ----------------------
class Math_Cipher:
    BASE = utilities.get_base('lower') + ' ' + utilities.get_base('nonalpha') + utilities.get_base('upper')
    DEFAULT_KEY = (11, 7, 13, 0, 26)

    def __init__(self, key=DEFAULT_KEY):
        self.key = key
        return
    
    def get_key(self):
        return deepcopy(self.key)

    def get_base(self):
        key = self.get_key()
        start = key[3]
        end = key[4]
        return deepcopy(Math_Cipher.BASE[start:end])
        
    def set_key(self, key):
        valid = Math_Cipher.valid_key(key)
        if valid:
            a = key[0]
            b = key[1]
            mod = MOD(a, key[4] - key[3])
            if a > key[4] - key[3] or a < 0:
                a = mod.get_residue()
            if b > key[4] - key[3] or b < 0:
                mod.set_value(b)
                b = mod.get_residue()
            self.key = (a, b, key[2], key[3], key[4])
        else:
            self.key = Math_Cipher.DEFAULT_KEY
        return valid
    
    def __str__(self):
        key = self.get_key()
        a = key[0]
        b = key[1]
        c = key[2]
        m = key[4] - key[3]
        output = "Math_Cipher:\ny = {}*{}x + {}^2 - {} mod {}".format(a, b, b, c, m)
        return output
    
    @staticmethod
    def valid_key(key):
        """
        (a,b,c,start,end)
        """
        valid = True
        if not isinstance(key, tuple):
            valid = False
        elif len(key) != 5:
            valid = False
        elif not (isinstance(key[0], int) and isinstance(key[1], int) and isinstance(key[2], int) and isinstance(key[3], int)and isinstance(key[4], int)):
            valid = False
        elif key[3] > key[4]:
            valid = False
        elif MOD.gcd(key[0], key[4] - key[3]) != 1 or MOD.gcd(key[1], key[4] - key[3]) != 1:
            valid = False
        elif key[4] - key[3] < 2:
            valid = False
        return valid
    
    def find_index(self, char, base):
        '''
        finds the index of char in base
        '''
        index = -1
        i = 0
        found = False
        while i < len(base) and not found:
            if base[i] == char:
                index = i
                found = True
            else:
                i += 1
        return index
    
    def encrypt(self, plaintext):
        key = self.get_key()
        base = self.get_base()
        a = key[0]
        b = key[1]
        c = key[2]
        start = key[3]
        end = key[4]
        m = end - start
        
        ciphertext = ""
        
        for p in plaintext:
            index = self.find_index(p, base)
            if index == -1:
                ciphertext += p
            else:
                y = (a * b * index + b ** 2 - c) % m
                ciphertext += base[y]
        
        return ciphertext
    
    def decrypt(self, ciphertext):
        key = self.get_key()
        base = self.get_base()
        a = key[0]
        b = key[1]
        c = key[2]
        start = key[3]
        end = key[4]
        m = end - start
        
        mod = MOD(a * b, m)
        mul_inv = mod.get_mul_inv()
        plaintext = ""
        for i in ciphertext:
            index = self.find_index(i, base)
            if index == -1:
                plaintext += i
            else:
                x = (mul_inv * (index - b ** 2 + c)) % m
                plaintext += base[x]
                
        return plaintext
    
    @staticmethod
    def analyze_keys(start, end):
        m = end - start
        total = m ** 3
        illegal = 0
        no_encipherment = 0
        decimation = 0
        valid = 0
        mod = MOD(0, m)
        for a in range(start, end):
            for b in range(start, end):
                for c in range(start, end):
                    val = a * b
                    mod.set_value(val)
                    # illegal keys have no modular multiplicative inverse
                    if not mod.has_mul_inv():
                        illegal += 1
                    # decimation cipher is kx mod m, think of ab as k
                    # math cipher would be the exact same if b^2-c = 0
                    elif b == c:
                        if (b ** 2 - c) % m == 0:
                            no_encipherment += 1
                        else:
                            decimation += 1
                    else:
                        valid += 1
        
        return [total, illegal, no_encipherment, decimation, valid]
    
    @staticmethod
    def cryptanalyze(ciphertext):
        # start always equals 0
        # end is somewhere between 60 and 95
        key = ""
        plaintext = ""
        dict_list = utilities.load_dictionary("engmix.txt")
        math = Math_Cipher()
        
        for end in range(61, 95):
            mod = MOD(0, end)
            for a in range(end):
                if plaintext != "":
                    break
                for b in range(end):
                    for c in range(end):
                        val = a * b
                        mod.set_value(val)
                        if mod.has_mul_inv() and b != c:
                            # key is valid
                            math.set_key((a, b, c, 0, end))
                            text = math.decrypt(ciphertext)
                            if utilities.is_plaintext(text, dict_list, 0.9):
                                key = (a, b, c, 0, end)
                                plaintext = text
                                break
        
        return key, plaintext
    

#-------------------- Task 2: SDES CTR Mode ----------------------
class SBOX:

    def __init__(self, filename=''):
        self._box = [[], []]
        self._size = 0
        if filename != '':
            self.set_box(filename)
    
    def is_empty(self):
        return self._size == 0
    
    def get_box(self):
        return deepcopy(self._box)
    
    def get_size(self):
        return self._size
    
    @staticmethod
    def valid_box(box): 
        if type(box) != list or len(box) != 2:
            return False
        if box == [[], []]:
            return True
        if len(box[0]) != len(box[1]):
            return False
        for i in range(2):
            for j in range(len(box[0])):
                if not utilities.is_binary(box[i][j]) or len(box[i][j]) != len(box[0][0]):
                    return False
        return True
    
    def set_box(self, filename):
        temp = [[], []]
        in_file = open(filename, 'r')
        line1 = in_file.readline().strip()
        line2 = in_file.readline().strip()
        in_file.close()
        temp[0] = line1.split('-')
        temp[1] = line2.split('-')
        if not SBOX.valid_box(temp):
            return False
        self._box = deepcopy(temp)
        self._size = len(temp[0][0]) + 1
        return True
    
    def substitute(self, value):
        if not utilities.is_binary(value) or len(value) != self._size:
            return ''
        row = int(value[0])
        col = utilities.bin_to_dec(value[1:])
        return self._box[row][col]
    
    def __str__(self):
        output = 'SBOX({}):\n'.format(self._size)
        output += str(self._box[0]) + '\n'
        output += str(self._box[1])
        return output

    
class SDES_CTR:
    DEFAULT_ENCODING = 'B6'
    DEFAULT_BLOCK_SIZE = 12
    DEFAULT_KEY_LENGTH = 9
    DEFAULT_ROUNDS = 2
    DEFAULT_SBOX1 = SBOX('sbox1.txt')
    DEFAULT_SBOX2 = SBOX('sbox2.txt')
    DEFAULT_KEY = '111011011'

    def __init__(self, key=DEFAULT_KEY):
        self._rounds = self.DEFAULT_ROUNDS
        self._key_length = self.DEFAULT_KEY_LENGTH
        self._block_size = self.DEFAULT_BLOCK_SIZE
        self._encoding = self.DEFAULT_ENCODING
        self._sbox1 = self.DEFAULT_SBOX1
        self._sbox2 = self.DEFAULT_SBOX2
        self._key = key
        
    def get_value(self, parameter):
        result = ""
        if parameter == "rounds":
            result = deepcopy(self._rounds)
        elif parameter == "key_length":
            result = deepcopy(self._key_length)
        elif parameter == "block_size":
            result = deepcopy(self._block_size)
        elif parameter == "encoding":
            result = deepcopy(self._encoding)
        elif parameter == "sbox1":
            result = deepcopy(self._sbox1)
        elif parameter == "sbox2":
            result = deepcopy(self._sbox2)
        return result
    
    def set_key(self, key):
        self._key = key
        return True
    
    def set_parameter(self, parameter, value):
        valid = True
        if parameter == "rounds":
            if not isinstance(value, int) or value < 1:
                valid = False
                print("Error (set_parameter_: Invalid input")
            else:
                self._rounds = value
        elif parameter == "block_size":
            if not isinstance(value, int) or value % 2 != 0 or value < 4:
                valid = False
                print("Error (set_parameter_: Invalid input")
            else:
                self._key_length = value // 2 + 3
        elif parameter == "sbox1":
            if not isinstance(value, SBOX) or value.is_empty():
                valid = False
                print("Error (set_parameter_: Invalid input")
            else:
                self._sbox1 = value
        elif parameter == "sbox2":
            if not isinstance(value, SBOX) or value.is_empty():
                valid = False
                print("Error (set_parameter_: Invalid input")
            else:
                self._sbox2 = value
        return valid

    def get_key(self):
        return deepcopy(self._key)
    
    def get_subkey(self, i):
        # generate the key starting at the ith index and wrapping if necessary
        subkey = ""
        key = self.get_key()
        counter = 0
        while counter < 8:
            if i == len(key):
                i = 0
            subkey += key[i]
            i += 1
            counter += 1
        
        return subkey
        
    def expand(self, R):
        result = ""
        if utilities.is_binary(R):
            middle = len(R) // 2 - 1
            if middle > 0:
                result = R[:middle] + R[middle + 1] + R[middle] + R[middle + 1] + R[middle] + R[middle + 2:]
        return result
    
    def F(self, Ri, ki):
        result = ""
        if isinstance(Ri, str) and isinstance(ki, str) and utilities.is_binary(Ri) and utilities.is_binary(ki):
            sbox1 = self.get_value("sbox1")
            sbox2 = self.get_value("sbox2")
            
            step1 = self.expand(Ri)
            if len(step1) == len(ki):
                step2 = str(self.xor(step1, ki))
                step3_first = step2[:len(step2) // 2]
                step3_second = step2[len(step2) // 2:]
                
                step4_first = sbox1.substitute(step3_first)
                step4_second = sbox2.substitute(step3_second)
                
                result = step4_first + step4_second
        return result
    
    def xor(self, a, b):
        decimal = ""
        for i in range(len(a)):
            if a[i] == b[i]:
                decimal += '0'
            else:
                decimal += '1'
        return decimal

    def feistel(self, bi, ki):
        bi2 = ""
        if isinstance(bi, str) and isinstance(ki, str) and utilities.is_binary(bi) and utilities.is_binary(ki):
            
            mid = len(bi) // 2
            l2 = bi[mid:]
            l1 = bi[:mid]
            f = self.F(l2, ki)
            if len(f) == len(l1):
                r2 = self.xor(l1, f)
                bi2 = l2 + r2
        return bi2
    
    def get_counter_value(self):
        key = self.get_key()
        counter = 0
        for k in key:
            if k == "1":
                counter += 1
        return counter
        
    def encrypt(self, plaintext): 
        # remove unwanted base chars
        base = utilities.get_base("B6")
        all = utilities.get_base("all")
        base_to_remove = ""
        for a in all:
            if a not in base:
                base_to_remove += a
                
        positions = utilities.get_positions(plaintext, base_to_remove)
        plaintext = utilities.clean_text(plaintext, base_to_remove)
        ciphertext = ""
        
        # each character corresponds to 6 binary numbers, add them to blocks
        blocks = []
        # get the nonce (counter)
        nonce = self.get_counter_value()
        bits = self.get_value("block_size")
        # convert it to binary
        nonce_binary = utilities.dec_to_bin(nonce, bits)
        nonces = []
        nonces.append(nonce_binary)
        curr_block = ""
        block_size = self.get_value("block_size")
        
        for i in range (len(plaintext)):
            curr_block += utilities.encode(plaintext[i], "B6")
            if len(curr_block) == block_size:
                blocks.append(curr_block)
                curr_block = ""
            # add the last block regardless of whether it is the correct length
            elif i == len(plaintext) - 1:
                blocks.append(curr_block)
            
        rounds = self.get_value("rounds")
        j = 0
        
        # encrypt nonce and key, xor this with plainblock to get cipherblock
        for i in range(len(blocks)):
            prev = nonces[i]
            curr = ""
            j = 0
            while j < rounds:
                key = self.get_subkey(j)
                curr = self.feistel(prev, key)
                prev = curr
                j += 1
            # swap on last round
            mid = len(curr) // 2
            curr = curr[mid:] + curr[:mid]
            # increment the counter and add it to nonces
            nonce += 1
            nonce_binary = utilities.dec_to_bin(nonce, bits)
            nonces.append(nonce_binary)
            # xor with plainblock
            if len(blocks[i]) != len(curr):
                # last char, pad front with 0s
                curr = self.xor(curr[:len(curr) // 2], blocks[i])
                curr = utilities.decode(curr, "B6")
            else:
                curr = self.xor(curr, blocks[i])
                second = utilities.decode(curr[mid:], "B6")
                first = utilities.decode(curr[:mid], "B6")
                curr = first + second
            ciphertext += curr
        
        ciphertext = utilities.insert_positions(ciphertext, positions)
        return ciphertext

    def decrypt(self, ciphertext):
        plaintext = self.encrypt(ciphertext)
        return plaintext
    
    @staticmethod
    def cryptanalyze(ciphertext):
        # you know that the key has 5 1s and 9 digits
        # generate every possible binary number of length 9, make sure
        # it has 5 1s and then test it
        # the smallest the number can be in 000011111 - 31
        # the biggest is 111110000 - 496
        dict_list = utilities.load_dictionary("engmix.txt")
        ctr = SDES_CTR()
        key = ""
        plaintext = ""
        for k in range(31, 496):
            one_count = 0
            k_binary = utilities.dec_to_bin(k, 9)
            # make sure it has 5 1s
            for b in k_binary:
                if b == '1':
                    one_count += 1
            # if it does then continue
            if one_count == 5:
                ctr.set_key(k_binary)
                text = ctr.decrypt(ciphertext)
                if utilities.is_plaintext(text, dict_list, 0.9):
                    key = k_binary
                    plaintext = text
                    break
        
        return key, plaintext

    
#-------------------- Task 3: RSA ----------------------
class RSA:
    BLOCK_SIZE = 6
    PAD = 'Q'
    THRESHOLD = 0.7
    DICT_FILE = 'engmix.txt'
    P = 27419851  # <---------- hardcode your p value here
    Q = 16944089  # <---------- hardcode your q value here
    E = 32452999  # <---------- hardcode your e value here
    
    @staticmethod
    def compute_m(p, q):
        return p * q
    
    @staticmethod
    def compute_n(p, q):
        return (p - 1) * (q - 1)
    
    @staticmethod
    def compute_d(p, q, e):
        # d = e^-1 mod n
        n = RSA.compute_n(RSA.P, RSA.Q)
        mod = MOD(e, n)
        d = mod.get_mul_inv()
        return d
    
    @staticmethod
    def get_public_key(p, q, e):
        return (RSA.E, RSA.compute_m(p, q))
    
    @staticmethod
    def get_private_key(p, q, e):
        return (RSA.compute_d(p, q, e), RSA.compute_m(p, q))
    
    @staticmethod
    def LRM(b, e, m):
        # convert exponent to binary
        e_binary = utilities.dec_to_bin(e)
        # make tuple
        nums = []
        mod = MOD(b, m)
        for i in range(len(e_binary)):
            # MSB is always 1
            if i == 0:
                curr = mod.get_residue()
            # if 0 take the square of the previous value, then mod m and add it
            elif e_binary[i] == '0':
                mod.set_value(nums[-1] ** 2)
                curr = mod.get_residue()
            # if 1 then take the square of the previous value and mod it
            # then take that modded value and multiply it by the original value
            else:
                mod.set_value(nums[-1] ** 2)
                x2 = mod.get_residue()
                x3 = nums[0] * x2
                mod.set_value(x3)
                curr = mod.get_residue()
            nums.append(curr)
                
        return nums[-1]

    @staticmethod
    def encode(text):
        base = utilities.get_base("BA")
        # find the index in base then multiply that index by a power of 96
        counter = len(text) - 1
        result = 0
        index = 0
        for t in text:
            # find t in base
            index = 0
            while base[index] != t:
                index += 1
            # now index stores the index of t in base
            result += (index * (96 ** counter))
            counter -= 1
        return result
    
    @staticmethod
    def decode(num, block_size):
        # first check to make sure that 96^block size < num
        if 96 ** block_size < num:
            return ""
        base = utilities.get_base("BA")
        # were given a number and we have to convert it to characters
        # if the number of characters we get != block_size then prepad with As
        result = ""
        while num > 96:
            mod = num % 96
            num //= 96
            result += base[mod]
        if num == 96:
            result += "AB"
        else:
            result += base[num]
            
        result = result[::-1]
        # pad with As if need be
        while len(result) < block_size:
            result = "A" + result
        return result

    @staticmethod
    def encrypt(plaintext, key):
        e = key[0]
        m = key[1]
        ciphertext = ""
        # divide plaintext into blocks of BLOCK_SIZE
        blocks = utilities.text_to_blocks(plaintext, RSA.BLOCK_SIZE, True, RSA.PAD)
        
        # convert each block to a number
        blocks_as_numbers = []
        for b in blocks:
            blocks_as_numbers.append(RSA.encode(b))
        
        # for each block, compute the corresponding cipher block
        # using the formula y = x^e mod m by invoking the LRM function
        cipher_blocks = []
        for b in blocks_as_numbers:
            cipher_blocks.append(RSA.LRM(b, e, m))
            
        # convert each block back into character stream using decode
        # each cipher block should be 8 characters (BLOCK_SIZE + 2)
        for c in cipher_blocks:
            ciphertext += RSA.decode(c, RSA.BLOCK_SIZE + 2)
        
        return ciphertext
 
    @staticmethod
    def decrypt(ciphertext, key):
        d = int(key[0])
        m = int(key[1])
        plaintext = ""
        
        # break the ciphertext into blocks of BLOCK_SIZE+2
        # shouldn't need to have any padding
        blocks = utilities.text_to_blocks(ciphertext, RSA.BLOCK_SIZE + 2)
        
        # each block holds a character stream, we need to convent it to a 
        # number using encode
        blocks_as_numbers = []
        for b in blocks:
            blocks_as_numbers.append(RSA.encode(b))
        
        # now we need to compute the correct number using the formula
        # x = y^d mod m
        correct_numbers = []
        for b in blocks_as_numbers:
            correct_numbers.append(RSA.LRM(b, d, m))
        
        # now we need to change those numbers back to character streams
        for c in correct_numbers:
            plaintext += RSA.decode(c, RSA.BLOCK_SIZE + 2)[2:]
            
        # strip padding at the end
        while plaintext[-1] == RSA.PAD:
            plaintext = plaintext[:-1]
        return plaintext

    @staticmethod
    def verify(message, public_key_file):
        name = "Unknown"
        plaintext = ""
        # someone has encrypted a message using their private key
        # you can use their public key to decrypt the message
        # loop through all public keys, whichever one decodes the 
        # message is your sender
        file_contents = utilities.file_to_text(public_key_file)
        senders = file_contents.split("\n")
        dict_list = utilities.load_dictionary("engmix.txt")
        for s in senders:
            if s == "":
                break
            line = s.split()
            temp_name = line[0]
            d = int(line[1])
            m = int(line[2])
            text = RSA.decrypt(message, (d, m))
            if utilities.is_plaintext(text, dict_list, 0.7):
                name = temp_name
                plaintext = text

        return name, plaintext

#-------------------- Task 4: Flip Cipher ----------------------


class Flip_Cipher:
    DEFAULT_KEY = 2
    
    def __init__(self, key=DEFAULT_KEY):
        self.key = key
        return
    
    def get_key(self):
        return deepcopy(self.key)
    
    def set_key(self, key):
        valid = Flip_Cipher.valid_key(key)
        if valid:
            self.key = key
        else:
            self.key = Flip_Cipher.DEFAULT_KEY
        return valid
    
    def __str__(self):
        return "Flip Cipher, key = {}".format(self.get_key())
    
    @staticmethod
    def valid_key(key):
        return isinstance(key, int) and key > 0
    
    @staticmethod
    def flip_block(text, block_size):
        result = ""
        # the fliping takes place either on 2 tokens or on 3 tokens
        # if the block_size is even the token size will be even
        # if the block size is odd, the pivot token will be 1 and 
        # the other two will each be (block_size-1)/2
        # create blocks of block_size
        blocks = utilities.text_to_blocks(text, block_size)
        flip = Flip_Cipher()
        if block_size % 2 == 0:
            for b in range(len(blocks)):
                # do nothing if last block doesn't have the right size
                if not (b == len(blocks) - 1 and len(blocks[b]) != block_size):
                    mid = int(len(blocks[b]) / 2)
                    one, two = flip.swap(blocks[b][:mid], blocks[b][mid:])
                    blocks[b] = one + two
            
        else:
            for b in range(len(blocks)):
                if not(b == len(blocks) - 1 and len(blocks[b]) != block_size):
                    mid = len(blocks[b]) // 2
                    one, two = flip.swap(blocks[b][:mid], blocks[b][mid + 1:])
                    blocks[b] = one + blocks[b][mid] + two
                    
        for b in blocks:
            result += b
                
        return result
    
    def swap(self, a, b):
        temp = a
        a = b
        b = temp
        return a, b   
    
    def encrypt(self, plaintext):
        key = self.get_key()
        curr = ""
        prev = plaintext
        for i in range(2, key + 1):
            curr = Flip_Cipher.flip_block(prev, i)
            prev = curr
            
        return curr
    
    def decrypt(self, ciphertext):
        key = self.get_key()
        curr = ""
        prev = ciphertext
        for i in range(key, 1, -1):
            curr = Flip_Cipher.flip_block(prev, i)
            prev = curr
        return curr
    
    @staticmethod
    def cryptanalyze(ciphertext):
        # brute force keys
        i = 2
        found = False
        dict_list = utilities.load_dictionary("engmix.txt")
        flip = Flip_Cipher()
        key = ""
        plaintext = ""
        while i < 1000 and not found:
            flip.set_key(i)
            text = flip.decrypt(ciphertext)
            if utilities.is_plaintext(text, dict_list, 0.7):
                key = i
                plaintext = text
                found = True
            i += 1
        return key, plaintext
