"""
-----------------------------
CP460 (Fall 2021)
Name: <------------------------- edit this
ID:   <------------------------- edit this
Assignment 4
-----------------------------
"""

"""Put any comments to the grader here"""

import utilities
import math
from copy import deepcopy


class Cryptanalysis:
    """
    ----------------------------------------------------
    Description: Class That contains cryptanalysis functions
                 Mainly for Vigenere and Shift Cipher 
                     but can be used for other ciphers
    ----------------------------------------------------
    """

    @staticmethod    
    def index_of_coincidence(text, base_type=None):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   text(str)
                      base_type(str): default = None
        Return:       I (float): Index of Coincidence
        Description:  Computes and returns the index of coincidence 
                      Uses English alphabets by default, otherwise, given base_type
        Asserts:      text is a string
        ----------------------------------------------------
        """
        assert type(text) == str, 'Error index_of_coincidence: invalid input'
        ic = 0
        # use the english alphabet by default
        # strip text
        cleantext = ""
        for c in text:
            if c.isalpha():
                cleantext += c
        text = cleantext
        N = len(text)
        freqs = utilities.get_freq(text, base_type)
        total = 0
        for i in range(len(freqs)):
            total += (freqs[i] * (freqs[i] - 1))
        if N > 0:
            ic = total / (N * (N - 1))
        
        return ic

    @staticmethod
    def IOC(text):
        """
        ----------------------------------------------------
        Same as Cryptanalysis.index_of_coincidence(text)
        ----------------------------------------------------
        """
        return Cryptanalysis.index_of_coincidence(text)
    
    @staticmethod
    def friedman(ciphertext):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext(str)
        Return:       list of two key lengths [int,int]
        Description:  Uses Friedman's test to compute key length
                      returns best two candidates for key length
                        Best candidates are the floor and ceiling of the value
                          Starts with most probable key, for example: 
                          if friedman = 3.2 --> [3, 4]
                          if friedman = 4.8 --> [5,4]
                          if friedman = 6.5 --> [6, 5]
        Asserts:      ciphertext is a non-empty string
        ----------------------------------------------------
        """
        n = len(ciphertext)
        I = Cryptanalysis.index_of_coincidence(ciphertext, None)
        k = (0.0265 * n) / ((0.065 - I) + n * (I - 0.0385))
        floor = k - math.floor(k)
        if floor >= 0.5:
            return [math.ceil(k), math.floor(k)]
        return [math.floor(k), math.ceil(k)]

    @staticmethod
    def chi_squared(text, language='English'):
        """
        ----------------------------------------------------
        Parameters:   text (str)
                      language (str): default = 'English'
        Return:       result (float)
        Description:  Calculates the Chi-squared statistics 
                      for given text against given language
                      Only alpha characters are considered
        Asserts:      text is a string
        Errors:       if language is unsupported:
                        print error msg: 'Error(chi_squared): unsupported language'
                        return -1
        ----------------------------------------------------
        """
        assert isinstance(text, str), "Error (chi_squared): invalid input"
        if language != 'English' or len(text) == 0:
            return -1
        else:
            expected_freqs = utilities.get_language_freq(language)
            
        # strip text
        cleantext = ""
        for c in text:
            if c.isalpha():
                cleantext += c
        text = cleantext
        
        freqs = utilities.get_freq(text, None)
        result = 0
        for i in range(len(freqs)):
            expected = expected_freqs[i] * len(text)
            result += (((freqs[i] - expected) ** 2) / expected)
        
        return result

    @staticmethod
    def cipher_shifting(ciphertext, args=[20, 26]):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
                      args (list):
                          max_key_length (int): default = 20
                          factor (int): default = 26
        Return:       Best two key lengths [int,int]
        Description:  Uses Cipher shifting to compute key length
                      returns best two candidates for key length
                      cipher shift factor determines how many shifts should be made
                      Cleans the text from all non-alpha characters before shifting
                      Upper and lower case characters are considered different chars
                      The returned two keys, are the ones that produced highest matches
                          if equal, start with smaller value
        Asserts:      ciphertext is a non-empty string
        ----------------------------------------------------
        """
        # strip text
        cleantext = ""
        for c in ciphertext:
            if c.isalpha():
                cleantext += c
        ciphertext = cleantext
        
        max_key_length = args[0]
        factor = args[1]
        
        original = ciphertext
        highest_matches = 0
        second_highest_matches = 0
        first_key = 0
        second_key = 0
        matches = 0
        i = 1
        while i < factor:
            matches = 0
            shifted = ciphertext[i:]
            # compare
            for j in range(len(shifted)):
                if shifted[j] == original[j]:
                    matches += 1
                    
            if matches > highest_matches:
                second_highest_matches = highest_matches
                highest_matches = matches
                second_key = first_key
                first_key = i
            elif matches > second_highest_matches:
                second_highest_matches = matches
                second_key = i
            i += 1
        
        if first_key > max_key_length:
            first_key %= max_key_length
        if second_key > max_key_length:
            second_key %= max_key_length
            
        if second_highest_matches == highest_matches:
            if second_key < first_key:
                return [second_key, first_key]
        
        return [first_key, second_key]


class Shift:
    """
    ----------------------------------------------------
    Cipher name: Shift Cipher
    Key:         (int,int,int): shifts,start_index,end_index
    Type:        Shift Substitution Cipher
    Description: Generalized version of Caesar cipher
                 Uses a subset of BASE for substitution table
                 Shift base by key and then substitutes
                 Case sensitive
                 Preserves the case whenever possible
                 Uses circular left shift
    ----------------------------------------------------
    """
    BASE = utilities.get_base('all') + ' '
    DEFAULT_KEY = (3, 26, 51)  # lower case Caesar cipher
    
    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (int,int,int): 
                        #shifts, start_index, end_indx 
                        (inclusive both ends of indices)
        Description:  Shift constructor
                      sets _key
        ---------------------------------------------------
        """
        self._key = key
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str)
        Description:  Returns a copy of the Shift key
        ---------------------------------------------------
        """
        return deepcopy(self._key)
       
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (str): non-empty string
        Return:       success: True/False
        Description:  Sets Shift cipher key to given key
                      #shifts is set to smallest value
                      if invalid key --> set to default key
        ---------------------------------------------------
        """ 
        valid = Shift.valid_key(key)
        if valid:
            new_key = key
            if key[0] < 0:
                new_key = (key[2] - key[1] + key[0] + 1, key[1], key[2])
            self._key = new_key
        else:
            self._key = self.DEFAULT_KEY
        return valid

    def get_base(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       base (str)
        Description:  Returns a copy of the base characters
                      base is the subset of characters from BASE
                      starting at start_index and ending with end_index
                      (inclusive both ends)
        ---------------------------------------------------
        """
        key = self.get_key()
        start = key[1]
        end = key[2] + 1
        
        return self.BASE[start:end]
        
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Shift object. Used for testing
                      output format:
                      Shift Cipher:
                      key = <key>
                      base = <base>
                      sub  = <sub>
        ---------------------------------------------------
        """
        key = self.get_key()
        base = self.get_base()
        sub = utilities.shift_string(base, int(key[0]), 'l')
        output = "Shift Cipher:\nkey = {}\nbase = {}\nsub  = {}".format(key, base, sub)
        return output

    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Shift key
                      A valid key is a tuple consisting of three integers
                          shifts, start_index, end_index
                      The shifts can be any integer
                      The start and end index should be positive values
                      such that start is smaller than end and both are within BASE
        ---------------------------------------------------
        """
        valid = True
        if not isinstance(key, tuple):
            valid = False
        elif len(key) != 3:
            valid = False
        elif not isinstance(key[0], int) or not isinstance(key[1], int) or not isinstance(key[2], int):
            valid = False
        elif key[1] > key[2]:
            valid = False
        elif key[1] < 0 or key[2] < 0:
            valid = False
        elif key[1] > len(Shift.BASE) or key[2] > len(Shift.BASE):
            valid = False
        
        return valid

    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Shift Cipher
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        key = self.get_key()
        base = self.get_base()
        sub = utilities.shift_string(base, int(key[0]), 'l')
        ciphertext = ""
        #go through each char, find the char in base, match to sub
        x = 0
        while x < len(plaintext): 
            # find the correct index
            i = 0
            found = False
            while i < len(base) and not found:
                if base[i] == plaintext[x]:
                    found = True
                else:
                    i += 1
            if not found:
                ciphertext += plaintext[x]
            else:
                # add new char to cipher - preserve case
                ciphertext += sub[i]
            
            x += 1
        return ciphertext

    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Shift Cipher
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        key = self.get_key()
        base = self.get_base()
        sub = utilities.shift_string(base, int(key[0]), 'l')
        
        x = 0
        i = 0
        plaintext = ""
        found = False
        while x < len(ciphertext): 
            # find the correct index
            i = 0
            found = False
            while i < len(sub) and not found:
                if sub[i] == ciphertext[x]:
                    found = True
                else:
                    i += 1
            if not found:
                plaintext += ciphertext[x]
            else:
                # add new char to cipher
                plaintext += base[i]
            
            x += 1
        return plaintext

    @staticmethod
    def cryptanalyze(ciphertext, args=['', -1, -1]):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext (string)
                      args (list):
                            base: (str): default = ''
                            shifts: (int): default = -1
                            base_length (int): default = -1 
        Return:       key,plaintext
        Description:  Cryptanalysis of Shift Cipher
                      Returns plaintext and key (shift,start_indx,end_indx)
                      Uses the Chi-square method
                      Assumes user passes a valid args list
        ---------------------------------------------------
        """
        base = args[0]
        shifts = args[1]
        base_length = args[2]
        s = Shift()
        plaintext = ""
        key = ""
        min_chi = 999999
        #case 1: known base and number of shifts
        if base!="" and shifts!=-1 and base_length!=-1:
            key = s.get_key()
            s.set_key((shifts,key[1],key[1]+base_length-1))
            plaintext = s.decrypt(ciphertext)
            key = s.get_key()
        elif base!="" and shifts==-1 and base_length==-1:
            base_length = len(base)
            start = s.BASE.find(base[0])
            end = start+base_length-1
            for i in range(base_length):
                s.set_key((i,start,end))
                text = s.decrypt(ciphertext)
                chi = Cryptanalysis.chi_squared(text, 'English')
                if chi<min_chi:
                    min_chi = chi
                    plaintext = text
                    key = (i,start,end)
        elif base=="" and shifts!=-1 and base_length!=-1:
            for i in range(len(s.BASE)-base_length):
                start = i
                end = i+base_length-1
                s.set_key((shifts,start,end))
                text = s.decrypt(ciphertext)
                chi = Cryptanalysis.chi_squared(text, 'English')
                if chi<min_chi:
                    min_chi = chi
                    plaintext = text
                    key = (shifts,start,end)
        elif base=="" and shifts==-1 and base_length!=-1:
            for i in range(len(s.BASE)-base_length):
                for j in range(base_length):
                    start = i 
                    end = i+base_length-1
                    shifts = j 
                    s.set_key((shifts,start,end))
                    text = s.decrypt(ciphertext)
                    chi = Cryptanalysis.chi_squared(text, 'English')
                    if chi<min_chi:
                        min_chi = chi
                        plaintext = text
                        key = (shifts,start,end)
        elif base!="" and shifts == -1 and base_length!=-1:
            start = s.BASE.find(base[0])
            end = start+len(base)-1
            for i in range(len(base)):
                s.set_key((i,start,end))
                text = s.decrypt(ciphertext)
                chi = Cryptanalysis.chi_squared(text, 'English')
                if chi<min_chi:
                    min_chi = chi
                    plaintext = text
                    key = (i,start,end)
        else:
            print("Cryptoanalysis Failed")
                
            
        return key,plaintext


class Vigenere:
    """
    ----------------------------------------------------
    Cipher name: Vigenere Cipher
    Key:         (str): a character or a keyword
    Type:        Polyalphabetic Substitution Cipher
    Description: if key is a single characters, uses autokey method
                    Otherwise, it uses a running key
                 In autokey: key = autokey + plaintext (except last char)
                 In running key: repeat the key
                 Substitutes only alpha characters (both upper and lower)
                 Preserves the case of characters
    ----------------------------------------------------
    """
    
    DEFAULT_KEY = 'k'
    
    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (str): default value: 'k'
        Description:  Vigenere constructor
                      sets _key
                      if invalid key, set to default key
        ---------------------------------------------------
        """
        self._key = key
    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str)
        Description:  Returns a copy of the Vigenere key
        ---------------------------------------------------
        """
        return deepcopy(self._key)
       
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (str): non-empty string
        Return:       success: True/False
        Description:  Sets Vigenere cipher key to given key
                      All non-alpha characters are removed from the key
                      key is converted to lower case
                      if invalid key --> set to default key
        ---------------------------------------------------
        """ 
        valid = Vigenere.valid_key(key)
        if valid:
            #strip
            new_key = ""
            for k in key:
                if k.isalpha():
                    new_key+=k.lower()
                self._key = new_key
        else:
            self._key = self.DEFAULT_KEY
        return valid
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Vigenere object. Used for testing
                      output format:
                      Vigenere Cipher:
                      key = <key>
        ---------------------------------------------------
        """
        output = "Vigenere Cipher:\nkey = {}".format(self.get_key())
        return output
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?):
        Returns:      True/False
        Description:  Checks if given key is a valid Vigenere key
                      A valid key is a string composing of at least one alpha char
        ---------------------------------------------------
        """
        valid = False
        if isinstance(key,str):
            for s in key:
                if s.isalpha():
                    valid = True
                    break
        return valid

    @staticmethod
    def get_square():
        """
        ----------------------------------------------------
        static method
        Parameters:   -
        Return:       vigenere_square (list of string)
        Description:  Constructs and returns vigenere square
                      The square contains a list of strings
                      element 1 = "abcde...xyz"
                      element 2 = "bcde...xyza" (1 shift to left)
        ---------------------------------------------------
        """
        base = utilities.get_base("lower")
        vigenere_square = []
        for i in range(len(base)):
            temp = utilities.shift_string(base, i, 'l')
            vigenere_square.append(temp)
        return vigenere_square

    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Encryption using Vigenere Cipher
                      May use an auto character or a running key
        Asserts:      plaintext is a string
        ---------------------------------------------------
        """
        assert type(plaintext) == str, 'invalid plaintext'
        
        if len(self._key) == 1:
            return self._encrypt_auto(plaintext)
        else:
            return self._encrypt_run(plaintext)

    def _encrypt_auto(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Private helper function
                      Encryption using Vigenere Cipher Using an autokey
        ---------------------------------------------------
        """
        base = self.get_square()
        key = self.get_key()
        line2 = key+plaintext[:-1]
        row = 0
        col = 0
        ciphertext=""
        for p in plaintext:
            if not p.isalpha():
                ciphertext+=p
            else:
                #take the next char from key
                curr_key = line2[0]
                line2 = line2[1:]
                #find col 
                if p.isupper():
                    col = ord(p)-65
                else:
                    col = ord(p)-97
                #find row
                if curr_key.isupper():
                    row = ord(curr_key)-65
                else:
                    row = ord(curr_key)-97
                if p.isupper():
                    ciphertext+=base[row][col].upper()
                else:
                    ciphertext+=base[row][col].lower()
        return ciphertext

    def _encrypt_run(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (str)
        Description:  Private helper function
                      Encryption using Vigenere Cipher Using a running key
        ---------------------------------------------------
        """
        base = self.get_square()
        key = self.get_key()
        #build line 2 by repeating the key to the length of the plaintext
        repeats = math.ceil(len(plaintext)/len(key))
        line2 = key*repeats
        ciphertext = ""
        row = 0
        col = 0
        for p in plaintext:
            if not p.isalpha():
                ciphertext+=p
            else:
                #take the next char from key
                curr_key = line2[0]
                line2 = line2[1:]
                #find col 
                if p.isupper():
                    col = ord(p)-65
                else:
                    col = ord(p)-97
                #find row
                if curr_key.isupper():
                    row = ord(curr_key)-65
                else:
                    row = ord(curr_key)-97
                if p.isupper():
                    ciphertext+=base[row][col].upper()
                else:
                    ciphertext+=base[row][col].lower()
                
        return ciphertext

    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Decryption using Vigenere Cipher
                      May use an auto character or a running key
        Asserts:      ciphertext is a string
        ---------------------------------------------------
        """
        assert type(ciphertext) == str, 'invalid input'
        
        if len(self._key) == 1:
            return self._decryption_auto(ciphertext)
        else:
            return self._decryption_run(ciphertext)

    def _decryption_auto(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Private Helper method
                      Decryption using Vigenere Cipher Using autokey
        ---------------------------------------------------
        """
        base = self.get_square()
        key = self.get_key()
        #build line 2 by repeating the key to the length of the plaintext
        line2 = key+ciphertext[:-1]
        plaintext = ""
        row = 0
        col = -1
        for c in ciphertext:
            if not c.isalpha():
                plaintext+=c
            else:
                #take the next char from key
                curr_key = line2[0]
                line2 = line2[1:]
                #the key gives you the row
                if curr_key.isupper():
                    row = ord(curr_key)-65
                else:
                    row = ord(curr_key)-97
                #to get the col, search the string at that row for c
                col = -1
                i=0
                while col==-1:
                    if base[row][i]==c.lower():
                        col = i
                    else:
                        i+=1
                if c.isupper():
                    plaintext+=base[0][col].upper()
                else:
                    plaintext+=base[0][col]
        
        return plaintext

    def _decryption_run(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (str)
        Description:  Private Helper method
                      Decryption using Vigenere Cipher Using running key
        ---------------------------------------------------
        """
        base = self.get_square()
        key = self.get_key()
        #build line 2 by repeating the key to the length of the plaintext
        repeats = math.ceil(len(ciphertext)/len(key))
        line2 = key*repeats
        plaintext = ""
        row = 0
        col = -1
        for c in ciphertext:
            if not c.isalpha():
                plaintext+=c
            else:
                #take the next char from key
                curr_key = line2[0]
                line2 = line2[1:]
                #the key gives you the row
                if curr_key.isupper():
                    row = ord(curr_key)-65
                else:
                    row = ord(curr_key)-97
                #to get the col, search the string at that row for c
                col = -1
                i=0
                while col==-1:
                    if base[row][i]==c.lower():
                        col = i
                    else:
                        i+=1
                if c.isupper():
                    plaintext+=base[0][col].upper()
                else:
                    plaintext+=base[0][col]
        
        return plaintext
    
    @staticmethod
    def cryptanalyze_key_length(ciphertext):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   ciphertext (str)
        Return:       key_lenghts (list)
        Description:  Finds key length for Vigenere Cipher
                      Combines results of Friedman and Cipher Shifting
                      Produces a list of key lengths from the above two functions
                      Start with Friedman and removes duplicates
        ---------------------------------------------------
        """
        # combines the outputs of both Friedman and cipher shifting
        #the key lengths generated by the two methods are combined
        #in a list after removing the duplicates
        friedman = Cryptanalysis.friedman(ciphertext)
        cipher_shifting = Cryptanalysis.cipher_shifting(ciphertext)
        #combine two lists, if there is a duplicate put it first
        key_lengths = []
        
        if friedman[0] in cipher_shifting:
            key_lengths.append(friedman[0])
        elif friedman[1] in cipher_shifting:
            key_lengths.append(friedman[1])
        #append all other key lengths
        for f in friedman:
            if f not in key_lengths:
                key_lengths.append(f)
        for c in cipher_shifting:
            if c not in key_lengths:
                key_lengths.append(c)
        
        return key_lengths

    @staticmethod
    def cryptanalyze(ciphertext):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext (string)
        Return:       key,plaintext
        Description:  Cryptanalysis of Shift Cipher
                      Returns plaintext and key (shift,start_indx,end_indx)
                      Uses the key lengths produced by Vigenere.cryptanalyze_key_length
                      Finds out the key, then apply chi_squared
                      The key with the lowest chi_squared value is returned
        Asserts:      ciphertext is a non-empty string
        ---------------------------------------------------
        """
        # to find the key, you need to iterate through the key lengths
        # generated by the previous steps. For each key, the ciphertext
        #should be broken into blocks then baskets
        #for each basket you need to cryptoanalyze using the shift cipher
        #the vigenere key is the concatenation of the letters generated
        #by the shift ciphers cryptoanalysis
        #after finding the key pertaining to each key length
        #compute the chi squared value for all keys. The one with the smallest
        #value shouuld be returned, along with the recovered plaintext
        
        #get key lengths
        key_lengths = Vigenere.cryptanalyze_key_length(ciphertext)
        
        min_chi = 999999
        final_key = -1
        base = "abcdefghijklmnopqrstuvwxyz"
        non_alpha = utilities.get_base('nonalpha')
        positions = utilities.get_positions(ciphertext, non_alpha+" \t\n")
        ciphertext = utilities.clean_text(ciphertext, non_alpha+" \t\n")
        #iterate through the key lengths
        for k in key_lengths:
            curr_key = ""
            curr_text = ""
            #break the text into blocks of size k
            blocks = utilities.text_to_blocks(ciphertext, k, True,"q")
            #break those blocks into baskets
            baskets = utilities.blocks_to_baskets(blocks)
            #for each basket, cryptoanalyze 
            for basket in baskets:
                key,plaintext= Shift.cryptanalyze(basket,[base,-1,-1])
                shifts = key[0]
                curr_key+=base[shifts]
                curr_text+=plaintext
            #get the chi squared of current text to compare it to english
            chi = Cryptanalysis.chi_squared(curr_text,'English')
            #replace the final text if it is closer to english
            if chi<min_chi:
                min_chi = chi
                final_key = curr_key
                final_text = curr_text
        utilities.insert_positions(final_text, positions)   
            
        return final_key, final_text
