import utilities

def test_basics():
    print('{}'.format('-'*40))
    print("Start of get_base, get_langauge_freq Testing")
    print()
    
    print('Testing get_base:')
    cases = ['lower', 'upper', 'alpha', 'lowernum', 'uppernum', 'alphanum', 'special', 
             'nonalpha', 'B6', 'BA', 'all', 'alphadec']
    for base in cases:
        print('base = {}'.format(base))
        print(utilities.get_base(base))
        print()
        
    print('Testing get_language_freq:')
    cases = ['English','French']
    for language in cases:
        print('get_language_freq({})'.format(language))
        print(utilities.get_language_freq(language))
        print()
        
    print('End of get_base Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_files():
    print('{}'.format('-'*40))
    print("Start of is_valid_filename, file_to_text and text_to_file Testing")
    print()
    
    print('Testing is_valid_filename:')
    filenames = ['plaintext.txt', 'ciphertext1.py', 'output.c', 'plaintext2', '.py',
                 'text.', 'plain.text.txt', 'input-py']
    for filename in filenames:
        print('is_valid_filename({}) = {}'.format(filename,utilities.is_valid_filename(filename)))
    print()
    
    texts = []
    
    print('Testing file_to_text:')
    for i in range(1,4):
        filename = 'plaintext' + str(i) + '.txt'
        print('loading file {}'.format(filename))
        text = utilities.file_to_text(filename)
        texts.append(text)
        print(text)
    
    print('Testing text_to_file:')
    for i in range(1,4):
        filename = 'output' + str(i) + '.txt'
        print('Writing to file {}: '.format(filename),end='')
        utilities.text_to_file(texts[i-1], filename)
        if utilities.file_to_text(filename) == texts[i-1]:
            print('Written data matches input data')
        else:
            print('Mismatch between written data and input data')
    print()
        
    print('End of is_valid_filename, file_to_text and text_to_file Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_dictionary():
    print('{}'.format('-'*40))
    print("Start of load_dictionary, text_to_words, analyze_text and is_plaintext Testing")
    print()

    print('Testing load_dictionary:')
    dict_files = ['english3.txt','engmix.txt']
    for dict_file in dict_files:
        print('Loading dictionary file {}'.format(dict_file))
        dict_list = utilities.load_dictionary(dict_file)
        print("Number of words starting with b = ",len(dict_list[1]))
        print("10th word starting with P = ",dict_list[15][9])
        print("100th word starting with j = ",dict_list[9][99])
        print("Last word starting with s = ",dict_list[18][-1])
        print()
    
    print("Testing text_to_words:")
    for i in range(1,4):
        filename = 'plaintext'+str(i)+'.txt'
        text = utilities.file_to_text(filename)
        word_list = utilities.text_to_words(text)
        print(word_list)
        print()
 
    
    print("Testing analyze_text:")
    files = ['plaintext1.txt','plaintext2.txt','plaintext3.txt','ciphertext1.txt','ciphertext2.txt']
    dict_list = utilities.load_dictionary('engmix.txt')
    for i in range(len(files)):
        text = utilities.file_to_text(files[i])
        result = utilities.analyze_text(text,dict_list)
        print(result)
    print()
     
    print("Testing is_plaintext:")
    thresholds = [0.85,0.9,0.83,0.65,0.5]
    for i in range(len(files)):
        text = utilities.file_to_text(files[i])
        result = utilities.is_plaintext(text,dict_list,thresholds[i])
        print(result)
    print(utilities.is_plaintext(text,dict_list,0.6)) #the last file
    print()
    
    print('End of load_dictionary, text_to_words, analyze_text and is_plaintext Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_matrix():
    print('{}'.format('-'*40))
    print("Start of new_matrix, print_matrix and index_2d Testing")
    print()
     
    print('Testing new_matrix and print_matrix:')
    row = [2,3,0,6]
    column = [2,4,5,1]
    fill = ['A',0,'x','H']
    for i in range(len(row)):
        print('#rows = {}, #columns = {}, fill = {}'.format(row[i], column[i], fill[i]))
        matrix = utilities.new_matrix(row[i], column[i], fill[i])
        utilities.print_matrix(matrix)
        print()
        
    print('Testing index_2d:')
    list1 = [[1,2,3],[4,5],[6,7,8,9,10],[11],[12,13]]
    print('list1 = {}'.format(list1))
    cases = [2,5,6,11,12,18]
    for case in cases:
        print('{} is at {}'.format(case,utilities.index_2d(list1,case)))
    print()

    print('End of new_matrix, print_matrix and index_2d Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_strings():
    print('{}'.format('-'*40))
    print("Start of shift_string and matrix_to_string Testing")
    print()
    
    text = 'Cryptography is the fun part of math'
    print('Testing shift_string:')
    print('shift_string(text,4)    = {}'.format(utilities.shift_string(text,4)))
    print('shift_string(text,-4)   = {}'.format(utilities.shift_string(text,-4)))
    print('shift_string(text,5,l)  = {}'.format(utilities.shift_string(text,5,'l')))
    print('shift_string(text,6,r)  = {}'.format(utilities.shift_string(text,6,'r')))
    print('shift_string(text,-4,r) = {}'.format(utilities.shift_string(text,-4,'r')))
    print('shift_string(text,7,k)  = {}'.format(utilities.shift_string(text,7,'k')))
    print('shift_string(text,300)  = {}'.format(utilities.shift_string(text,300)))
    print('shift_string(text,-99)  = {}'.format(utilities.shift_string(text,-99)))
    print()
    
    print('Testing matrix_to_string:')
    matrix1 = [['M','O','V','E'],['T','H','E','T'],['R','O','O','P'],['S','S','O','U'],['T','H','q','q']]
    print(matrix1)
    print(utilities.matrix_to_string(matrix1))
    print()
    
    matrix1 = [['I',' ','a','m'],[' ','a',' ','cryptographer',' '], ['not',' ','working'],
               [' ','for',' ','the',' ','NSA']]
    print(matrix1)
    print(utilities.matrix_to_string(matrix1))
    print()
    
    print('End of shift_string Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_positions():
    print('{}'.format('-'*40))
    print("Start of get_positions, clean_text and insert_positions Testing")
    print()

    print('Testing get_positions:')
    str1 = 'One Must Acknowledge With Cryptography No Amount of Violence Will Ever Solve a Math Problem.'
    print('str1 = {}'.format(str1))
    print('get_positions(str1,get_base("upper")) --> ',end='')
    print('{}'.format(utilities.get_positions(str1,utilities.get_base('upper'))))
    print('get_positions(str1,get_base("vwxyz")) --> ',end='')
    print('{}'.format(utilities.get_positions(str1,'vwxyz')))
    print('get_positions(str1,get_base("special")) --> ',end='')
    print('{}'.format(utilities.get_positions(str1,utilities.get_base('special'))))
    print()
    
    print('Testing clean_text:')
    str2 = utilities.clean_text(str1,utilities.get_base('upper'))
    print('clean_text(str1,get_base("upper")) = {}'.format(str2))
    str3 = utilities.clean_text(str1,utilities.get_base('lower'))
    print('clean_text(str1,get_base("lower")) = {}'.format(str3))
    str4 = utilities.clean_text(str1,'abcdefghij')
    print('clean_text(str1,"abcdefghij") = {}'.format(str4))
    str5 = utilities.clean_text(str1,' \n')
    print('clean_text(str1," \\n") = {}'.format(str5))
    print()
    
    print('Testing insert_positions:')
    string = utilities.get_positions(str1,utilities.get_base('upper'))
    print(utilities.insert_positions(str2,string))
    string = utilities.get_positions(str1,utilities.get_base('lower'))
    print(utilities.insert_positions(str3,string))
    string = utilities.get_positions(str1,'abcdefghij')
    print(utilities.insert_positions(str4,string))
    string = utilities.get_positions(str1,' \n')
    print(utilities.insert_positions(str5,string))
    print()
        
    print('End of get_positions, clean_text and insert_positions Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_text_analysis():
    print('{}'.format('-'*40))
    print("Start of text_to_blocks, compare_texts and get_freq Testing")
    print()
    
    print('---------- Testing text_to_blocks:\n')
    text = 'Cryptography is the fun part of math'
    print('Text = {}\n'.format(text))
    
    block_size = [4,5,7,8,10]
    padding = [None,None,False,True,True]
    pad = [None,None,None,None,'x']
    for i in range(len(block_size)):
        if i < 2:
            blocks = utilities.text_to_blocks(text,block_size[i])
        elif i < 4:
            blocks = utilities.text_to_blocks(text,block_size[i],padding[i])
        else:
            blocks = utilities.text_to_blocks(text,block_size[i],padding[i], pad[i]) 
        print('block_size = {}, padding = {}, pad = {}'.format(block_size[i],padding[i],pad[i]))
        print(blocks)
        print()

    print('--------- Testing blocks_to_baskets:')
    text = 'CP460 is my favorite course in Fall 2021'
    sizes = [3,4,5]
    for size in sizes:
        blocks = utilities.text_to_blocks(text,size,True,'Q')
        print('blocks = {}'.format(blocks))
        baskets = utilities.blocks_to_baskets(blocks)
        print('baskets= {}'.format(baskets))
        print()
    
    blocks = ['ABCD',[10,11,12],['AB',12,'EF'],['ABC',['123'],'DEF'],['ABC','AB','CDE']]
    for b in blocks:
        print('blocks = {}'.format(b))
        baskets = utilities.blocks_to_baskets(b)
        print('baskets= {}'.format(baskets))
        print()

    print('-------------- Testing Compare Texts:')
    plaintext1 = utilities.file_to_text('ciphertext2.txt')
    cut = [10,100,0,len(plaintext1)]
    for i in cut:
        plaintext2 = plaintext1[:i]+plaintext1[i+1:]
        print('Result{} = {}'.format(cut.index(i)+1,utilities.compare_texts(plaintext1,plaintext2)))
    print()
    
    print('-------------- Testing get_freq:')
    bases = ['', 'abc' ,'lower','upper','nonalpha','B6']
    for i in range(len(bases)):
        if i >= 2:
            base = utilities.get_base(bases[i])
        else:
            base = bases[i]
        print('Base = {}'.format(base))
        print(utilities.get_freq(plaintext1,base))
        print()
        
    print('End of text_to_blocks, compare_texts and get_freq Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_binary():
    print('{}'.format('-'*40))
    print("Start of is_binary, bin_to_dec, dec_to_bin and xor Testing")
    print()
    
    print('Testing is_binary:')
    cases = ['0','1','01','110','110101','2','0-1',1,[0]]
    for b in cases:
        print('{} --> {}'.format(b,utilities.is_binary(b)))
    print()
    
    print('Testing bin_to_dec:')
    cases = ['0','1','01','110','110101','110110',100]
    for b in cases:
        print('{} --> '.format(b),end='')
        print(utilities.bin_to_dec(b))
    print()
    
    print('Testing dec_to_bin:')
    cases = [0,1,3,7,113]
    sizes = [None,None,3,None,12]
    for i in range(len(cases)):
        print('{} --> {}'.format(cases[i],utilities.dec_to_bin(cases[i], sizes[i])))
    utilities.dec_to_bin(24,3)
    utilities.dec_to_bin(24,'3')
    utilities.dec_to_bin(1,0)
    print()
    
    print('Testing xor:')
    a = ['0','0','1','1','101','11010110']
    b = ['0','1','0','1','001','01100010']
    for i in range(len(a)):
        print('{} xor {} = {}'.format(a[i],b[i],utilities.xor(a[i], b[i])))
    utilities.xor(110,'001')
    utilities.xor('001',101)
    utilities.xor('0010','010')
    print()
                           
    print('End of is_binary, bin_to_dec, dec_to_bin and xor Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_coding():
    print('{}'.format('-'*40))
    print("Start of encode and decode Testing")
    print()
    
    print("encode('A','ASCII') = ",utilities.encode('A','ASCII'))
    print("encode('\\n','ASCII') = ",utilities.encode('\n','ASCII'))
    print("encode('A','B6') = ",utilities.encode('A','B6'))
    print("encode('\\n','B6') = ",utilities.encode('\n','B6'))
    print("encode('a','B6') = ",utilities.encode('a','B6'))
    print("encode('','B6') = ",end ='')
    utilities.encode('','B6')
    print("encode(1,'B6') = ",end ='')
    utilities.encode(1,'B6')
    print("encode('A','Unicode') = ",end ='')
    utilities.encode('A','Unicode')
    print("encode('AB') = ",end = '')
    utilities.encode('AB','B6')
    print()
    
    print('Testing Decoding:')
    print("decode('01000001','ASCII') = ",utilities.decode('01000001','ASCII'))
    print("decode('01101101','ASCII') = ",utilities.decode('01101101','ASCII'))
    print("decode('100100','B6') = ",utilities.decode('100100','B6'))
    print("decode_B6('000010') = ",utilities.decode('000010','B6'))
    print("decode(1000001,'ASCII') = ",end ='')
    utilities.decode(1000001,'ASCII')
    print("decode('01000001','Unicode') = ",end ='')
    utilities.decode('01000001','Unicode')
    print("decode('','ASCII') = ",end ='')
    utilities.decode('','ASCII')
    print("decode_B6(100000) = ",end='')
    utilities.decode(100000,'B6')
    print("decode_B6('0100000') = ",end='')
    utilities.decode('0100000','B6')
    print()
    
    print('End of encode and decode Testing')
    print('{}'.format('-'*40))
    print()
    return  

test_basics()  #get_base
test_files() #file_to_text, text_to_file
test_dictionary() #load_dictionary, text_to_words, analyze_text, is_plaintext
test_matrix() # new_matrix, print_matrix index_2d
test_strings() #shift_string, matrix_to_string
test_positions() #get_positions, clean_text, insert_positions
test_text_analysis() #text_to_blocks, compare_texts, get_freq
test_binary() #is_binary, bin_to_dec, dec_to_bin and xor
test_coding() #encode, decode