"""
-----------------------------
CP460 (Fall 2021)
Name: Maxwell Dann
ID:   190274440
Assignment 3
-----------------------------
"""
from copy import deepcopy
import math
from _ast import keyword
"""Columnar transposition inspired by https://www.geeksforgeeks.org/columnar-transposition-cipher/"""

import utilities


class Columnar_Transposition:
    """
    ----------------------------------------------------
    Cipher name: Columnar Transposition Cipher
    Key:         (str) a keyword
    Type:        Transposition Cipher
    Description: Constructs a table from plaintext, 
                 #columns = len(keyword)
                 Rearrange columns based on keyword order
                 Read the text vertically
                 Applies to all characters except whitespaces
    ----------------------------------------------------
    """
    
    DEFAULT_PAD = 'q'
    DEFAULT_PASSWORD = 'abcd'
    
    def __init__(self, key=DEFAULT_PASSWORD, pad=DEFAULT_PAD):
        """
        ----------------------------------------------------
        Parameters:   _key (str): default = abcd
                      _pad (str): a character, default = q
        Description:  Columnar Transposition constructor
                      sets _key and _pad
        ---------------------------------------------------
        """
        self._key = key
        self._pad = pad
                    
    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       key (str)
        Description:  Returns a copy of columnar transposition key
        ---------------------------------------------------
        """
        return deepcopy(self._key)
    
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (str): keyword
        Return:       success: True/False
        Description:  Sets key to given key
                      if invalid key --> set to default key
        ---------------------------------------------------
        """
        valid = self.valid_key(key)
        if valid:
            self._key = key
        else:
            self._key = self.DEFAULT_PASSWORD
        return valid

    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str)
        Description:  Constructs and returns a string representation of 
                      Columnar Transposition object
                      output format:
                      Columnar Transposition Cipher:
                      key = <key>, pad = <pad>
        ---------------------------------------------------
        """
        output = "Columnar Transposition Cipher:\nkey = {}, pad = {}".format(self.get_key(), self.get_pad())
        return output
        
    def get_pad(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       pad (str): current padding character
        Description:  Returns a copy of current padding character
        ---------------------------------------------------
        """ 
        return deepcopy(self._pad)
    
    def set_pad(self, pad):
        """
        ----------------------------------------------------
        Parameters:   pad (str): a padding character
        Return:       success: True/False
        Description:  Sets pad to given character
                      a pad should be a single character
                      if invalid pad, set to default value
        ---------------------------------------------------
        """ 
        valid = isinstance(pad, str) and len(pad) == 1
        if valid:
            self._pad = pad
        else:
            self._pad = self.DEFAULT_PAD
        return valid
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?): an arbitrary input
        Returns:      True/False
        Description:  Check if given input is a valid Columnar Transposition key
                      A valid key is a string consisting of at least two unique chars
        ---------------------------------------------------
        """
        valid = True
        base = " " + utilities.get_base('all')
        if not isinstance(key, str):
            valid = False
        elif len(key) == 2:
            if key[0] == key[1]:
                valid = False
        elif len(key) > 2:
            k = 0
            while valid and k < len(key):
                if key[k] not in base:
                    valid = False
                k += 1
        elif len(key) < 2:
            valid = False
        return valid
 
    @staticmethod
    def key_order(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (str)           
        Return:       key_order (list)
        Description:  Returns key order
                      Example: [mark] --> akmr --> [1,3,0,2]
                      If invalid key --> return []
                      Applies to all ASCII characters from space to ~
                      Discards duplicate characters
        ----------------------------------------------------
        """  
        key = str(key)
        
        no_dupes = ""
        for char in key:
            if char not in no_dupes:
                no_dupes += char
        # sort list, match up entries with sorted list
        base = " " + utilities.get_base('all')
        positions = utilities.get_positions(base, no_dupes)
        l = len(no_dupes)
        key_order = [0] * l
        for i in range(l):
            for j in range(l):
                if no_dupes[i] == positions[j][0]:
                    key_order[j] = i
        return key_order

    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (list)
        Description:  Encryption using Columnar Transposition Cipher
                      Does not include whitespaces in encryption
                      Uses padding
        Asserts:      plaintext is a string
        ----------------------------------------------------
        """
        assert isinstance(plaintext, str), "Error(encrypt): invalid input"
        key = self.get_key()
        key2 = ""
        # remove duplicates from key
        for char in key:
            if char not in key2:
                key2 += char
                
        # get rid of whitespaces
        whitespaces = " \t\n"
        ws_positions = utilities.get_positions(plaintext, whitespaces)
        plaintext = utilities.clean_text(plaintext, whitespaces)
        
        l = len(plaintext)
        r = math.ceil(l / len(key2))
        c = len(key2)
        pad = self.get_pad()
        matrix = utilities.new_matrix(r, c, pad)
        s = 0
        
        # fill matrix
        for i in range(r):
            for j in range(c):
                if s < len(plaintext):
                    matrix[i][j] = plaintext[s]
                else:
                    matrix[i][j] = pad
                s += 1
        # transpose matrix
        columnar = Columnar_Transposition(key)
        order = columnar.key_order(key)
        ciphertext = ""
        for i in range(c):
            col = order[i]
            for j in range(r):
                temp = matrix[j][col]
                ciphertext += temp
        
        # add whitespaces back in
        ciphertext = utilities.insert_positions(ciphertext, ws_positions)
                
        return ciphertext
        
    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (list)
        Description:  Decryption using Columnar Transposition Cipher
        Asserts:      ciphertext is a string
        ----------------------------------------------------
        """
        # steps: remove whitespaces, make matrix, 
        #        populate matrix, read matrix in key order
        plaintext = ""
        # get rid of whitespaces
        whitespaces = " \t\n"
        ws_positions = utilities.get_positions(ciphertext, whitespaces)
        ciphertext = utilities.clean_text(ciphertext, whitespaces)
        
        key = self.get_key()
        key2 = ""
        # remove duplicates from key
        for char in key:
            if char not in key2:
                key2 += char
        r = math.ceil(len(ciphertext) / len(key2))
        c = len(key2)
        
        # make matrix
        pad = self.get_pad()
        matrix = utilities.new_matrix(r, c, pad)
        s = 0

        # fill matrix vertically
        x = 0
        for i in range(c):
            for j in range(r):
                if x >= len(ciphertext):
                    break;
                else:
                    matrix[j][i] = ciphertext[x]
                    x += 1
        
        # get column order
        columnar = Columnar_Transposition(key)
        order = columnar.key_order(key)
        
        # read matrix
        pad = self.get_pad()
        index = 0
        for i in range(r):
            index = 0
            for j in range(c):
                curr = order.index(index)
                temp = matrix[i][curr]
                if temp != pad:
                    plaintext += temp
                index += 1   
        # add whitespaces back in
        plaintext = utilities.insert_positions(plaintext, ws_positions)
        
        return plaintext


class Polybius:
    """
    ----------------------------------------------------
    Cipher name: Polybius Square Cipher (205-123 BC)
    Key:         tuple(start_char,size)
    Type:        Substitution Cipher
    Description: Substitutes every character with two digit number [row#][column#]
                 Implementation allows different square sizes with customized start ASCII char
                 Default square is 5x5 starting at 'a' and ending in 'y' (z not encrypted)
                 Encrypts/decrypts only characters defined in the square
    ----------------------------------------------------
    """
    
    DEFAULT_KEY = ('a', 5)

    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (str): default = ('a',5)
        Description:  Polybius Cipher constructor
                      sets _key
        ---------------------------------------------------
        """
        self._key = key

    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Returns:      key (tuple)
        Description:  Returns a copy of current key
        ---------------------------------------------------
        """
        return deepcopy(self._key)
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?): an arbitrary input
        Returns:      True/False
        Description:  Check if given input is a valid Polybius key
                      A valid key is a tuple with two elements
                      First element (start_char) is a single ASCII character
                      Second element (size) is an integer
                      The start_char should be an ASCII value between space and ~
                      The size should be an integer in the range [2,9]
                      The combination of start_char and size should not result in
                      a string that is beyond the ASCII range of [' ', '~']
        ---------------------------------------------------
        """
        valid = True
        p = Polybius()

        if not isinstance(key, tuple):
            valid = False
        elif not len(key) == 2:
            valid = False
        elif not isinstance(key[0], str):
            valid = False
        elif not len(key[0]) == 1:
            valid = False
        elif not isinstance(key[1], int):
            valid = False 
        elif not (ord(key[0]) >= 32 and ord(key[0]) <= 126 and ord(key[0]) + key[1] <= ord("~")):
            valid = False
        elif key[1] < 2 or key[1] > 9:
            valid = False
        else:
            # check to see that there are enough chars to make a table
            p._key = key
            base = p._get_base()
            size = int(key[1] ** 2)
            if len(base) < size or key[0] not in base:
                valid = False
        
        return valid
    
    def get_square(self, mode='list'):
        """
        ----------------------------------------------------
        Parameters:   mode(str)= 'list' or 'string'
        Returns:      square (2D list)
        Description:  Constructs Polybius square from key
                      Square can be returned as a 2D list or
                      as a string formatted as a matrix
        Errors:       if mode is not 'list' or 'string'
                          print error_msg: 'Error(Polybius.get_square): undefined mode'
                          return empty string
        ---------------------------------------------------
        """
        if mode != 'list' and mode != 'string':
            print('Error(Polybius.get_square): undefined mode')
        
        key = self.get_key()
        size = key[1]
        text = self._get_base()
        # fill table
        x = 0
        table = utilities.new_matrix(size, size, " ")
        
        for i in range(size):
            for j in range(size):
                table[i][j] = text[x]
                x += 1
        if mode == 'list':
            return table
        else:
            output = ""
            for i in range(size):
                for j in range(size):
                    output += table[i][j]
                    output += "  "
                if i != size - 1:
                    output += "\n"

            return output
    
    def _get_base(self):
        """
        ----------------------------------------------------
        A private helper function that returns the characters defined
        in the Polybius square as a single string
        String begins with start_char and ends with key*key subsequent chars
        ---------------------------------------------------
        """
        base = ""
        for i in range(32, 127):
            base += chr(i)
        chars = ""
        key = self.get_key()
        size = key[1] * key[1]
        # find start char of table
        x = 0
        found = False
        while not found and x < len(base):
            if base[x] == key[0]:
                found = True
            else:
                x += 1
        # line up base with key
        chars = base[x:x + size]
        return chars
    
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (tuple)
        Returns:      success (True/False)
        Description:  Sets Polybius object key to given key
                      Does not update key if invalid key
                      Returns success status: True/False
        ---------------------------------------------------
        """
        p = Polybius()
        valid = p.valid_key(key)
        if valid:
            self._key = key
        return valid
        
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str): string representation
        Description:  Returns a string representation of polybius
                      Format:
                      Polybius Cipher:
                      key = <key>
                      <polybius_square in matrix format>
        ---------------------------------------------------
        """
        output = "Polybius Cipher:\nkey = {}\n{}".format(self.get_key(), self.get_square("string"))
        return output
    
    def encode(self, plainchar):
        """
        -------------------------------------------------------
        Parameters:   plainchar(str): single character
        Return:       cipher(str): two digit number
        Description:  Substitutes a character with corresponding two numbers
                          using the defined Polybius square
                      If character is not defined in square return ''
        Errors:       if input is not a single character --> 
                         msg: 'Error(Polybius.encode): invalid input'
                         return empty string
        -------------------------------------------------------
        """
        num = ""
        if not isinstance(plainchar, str) or len(plainchar) != 1:
            print("Error(Polybius.encode): invalid input")
        else:
            square = self.get_square('list')
            i, j = utilities.index_2d(square, plainchar)
            if i != -1 and j != -1:
                num = str(i + 1) + str(j + 1)
        return num

    def decode(self, cipher):
        """
        -------------------------------------------------------
        Parameters:   cipher(str): two digit number
        Return:       plainchar(str): a single character
        Description:  Substitutes a two digit number with a corresponding char
                          using the defined Polybius square
                      If invalid two digit number return empty string
        Errors:       if input is not string composing of two digits  --> 
                         msg: 'Error(Polybius.decode): invalid input'
                         return empty string
        -------------------------------------------------------
        """
        plainchar = ""
        if not isinstance(cipher, str):
            print("Error(Polybius.decode): invalid input")
        elif len(cipher) != 2:
            print("Error(Polybius.decode): invalid input")
        elif not ('0' <= cipher[0] <= '9' or '0' <= cipher[1] <= '9'):
            print("Error(Polybius.decode): invalid input")
        else:
            square = self.get_square('list')
            size = len(square)
            row = int(cipher[0])
            col = int(cipher[1])
            if row <= size and col <= size and row > 0 and col > 0:
                plainchar = square[row - 1][col - 1]
        return plainchar
    
    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (list)
        Description:  Encryption using Polybius cipher
                      Encrypts only characters defined in the square
        Asserts:      plaintext is a string
        ----------------------------------------------------
        """
        assert isinstance(plaintext, str), "Error(encrypt): invalid input"
        ciphertext = ""
        for p in plaintext:
            temp = self.encode(p)
            if temp == "":
                ciphertext += p
            else:
                ciphertext += temp
        
        return ciphertext

    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (list)
        Description:  decryption using Polybius cipher
                        decrypts only 2 digit numbers
        Asserts:      ciphertext is a string
        ----------------------------------------------------
        """
        assert isinstance(ciphertext, str), "Error(decrypt): invalid input"
        
        plaintext = ""
        x = 0
        y = 1
        l = len(ciphertext)
        
        while y < len(ciphertext):
            c1 = ciphertext[x]
            if y < len(ciphertext):
                c2 = ciphertext[y]
            if not '0' <= c1 <= '9' or not '0' <= c2 <= '9':
                plaintext += c1
                x += 1
                l -= 1
            else:
                c = c1 + c2
                temp = self.decode(c)
                if temp == "":
                    plaintext += ""
                    l -= 1
                else:
                    plaintext += temp
                    l -= 2
                x += 2
            y = x + 1
        
        if l != 0:
            plaintext += ciphertext[-1]
        return plaintext

    @staticmethod
    def cryptanalyze(ciphertext, args=['', 0, 0, None, 0.93]):
        """
        ----------------------------------------------------
        Static method
        Parameters:   ciphertext (string)
                      args (list):
                            start_char: (str): default = ''
                            min_size: (int): default = 0
                            max_size: (int): default = 0
                            dictionary_file (str): default = None
                            threshold (float): default = 0.93
        Return:       key,plaintext
        Description:  Cryptanalysis of Polybius Cipher
                      Returns plaintext and key (start_char,size)
                      Assumes user passes a valid args list
                      Uses bruteforce for the sizes is in range [min_size,max_size]
                      The square is always located between [' ', '~'] ASCII characters
        ---------------------------------------------------
        """
        key = ""
        plaintext = ""
        start_char = args[0]
        min_size = args[1]
        max_size = args[2]
        dict_file = args[3]
        threshold = args[4]
        
        p = Polybius()
        
        if dict_file is None:
            dict_list = utilities.load_dictionary('engmix.txt')
        else:
            dict_list = utilities.load_dictionary(dict_file)
        
        base = ""
        
        if max_size == 0:
            max_size = 9
        if min_size == 0:
            min_size = 2
        for i in range(32, 127):
            base += chr(i)
        
        if start_char != "":
            # line up base with start char
            found = False
            x = 0
            while x < len(base) and not found:
                if base[x] == start_char:
                    found = True
                else:
                    x += 1
            if max_size != 0 and max_size ** 2 < len(base):
                base = base[x:x + max_size ** 2]
            else:
                base = base[x:]
            if min_size == max_size:
                p.set_key((start_char, max_size))
                text = p.decrypt(ciphertext)
                if utilities.is_plaintext(text, dict_list, threshold):
                    key = (start_char, min_size)
                    plaintext = text
            else:
                for i in range(min_size, max_size + 1):
                    p.set_key((start_char, i))
                    text = p.decrypt(ciphertext)
                    if utilities.is_plaintext(text, dict_list, threshold):
                        key = (start_char, i)
                        plaintext = text
                        break   
        else: 
            found = False
            x = 0
            for i in range(min_size, max_size + 1):
                x = 0
                while x < len(base) and not found:
                    p.set_key((base[x], i))
                    text = p.decrypt(ciphertext)
                    if utilities.is_plaintext(text, dict_list, threshold):
                        key = (base[x], i)
                        plaintext = text
                        found = True
                    else:
                        x += 1
                if found:
                    break
        if key == plaintext:
            print("Polybius.cryptanalyze: cryptanalysis failed")
        return key, plaintext


class Simple_Substitution:
    """
    ----------------------------------------------------
    Cipher name: Simple Substitution Cipher
    Key:         tuple(keyword(str),base(str))
    Type:        Substitution Cipher
    Description: The base is a stream of unique characters
                 Only characters defined in the base are substituted
                 The base is case insensitive
                 The keyword is a random arrangement of the base, or some of its characters
                 The substitution string is the keyword, then all base characters
                     not in keyword, while maintaining their order in the base
                 The case of characters should be preserved whenever possible
    ----------------------------------------------------
    """
    DEFAULT_KEY = ('frozen', 'abcdefghijklmnopqrstuvwxyz')

    def __init__(self, key=DEFAULT_KEY):
        """
        ----------------------------------------------------
        Parameters:   _key (str)
        Description:  Simple Substitution Cipher constructor
                      sets _key
        ---------------------------------------------------
        """
        self._key = key

    def get_key(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Returns:      key (tuple)
        Description:  Returns a copy of current key
        ---------------------------------------------------
        """
        return deepcopy(self._key)
    
    @staticmethod
    def valid_key(key):
        """
        ----------------------------------------------------
        Static Method
        Parameters:   key (?): an arbitrary input
        Returns:      True/False
        Description:  Check if given input is a valid Simple Substitution key
                      The key is a tuple composing of two strings
                      The base should contain at least two unique characters
                      The keyword should have at least two unique characters defined in the base
        ---------------------------------------------------
        """
        # key - (keyword,base)
        valid = True
        if len(key) != 2:
            valid = False
        elif not isinstance(key[0], str) and not isinstance(key[1], str):
            valid = False
        elif len(key[0]) < 2 or len(key[1]) < 2:
            valid = False
        else:
            # check for unique values
            keyword = key[0]
            base = key[1]
            
            # check that the base has at least 2 unique chars
            base_unique = False
            x = 0
            while x < len(base) and base_unique == False:
                if base[x] != base[0]:
                    base_unique = True
                x += 1
                
            if base_unique == False:
                valid = False
            else:
                # check the keyword has at least 2 chars defined in base
                def_chars = []
                x = 0
                while len(def_chars) < 2 and x < len(keyword):
                    if keyword[x].lower() in base.lower():
                        def_chars.append(x)
                    x += 1
                
                if len(def_chars) < 2:
                    valid = False
            # lastly check if the result would have no encipherment
            together = keyword + base[len(keyword):] 
            if together == base:
                valid = False
        
        return valid
    
    def get_table(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Returns:      [base,sub]
        Description:  Constructs a substitution table
                      First element is the base string
                      Second element is the substitution string 
        ---------------------------------------------------
        """
        key = self.get_key()
        keyword = key[0]
        base = key[1]
        # construct substitution string
        sub = keyword
        for char in base:
            if char not in sub:
                sub += char

        return [base, sub]
    
    def set_key(self, key):
        """
        ----------------------------------------------------
        Parameters:   key (tuple(str,str))
        Returns:      success (True/False)
        Description:  Sets Simple Substitution key to given key
                      Does not update key if invalid key
                      Stores key without duplicates in lower case
                          duplicates in base are removed
                          duplicates in keyword are removed
                          keyword chars not in base are removed
                      Returns success status: True/False
        ---------------------------------------------------
        """
        s = Simple_Substitution
        valid = s.valid_key(key)
        if valid:
            keyword = ""
            base = ""
            
            for char in key[1]:
                if char.lower() not in base.lower():
                    base += char.lower()
                    
            for char in key[0]:
                if char.lower() not in keyword.lower() and char.lower() in base.lower():
                    keyword += char.lower()
                    
            self._key = (keyword, base)
        return valid
    
    def __str__(self):
        """
        ----------------------------------------------------
        Parameters:   -
        Return:       output (str): string representation
        Description:  Returns a string representation of Simple Substitution
                      Format:
                      Simple Substitution Cipher:
                      keyword = <keyword>
                      <base string>
                      <sub string>
        ---------------------------------------------------
        """
        key = self.get_key()
        base, sub = self.get_table()
        output = "Simple Substitution Cipher:\nkey = {}\n{}\n{}".format(key[0], base, sub)
        return output
    
    def encrypt(self, plaintext):
        """
        ----------------------------------------------------
        Parameters:   plaintext (str)
        Return:       ciphertext (list)
        Description:  Encryption using Simple Substitution Cipher
                      Encrypts only characters defined in base
                      Preserves the case of characters
        Asserts:      plaintext is a string
        ----------------------------------------------------
        """
        # for each character in plaintext, linear seach the base for the char
        # find the index and then match it to the same index in sub
        assert isinstance(plaintext, str), "Error(encrypt): invalid input"
        base, sub = self.get_table()
        x = 0
        i = 0
        ciphertext = ""
        found = False
        while x < len(plaintext): 
            # find the correct index
            i = 0
            found = False
            while i < len(base) and not found:
                if base[i].lower() == plaintext[x].lower():
                    found = True
                else:
                    i += 1
            if not found:
                ciphertext += plaintext[x]
            else:
                # add new char to cipher - preserve case
                if plaintext[x].isupper():
                    ciphertext += sub[i].upper()
                else:
                    ciphertext += sub[i].lower()
            
            x += 1
        return ciphertext

    def decrypt(self, ciphertext):
        """
        ----------------------------------------------------
        Parameters:   ciphertext (str)
        Return:       plaintext (list)
        Description:  decryption using Simple Substitution Cipher
                      Decrypts only characters defined in base
                      Preserves the case of characters
        Asserts:      ciphertext is a string
        ----------------------------------------------------
        """
        assert isinstance(ciphertext, str), "Error(decrypt): invalid input"
        #for each char in ciphertext, linear seach the sub for the char
        #find the index and then match it to the same index in base
        base,sub = self.get_table()
        
        x = 0
        i = 0
        plaintext = ""
        found = False
        while x < len(ciphertext): 
            # find the correct index
            i = 0
            found = False
            while i < len(sub) and not found:
                if sub[i].lower() == ciphertext[x].lower():
                    found = True
                else:
                    i += 1
            if not found:
                plaintext += ciphertext[x]
            else:
                # add new char to cipher - preserve case
                if ciphertext[x].isupper():
                    plaintext += base[i].upper()
                else:
                    plaintext += base[i].lower()
            
            x += 1
        return plaintext
