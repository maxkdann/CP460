import utilities
from A3 import Columnar_Transposition, Polybius, Simple_Substitution

def test_columnar_transposition_basics():
    print('{}'.format('-'*40))
    print("Start of Columnar Transposition Basic Testing")
    print()
    
    print('Creating a columnar transposition cipher object using default constructor:')
    ct = Columnar_Transposition()
    print(ct)
    print()

    print('Testing key_order:')
    keys = ['','r','?','RAINY?', 'dad','face','Face','apple','good day','German']
    for key in keys:
        print('Key order for {} ='.format(key),end=' ')
        key_order = Columnar_Transposition.key_order(key)
        print(key_order)
    print()
            
    print('Testing set_key and get_key:')
    keys = ['Nova Scotia', 'Ontario', 123, 'c']
    for k in keys:
        print('set_key({}) = {}, get_key = {}'.format(k,ct.set_key(k), ct.get_key()))
    print()
    
    print('Testing set_pad and get_pad:')
    pads = ['Q','x','xx',3]
    for p in pads:
        print('set_pad({}) = {}, get_pad = {}'.format(p,ct.set_pad(p), ct.get_pad()))
    print()
    
    print('End of Columnar Transposition Basic Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_columnar_transposition():
    print('{}'.format('-'*40))
    print("Start of Columnar Transposition Testing")
    print() 
    
    ct = Columnar_Transposition()
    
    plaintext1 = 'DEFENDEASTERNWALLOFTHECASTLE'   
    plaintext2 = utilities.file_to_text('plaintext1.txt')
    plaintexts = [plaintext1, plaintext2[:92], plaintext2[:92]]
    keys = ['German','Truth Seeker', 'cryptology']
    pads = ['q','.','x']
    print('Testing Encryption/Decryption:')
    for i in range(len(keys)):
        ct.set_key(keys[i])
        ct.set_pad(pads[i])
        print('key = {}, pad = {}'.format(keys[i], pads[i]))
        print('plaintext  = {}'.format(plaintexts[i]))
        ciphertext = ct.encrypt(plaintexts[i])
        print('ciphertext = {}'.format(ciphertext))
        plaintext2 = ct.decrypt(ciphertext)
        print('plaintext2 = {}'.format(plaintext2))
        print()
     
    print('End of Columnar Transposition Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_polybius_basics():
    print('{}'.format('-'*40))
    print("Start of Polybius Cipher Basics Testing")
    print()
    
    print('Creating polybius using default constructor:')
    polybius = Polybius()
    print()

    print('Testing polybius.valaid_key:')
    cases = ['a',['a',5],('a',),('a',5,'b'),(5,10),('a','b'),('ab',5),(' ',1),(' ',10),
             ('|',2),('w',3), ('s',4),('a',5),('w',2),('v',3),('c',4),('3',8),(' ',9)]
    for case in cases:
        print('{:13s} --> {}'.format(str(case),Polybius.valid_key(case)))
    print()
        
    print('Testing set_key and get_key:')
    cases = [['A',4],('B',6),(' ',9),('s',4)]
    for case in cases:
        print('Setting Polybius key to {}'.format(case))
        print('\tSuccess = {}'.format(polybius.set_key(case)))
        print('\tget_key = {}'.format(polybius.get_key()))
    print()
    
    print('Testing get_square:')
    cases = [('D',2),('m',3),('9',4),('a',5),('B',6)]
    for case in cases:
        polybius.set_key(case)
        print('Set to key {}'.format(case))
        print('get_square(list): {}'.format(polybius.get_square('list')))
        print('get_square(string):\n{}'.format(polybius.get_square('string')))
        print()
    polybius.get_square('nohting')
    print()
    
    print('Testing __str__:')
    polybius.set_key(('6',5))
    print(polybius)
    print()
    
    print('End of Polybius Cipher Basics Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_polybius_encoding():
    print('{}'.format('-'*40))
    print("Start of Polybius Cipher Encoding Testing")
    print()
    
    polybius = Polybius()
    print(polybius)
    print()
    
    print('Testing encode:')
    cases = ['a','g','n','w','z','abc']
    for case in cases:
        print('encode({}) = {}'.format(case,polybius.encode(case)))
    print()
    
    print('Testing decode: ')
    cases = ['11','31','42','53','16','02','ab']
    for case in cases:
        print('decode({}) = {}'.format(case,polybius.decode(case)))
    print()
    
    print('End of Polybius Cipher Encoding Testing')
    print('{}'.format('-'*40))
    print()
    return
    
def test_polybius():
    print('{}'.format('-'*40))
    print("Start of Polybius Cipher Testing")
    print()
    
    polybius = Polybius()
    
    plain0 = 'POLYBIUS'
    plain1 = utilities.file_to_text('plaintext2.txt')
    plain2 = utilities.file_to_text('plaintext3.txt')
    plaintexts = [plain0,plain0 + ' Cipher', plain0+'1', plain1,plain2,plain1]
    
    keys = [('A',5),('D',5),('R',4),('a',5),('D',6),('A',7)]
    for i in range(len(keys)):
        polybius.set_key(keys[i])
        print(polybius)
        plaintext = plaintexts[i]
        print('plaintext  = {}'.format(plaintext[:130]))
        ciphertext = polybius.encrypt(plaintext)
        print('ciphertext = {}'.format(ciphertext[:130]))
        plaintext2 = polybius.decrypt(ciphertext)
        print('plaintext2 = {}'.format(plaintext2[:130]))
        print()
    
    print('End of Polybius Cipher Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_polybius_cryptanalysis():
    print('{}'.format('-'*40))
    print("Start of Polybius Cipher Cryptanalysis Testing")
    print()
        
    cases = [['b',5,5,None,0.91], ['A',2,0,None,0.95],['#',0,7,None,0.96],
             ['D',0,0,None,0.95], ['',0,0,None,0.94],['',0,0,None,0.95],['',0,0,None,0.94]]
    #cases that fail: 5,6,7
    for i in range(len(cases)):
        cipher_file = 'ciphertext' + str(i+1) + '.txt'
        print('Cryptanalysis of {}'.format(cipher_file))
        ciphertext = utilities.file_to_text(cipher_file)
        key,plaintext = Polybius.cryptanalyze(ciphertext, cases[i])
        print('key = {}'.format(key))
        print('plaintext = {}'.format(plaintext[:100]))
        print()
        
    print('End of Polybius Cipher Cryptanlaysis Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_simple_substitution_basics():
    print('{}'.format('-'*40))
    print("Start of simple_substitution Basics Testing")
    print()
    
    print('------ Creating polybius using default constructor:')
    ss = Simple_Substitution()
    print(ss)
    print()

    print('------ Testing Simple_Substitution.valaid_key:')
    lower = utilities.get_base('lower')
    upper = utilities.get_base('upper')
    alphanum = utilities.get_base('alphanum')
    cases = [lower,['abc',lower],(upper,),('abc',lower[:10],upper[:5]), ('',lower),
             ('a',lower), ('a$',lower),('ab','a'), ('ab','aaa'), ('aba','bcd'), 
             ('substitution',lower[:8]),
             ('ba','ab'), ('contribution',lower[:10]), ('An',upper[:18]), ('password',upper)]
    for case in cases:
        print('{} --> {}'.format(case,Simple_Substitution.valid_key(case)))
    print()
    
    print('------ Testing set_key, get_key, get_table and __str__:')
    cases = [('contribution',lower[:10]), ('An',upper[:18]), ('password',upper),
             ('Substitution','Simple Substitution Cipher'), ('9$perday',alphanum)]
    for case in cases:
        print('Setting key to {}'.format(case))
        print('Success = {}'.format(ss.set_key(case)))
        print('get_key = {}'.format(ss.get_key()))
        print('get_table = {}'.format(ss.get_table()))
        print(ss)
        print()

    print('End of simple_substitution Cipher Basics Testing')
    print('{}'.format('-'*40))
    print()
    return

def test_simple_substitution():
    print('{}'.format('-'*40))
    print("Start of simple_substitution Cipher Testing")
    print()
    
    lower = utilities.get_base('lower')
    upper = utilities.get_base('upper')
    alphanum = utilities.get_base('alphanum')
    all = utilities.get_base('all')
    
    ss = Simple_Substitution()
    
    plain0 = 'Create strong passwords that are difficult to guess!'
    plain1 = utilities.file_to_text('plaintext2.txt')
    plaintexts = [plain0, plain1,plain1,plain1]
    
    keys = [('Oxygen',lower),('Cobalt',upper),
            ('Potassium 2 sulfide',alphanum[:10]+' '+alphanum[11:]), 
            ('FeSO4:Iron(II)sulfate',all[:20]+' '+all[21:])]
    for i in range(len(keys)):
        ss.set_key(keys[i])
        print(ss)
        plaintext = plaintexts[i]
        print('plaintext  = {}'.format(plaintext[:130]))
        ciphertext = ss.encrypt(plaintext)
        print('ciphertext = {}'.format(ciphertext[:130]))
        plaintext2 = ss.decrypt(ciphertext)
        print('plaintext2 = {}'.format(plaintext2[:130]))
        print()
    
    print('End of Simple Substitution Cipher Testing')
    print('{}'.format('-'*40))
    print()
    return

test_columnar_transposition_basics()
test_columnar_transposition()
# test_polybius_basics()
# test_polybius_encoding()
# test_polybius()
# test_polybius_cryptanalysis()
# test_simple_substitution_basics()
# test_simple_substitution()